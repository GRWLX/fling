aPackageInfo = [
    :name = "The SSHFling Package",
    :description = "Ring launcher for the bundled SSHFling runtime",
    :folder = "sshfling",
    :developer = "GRWLX",
    :email = "",
    :license = "LicenseRef-Proprietary",
    :version = "0.1.16",
    :ringversion = "1.24",
    :versions = [[:version = "0.1.16", :branch = "main"]],
    :libs = [],
    :files = ["lib.ring", "main.ring", "bin", "runtime", "LICENSE", "README.md"],
    :ringfolderfiles = []
]
