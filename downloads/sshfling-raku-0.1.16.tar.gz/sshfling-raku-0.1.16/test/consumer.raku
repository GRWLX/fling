use lib $?FILE.IO.parent.parent.add("lib").Str;
use SSHFling;

exit run(@*ARGS);
