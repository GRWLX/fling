Module {
    name: 'sshfling'
    description: 'V launcher API and CLI for the bundled SSHFling runtime'
    version: '0.1.16'
    license: 'LicenseRef-SSHFling-Commercial'
    repo_url: 'https://github.com/GRWLX/sshfling'
}
