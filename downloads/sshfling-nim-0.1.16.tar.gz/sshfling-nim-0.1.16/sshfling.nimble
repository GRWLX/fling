version = "0.1.16"
author = "GRWLX"
description = "Nim launcher API and CLI for the bundled SSHFling runtime"
license = "LicenseRef-SSHFling-Commercial"
srcDir = "src"
bin = @["sshfling_cli"]

requires "nim >= 1.6.0"
