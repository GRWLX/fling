function version = packageVersion()
%PACKAGEVERSION Return the packaged SSHFling version.
    version = '0.1.16';
end
