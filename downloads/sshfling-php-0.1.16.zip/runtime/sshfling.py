#!/usr/bin/env python3
import argparse
import base64
import datetime as dt
import fnmatch
import getpass
import glob
import hashlib
import hmac
import html
import http.server
import ipaddress
import json
import os
import urllib.parse
import shlex
import re
import secrets
import shutil
import signal
import socket
import stat
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

VERSION = "0.1.16"
DEFAULT_NETWORK = "timed-ssh-net"
DEFAULT_SESSION_WRAPPER = "/usr/local/libexec/sshfling-session"
DEFAULT_ISSUER_LISTEN = "127.0.0.1:8787"
DEFAULT_SESSION_DIR = "/var/lib/sshfling/sessions"
DEFAULT_POLICY_FILE = "/etc/sshfling/policy.json"
DEFAULT_PASSWORD_GRANT_DIR = "/var/lib/sshfling/password-grants"
DEFAULT_HOST_USER_MARKER_DIR = "/var/lib/sshfling/host-users"
DEFAULT_TEMP_USERNAME_PREFIX = "s"
DEFAULT_DETACHED_DIR = ".sshfling/detached"
MAX_TIME_SECONDS = 86400
MAX_CONNECTIONS = 10
MAX_DETACHED_JOBS = 10
DEFAULT_ACCESS_LEVEL = "standard"
ACCESS_LEVEL_ORDER = {
    "standard": 0,
    "operator": 1,
    "sudo-limited": 2,
    "admin": 3,
}
ACCESS_LEVEL_ALIASES = {
    "standard": "standard",
    "standard-user": "standard",
    "user": "standard",
    "operator": "operator",
    "ops": "operator",
    "sudo": "sudo-limited",
    "sudo-limited": "sudo-limited",
    "sudo-limited-user": "sudo-limited",
    "limited-sudo": "sudo-limited",
    "admin": "admin",
    "administrator": "admin",
    "root": "admin",
    "root-equivalent": "admin",
    "admin/root-equivalent": "admin",
}
ACCESS_LEVEL_DESCRIPTIONS = {
    "standard": "Non-privileged account; no sudo/root-equivalent rights expected.",
    "operator": "Operational account for diagnostics or approved service actions; not broad sudo.",
    "sudo-limited": "Account with a reviewed sudoers allowlist or equivalent constrained elevation.",
    "admin": "Root-equivalent or local administrator access; use only for approved break-glass work.",
}
ROOT_EQUIVALENT_USERS = {"root", "administrator"}
FORCED_SESSION_WRAPPER = "sshfling-session"
FORCED_SESSION_ALLOW_DETACHED_ARG = "--allow-detached-start"
LOGIN_SHELL_WRAPPER_ASSIGNMENT = "expected_wrapper=@SSHFLING_SESSION_WRAPPER@"
LOGIN_SHELL_POLICY_ASSIGNMENT = "expected_policy=@SSHFLING_POLICY_FILE@"
LOGIN_SHELL_BASH_ASSIGNMENT = "expected_bash=@SSHFLING_BASH@"
FORCED_COMMAND_PATH_PATTERN = re.compile(r"[A-Za-z0-9_./:@%+=,-]+")
DANGEROUS_SSH_ENVIRONMENT_NAMES = (
    "LD_PRELOAD",
    "LD_LIBRARY_PATH",
    "LD_AUDIT",
    "LD_DEBUG",
    "LD_PROFILE",
    "LD_ORIGIN_PATH",
    "DYLD_INSERT_LIBRARIES",
    "DYLD_LIBRARY_PATH",
    "DYLD_FRAMEWORK_PATH",
    "LIBPATH",
    "SHLIB_PATH",
    "LDR_PRELOAD",
    "LDR_PRELOAD64",
    "_RLD_LIST",
    "BASH_ENV",
    "BASH_FUNC_id%%",
    "ENV",
    "PATH",
    "SHELLOPTS",
    "BASHOPTS",
    "PS4",
    "PROMPT_COMMAND",
    "CDPATH",
    "GLOBIGNORE",
    "LOCPATH",
    "GCONV_PATH",
    "NLSPATH",
)
MIN_BEARER_TOKEN_LENGTH = 32
MAX_HTTP_BODY_BYTES = 16384
ISSUER_POST_RATE_LIMIT = 20
WEB_LOGIN_RATE_LIMIT = 10
RATE_LIMIT_WINDOW_SECONDS = 60
UTC = getattr(dt, "UTC", dt.timezone.utc)
AUDIT_REDACTED = "[REDACTED]"
SENSITIVE_AUDIT_FIELD_MARKERS = (
    "password",
    "token",
    "secret",
    "cookie",
    "authorization",
    "private_key",
    "public_key",
    "certificate",
    "ssh_key",
)

TEMPLATE_ENTRIES = [
    ".env.example",
    "LICENSE",
    "README.md",
    "compose.server.yml",
    "compose.client.yml",
    "native/sshfling-linux-account",
    "native/sshfling-unix-identity",
    "scripts/install-local.sh",
    "scripts/uninstall-local.sh",
    "scripts/create-network.sh",
    "scripts/generate-ssh-key.sh",
    "secrets/.gitkeep",
    "ssh-client/Dockerfile",
    "ssh-client/entrypoint.sh",
    "ssh-server/Dockerfile",
    "ssh-server/entrypoint.sh",
    "ssh-server/limited-session.sh",
    "ssh-server/sshd_config",
    "production/sshfling-login-shell",
    "production/sshfling-session",
    "systemd/sshflingd.service",
    "systemd/sshfling-prune.service",
    "systemd/sshfling-prune.timer",
    "systemd/sshflingd.env.example",
]

EXECUTABLE_TEMPLATE_ENTRIES = {
    "native/sshfling-linux-account",
    "native/sshfling-unix-identity",
    "scripts/install-local.sh",
    "scripts/uninstall-local.sh",
    "scripts/create-network.sh",
    "scripts/generate-ssh-key.sh",
    "ssh-client/entrypoint.sh",
    "ssh-server/entrypoint.sh",
    "ssh-server/limited-session.sh",
    "production/sshfling-login-shell",
    "production/sshfling-session",
}


class SSHFlingError(Exception):
    def __init__(self, message, code=1, **details):
        super().__init__(message)
        self.message = message
        self.code = code
        self.details = details


def eprint(*parts):
    print(*parts, file=sys.stderr)


def emit_json(payload):
    print(json.dumps(payload, indent=2, sort_keys=True))


def command_path(name):
    return shutil.which(name)


def trusted_root_executable(name):
    fixed_directories = (
        "/bin",
        "/usr/bin",
        "/usr/local/bin",
        "/opt/homebrew/bin",
        "/opt/local/bin",
        "/usr/pkg/bin",
        "/run/current-system/sw/bin",
        "/nix/var/nix/profiles/default/bin",
        "/run/current-system/profile/bin",
        "/var/guix/profiles/system/profile/bin",
    )
    path_directories = tuple(filter(None, os.environ.get("PATH", "").split(os.pathsep)))
    seen = set()
    for directory in (*fixed_directories, *path_directories):
        candidate = Path(directory) / name
        try:
            resolved = candidate.resolve(strict=True)
            if resolved in seen or not resolved.is_file() or not os.access(resolved, os.X_OK):
                continue
            seen.add(resolved)
            metadata = resolved.stat()
            if metadata.st_uid != 0 or stat.S_IMODE(metadata.st_mode) & 0o022:
                continue
            parent = resolved.parent
            safe_parent = True
            while True:
                parent_metadata = parent.stat()
                mode = stat.S_IMODE(parent_metadata.st_mode)
                writable = mode & 0o022
                if (
                    not stat.S_ISDIR(parent_metadata.st_mode)
                    or parent_metadata.st_uid != 0
                    or (writable and not mode & stat.S_ISVTX)
                ):
                    safe_parent = False
                    break
                if parent == parent.parent:
                    break
                parent = parent.parent
            if safe_parent:
                return resolved
        except OSError:
            continue
    raise SSHFlingError(f"Could not find a trusted root-owned {name} executable.", 127, executable=name)


def native_session_lock_tool_path():
    flock_path = command_path("flock")
    if flock_path:
        return flock_path
    if sys.platform == "darwin" or sys.platform.startswith(("freebsd", "dragonfly")):
        return command_path("lockf")
    return None


def is_loopback_host(host):
    value = (host or "").strip().strip("[]").lower()
    if value in {"localhost", "localhost.localdomain"}:
        return True
    try:
        return ipaddress.ip_address(value).is_loopback
    except ValueError:
        return False


def env_truthy(name):
    return os.environ.get(name, "").strip().lower() in {"1", "true", "yes", "on"}


def validate_bearer_token(token, label):
    token = (token or "").strip()
    if not token:
        raise SSHFlingError(f"Set {label} before starting the issuer service.", 2)
    normalized = re.sub(r"[^a-z0-9]+", "", token.lower())
    placeholder_markers = {"changeme", "placeholder", "replaceme", "yourtoken", "exampletoken", "testtoken"}
    if token == "replace-with-a-long-random-token" or any(marker in normalized for marker in placeholder_markers):
        raise SSHFlingError(f"{label} still contains the placeholder token.", 2)
    if len(token) < MIN_BEARER_TOKEN_LENGTH:
        raise SSHFlingError(f"{label} must be at least {MIN_BEARER_TOKEN_LENGTH} characters.", 2)
    if any(ch.isspace() for ch in token):
        raise SSHFlingError(f"{label} must not contain whitespace.", 2)
    return token


def bearer_token_matches(header, token):
    actual = (header or "").encode("utf-8", "surrogatepass")
    expected = f"Bearer {token}".encode("utf-8")
    return hmac.compare_digest(actual, expected)


def read_http_body(handler, max_bytes):
    try:
        length = int(handler.headers.get("Content-Length", "0"))
    except ValueError as exc:
        raise SSHFlingError("Invalid Content-Length.", 400) from exc
    if length < 0:
        raise SSHFlingError("Invalid Content-Length.", 400)
    if length > max_bytes:
        raise SSHFlingError("Request body too large.", 413)
    return handler.rfile.read(length)


def rate_limit_allowed(server, bucket, key, limit, window_seconds):
    now = time.time()
    lock = getattr(server, "rate_limit_lock", None)
    if lock is None:
        server.rate_limit_lock = threading.Lock()
        lock = server.rate_limit_lock
    with lock:
        store = getattr(server, "rate_limits", None)
        if store is None:
            store = {}
            server.rate_limits = store
        window_key = (bucket, key)
        attempts = [ts for ts in store.get(window_key, []) if now - ts < window_seconds]
        if len(attempts) >= limit:
            store[window_key] = attempts
            return False
        attempts.append(now)
        store[window_key] = attempts
        return True


def rate_limit_reset(server, bucket, key):
    lock = getattr(server, "rate_limit_lock", None)
    store = getattr(server, "rate_limits", None)
    if lock is None or store is None:
        return
    with lock:
        store.pop((bucket, key), None)


def remote_addr(handler):
    try:
        return handler.client_address[0]
    except (AttributeError, IndexError, TypeError):
        return "unknown"


def audit_field_value(key, value):
    if any(marker in str(key).lower() for marker in SENSITIVE_AUDIT_FIELD_MARKERS):
        return AUDIT_REDACTED
    return value


def audit_log(event, **fields):
    record = {
        "event": event,
        "program": "sshfling",
        "pid": os.getpid(),
    }
    if hasattr(os, "geteuid"):
        record["euid"] = os.geteuid()
    try:
        record["local_user"] = getpass.getuser()
    except Exception:
        pass
    for key, value in fields.items():
        if value is None:
            continue
        value = audit_field_value(key, value)
        if isinstance(value, Path):
            value = str(value)
        elif isinstance(value, (list, tuple, set)):
            value = ",".join(str(item) for item in value)
        record[key] = value

    logger = command_path("logger")
    if not logger:
        return
    try:
        subprocess.run(
            [logger, "-t", "sshfling", "--", json.dumps(record, sort_keys=True, separators=(",", ":"))],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
            timeout=2,
        )
    except Exception:
        pass


def is_usable_server_host(value):
    value = (value or "").strip()
    if not value or any(ch.isspace() for ch in value):
        return False
    lowered = value.lower()
    if lowered in {"localhost", "localhost.localdomain", "::1"}:
        return False
    if lowered.startswith("127."):
        return False
    if lowered.startswith("169.254."):
        return False
    return True


def detect_server_host():
    override = os.environ.get("SSHFLING_SERVER_HOST")
    if is_usable_server_host(override):
        return override.strip()

    candidates = []
    if command_path("hostname"):
        proc = run(["hostname", "-I"], capture=True, check=False)
        if proc.returncode == 0:
            candidates.extend((proc.stdout or "").split())

    try:
        candidates.append(socket.gethostbyname(socket.gethostname()))
    except OSError:
        pass

    for candidate in candidates:
        if is_usable_server_host(candidate) and "." in candidate:
            return candidate.strip()
    for candidate in candidates:
        if is_usable_server_host(candidate):
            return candidate.strip()

    try:
        fqdn = socket.getfqdn()
    except OSError:
        fqdn = ""
    if is_usable_server_host(fqdn):
        return fqdn

    return "SERVER_IP"


def is_admin():
    if hasattr(os, "geteuid"):
        return os.geteuid() == 0
    if os.name == "nt":
        try:
            import ctypes

            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        except Exception:
            return False
    return False


def require_root(action):
    if not is_admin():
        raise SSHFlingError(f"{action} requires root/admin privileges. Run it with sudo or from an elevated shell.", 77)


def run(args, cwd=None, env=None, capture=False, check=True, timeout=None):
    merged_env = os.environ.copy()
    if env:
        merged_env.update({k: str(v) for k, v in env.items() if v is not None})

    try:
        proc = subprocess.run(
            args,
            cwd=str(cwd) if cwd else None,
            env=merged_env,
            universal_newlines=True,
            stdout=subprocess.PIPE if capture else None,
            stderr=subprocess.PIPE if capture else None,
            check=False,
            timeout=timeout,
        )
    except FileNotFoundError as exc:
        raise SSHFlingError(f"Missing command: {args[0]}", 127) from exc
    except subprocess.TimeoutExpired as exc:
        if check:
            raise SSHFlingError(f"Command timed out after {timeout}s: {' '.join(args)}", 124) from exc
        return subprocess.CompletedProcess(
            args,
            124,
            stdout=exc.stdout or "",
            stderr=exc.stderr or f"timed out after {timeout}s",
        )

    if check and proc.returncode != 0:
        details = {}
        if capture:
            details = {"stdout": proc.stdout, "stderr": proc.stderr}
        raise SSHFlingError(
            f"Command failed with exit code {proc.returncode}: {' '.join(args)}",
            proc.returncode,
            **details,
        )

    return proc


def run_with_input(args, input_text, cwd=None, env=None, capture=False, check=True):
    merged_env = os.environ.copy()
    if env:
        merged_env.update({k: str(v) for k, v in env.items() if v is not None})

    try:
        proc = subprocess.run(
            args,
            cwd=str(cwd) if cwd else None,
            env=merged_env,
            input=input_text,
            universal_newlines=True,
            stdout=subprocess.PIPE if capture else None,
            stderr=subprocess.PIPE if capture else None,
            check=False,
        )
    except FileNotFoundError as exc:
        raise SSHFlingError(f"Missing command: {args[0]}", 127) from exc

    if check and proc.returncode != 0:
        details = {}
        if capture:
            details = {"stdout": proc.stdout, "stderr": proc.stderr}
        raise SSHFlingError(
            f"Command failed with exit code {proc.returncode}: {' '.join(args)}",
            proc.returncode,
            **details,
        )

    return proc


def project_dir_from(args):
    return Path(args.project_dir).expanduser().resolve()


def source_root():
    return Path(__file__).resolve().parents[1]


def native_helper_candidates(filename, override_env):
    candidates = []
    privileged = is_admin()
    override = os.environ.get(override_env)
    if override and not privileged:
        candidates.append(Path(override).expanduser())
    cli_prefix = Path(__file__).resolve().parent.parent
    template_dir = os.environ.get("SSHFLING_TEMPLATE_DIR")
    candidates.extend(
        [
            Path(__file__).resolve().parent / filename,
            Path(__file__).resolve().parent / "templates/native" / filename,
            cli_prefix / "libexec/sshfling" / filename,
            cli_prefix / "share/sshfling/templates/native" / filename,
            source_root() / "native" / filename,
        ]
    )
    if template_dir and not privileged:
        candidates.append(Path(template_dir).expanduser() / "native" / filename)
    candidates.extend(
        [
            Path("/usr/libexec/sshfling") / filename,
            Path("/usr/local/libexec/sshfling") / filename,
        ]
    )
    if not privileged:
        candidates.append(Path.home() / ".local/libexec/sshfling" / filename)
    return candidates


def find_native_helper(filename, override_env):
    candidates = native_helper_candidates(filename, override_env)
    for candidate in candidates:
        if candidate.is_file() and os.access(candidate, os.X_OK):
            return candidate.resolve(), candidates
    return None, candidates


def native_linux_account_helper(required=False):
    if not sys.platform.startswith("linux"):
        if required:
            raise SSHFlingError(
                "Linux account operations require the native sshfling-linux-account backend on a Linux host.",
                127,
            )
        return None

    helper, candidates = find_native_helper("sshfling-linux-account", "SSHFLING_LINUX_ACCOUNT_HELPER")
    if helper:
        return helper
    if required:
        raise SSHFlingError(
            "Native Linux account backend is missing. Reinstall SSHFling or set SSHFLING_LINUX_ACCOUNT_HELPER.",
            127,
            checked=[str(path) for path in candidates],
        )
    return None


def native_unix_identity_helper(required=False):
    if os.name == "nt":
        if required:
            raise SSHFlingError("Native Unix identity lookup is unavailable on Windows.", 127)
        return None

    helper, candidates = find_native_helper("sshfling-unix-identity", "SSHFLING_UNIX_IDENTITY_HELPER")
    if helper:
        return helper
    if required:
        raise SSHFlingError(
            "Native Unix identity backend is missing. Reinstall SSHFling or set SSHFLING_UNIX_IDENTITY_HELPER.",
            127,
            checked=[str(path) for path in candidates],
        )
    return None


def parse_native_backend_records(output):
    records = []
    for line in (output or "").splitlines():
        fields = line.split("\t")
        if not fields or fields[0] not in {"result", "attempt"}:
            raise SSHFlingError("Native command backend returned an invalid record.", 1, output=output)
        record = {"record": fields[0]}
        for field in fields[1:]:
            if "=" not in field:
                raise SSHFlingError("Native command backend returned an invalid field.", 1, output=output)
            key, value = field.split("=", 1)
            if not key or key in record:
                raise SSHFlingError("Native command backend returned a duplicate field.", 1, output=output)
            record[key] = value
        records.append(record)
    return records


def run_native_linux_account(action, *arguments, input_text=None, check=True):
    helper = native_linux_account_helper(required=True)
    command = [str(helper), action, *[str(value) for value in arguments]]
    if input_text is None:
        proc = run(command, capture=True, check=False)
    else:
        proc = run_with_input(command, input_text, capture=True, check=False)
    records = parse_native_backend_records(proc.stdout) if proc.stdout else []
    if check and proc.returncode != 0:
        message = (proc.stderr or "").strip() or f"Native Linux account action failed: {action}"
        raise SSHFlingError(message, proc.returncode, action=action, records=records)
    return proc, records


def run_native_unix_identity(username):
    helper = native_unix_identity_helper(required=True)
    proc = run([str(helper), "identity", str(username)], capture=True, check=False)
    records = parse_native_backend_records(proc.stdout) if proc.stdout else []
    if proc.returncode != 0:
        message = (proc.stderr or "").strip() or f"Native Unix identity lookup failed: {username}"
        raise SSHFlingError(message, proc.returncode, username=username, records=records)
    return native_result_record(records, "identity")


def native_result_record(records, action):
    results = [record for record in records if record.get("record") == "result"]
    if len(results) != 1:
        raise SSHFlingError(
            f"Native command backend returned {len(results)} result records for {action}.",
            1,
        )
    return results[0]


def native_result_for_user(records, action, username):
    result = native_result_record(records, action)
    if result.get("user") != username:
        raise SSHFlingError(
            f"Native command backend returned a result for the wrong user during {action}.",
            1,
        )
    return result


def native_result_flag(result, field, action):
    value = result.get(field)
    if value not in {"true", "false"}:
        raise SSHFlingError(
            f"Native Linux account backend returned an invalid {field!r} flag for {action}.",
            1,
        )
    return value == "true"


def native_created_user_cleanup_failure(exc, username, action):
    if not isinstance(exc, SSHFlingError) or exc.details.get("action") != action:
        return None
    matches = [
        record
        for record in exc.details.get("records", [])
        if record.get("record") == "result"
        and record.get("status") == "cleanup-failed"
        and record.get("user") == username
        and record.get("created") == "true"
        and record.get("cleanup_confirmed") == "false"
    ]
    return matches[0] if len(matches) == 1 else None


def find_template_dir():
    candidates = []

    env_dir = os.environ.get("SSHFLING_TEMPLATE_DIR")
    if env_dir and not is_admin():
        candidates.append(Path(env_dir).expanduser())

    candidates.extend(
        [
            Path(__file__).resolve().parent / "templates",
            source_root(),
            Path(__file__).resolve().parents[1] / "share/sshfling/templates",
            Path("/usr/share/sshfling/templates"),
        ]
    )
    if not is_admin():
        candidates.append(Path.home() / ".local/share/sshfling/templates")

    for candidate in candidates:
        candidate = candidate.resolve()
        if (candidate / "compose.server.yml").exists() and (candidate / "ssh-server").is_dir():
            return candidate

    raise SSHFlingError(
        "Could not find sshfling templates. Set SSHFLING_TEMPLATE_DIR or reinstall sshfling.",
        2,
        checked=[str(p) for p in candidates],
    )


def resource_file(relative):
    base = find_template_dir()
    path = base / relative
    if not path.exists():
        raise SSHFlingError(f"Missing sshfling resource: {relative}", 2, path=str(path))
    return path


def is_same_path(a, b):
    try:
        return a.resolve().samefile(b.resolve())
    except FileNotFoundError:
        return False


def symlink_component(path):
    candidate = Path(path).expanduser()
    if not candidate.is_absolute():
        candidate = Path.cwd() / candidate
    current = Path(candidate.anchor) if candidate.anchor else Path(".")
    parts = candidate.parts[1:] if candidate.anchor else candidate.parts
    for part in parts:
        current = current / part
        try:
            if current.is_symlink():
                return current
            if not current.exists():
                return None
        except OSError as exc:
            raise SSHFlingError(f"Could not inspect managed path: {candidate}", 2, path=str(candidate)) from exc
    return None


def reject_symlink_component(path, action="manage"):
    link = symlink_component(path)
    if link:
        raise SSHFlingError(
            f"Refusing to {action} through symlinked path component: {link}",
            2,
            path=str(Path(path).expanduser()),
            symlink=str(link),
        )


def prepare_root_managed_parent(path, action="install", dry_run=False):
    if not is_admin():
        return

    candidate = Path(path).expanduser()
    if not candidate.is_absolute():
        candidate = (Path.cwd() / candidate).resolve()
    parent = candidate.parent
    current = Path(parent.anchor)
    for component in parent.parts[1:]:
        current = current / component
        if not current.exists():
            if dry_run:
                return
            current.mkdir(mode=0o755)
        if current.is_symlink():
            raise SSHFlingError(
                f"Refusing to {action} below a symlinked directory: {current}",
                2,
                path=str(candidate),
            )
        try:
            metadata = current.stat()
        except OSError as exc:
            raise SSHFlingError(f"Could not inspect managed directory: {current}", 2) from exc
        mode = stat.S_IMODE(metadata.st_mode)
        writable = mode & 0o022
        sticky = mode & stat.S_ISVTX
        if not stat.S_ISDIR(metadata.st_mode) or metadata.st_uid != 0 or (writable and not sticky):
            raise SSHFlingError(
                f"Refusing to {action} below a non-root-managed directory: {current}",
                2,
                path=str(candidate),
                owner=metadata.st_uid,
                mode=oct(mode),
            )


def chmod_open_file(fd, path, mode):
    if hasattr(os, "fchmod"):
        os.fchmod(fd, mode)
    else:
        Path(path).chmod(mode)


def write_text_atomic(path, content, mode=0o600, action="write"):
    path = Path(path)
    reject_symlink_component(path, action)
    path.parent.mkdir(parents=True, exist_ok=True)
    reject_symlink_component(path, action)
    fd = None
    tmp_path = None
    try:
        fd, tmp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent), text=True)
        tmp_path = Path(tmp_name)
        chmod_open_file(fd, tmp_path, mode)
        with os.fdopen(fd, "w", encoding="utf-8") as tmp_file:
            fd = None
            tmp_file.write(content)
            tmp_file.flush()
            os.fsync(tmp_file.fileno())
        reject_symlink_component(path, action)
        tmp_path.replace(path)
    except Exception:
        if fd is not None:
            os.close(fd)
        if tmp_path is not None:
            try:
                tmp_path.unlink()
            except FileNotFoundError:
                pass
        raise


def write_bytes_atomic(path, content, mode=0o600, action="write"):
    path = Path(path)
    reject_symlink_component(path, action)
    path.parent.mkdir(parents=True, exist_ok=True)
    reject_symlink_component(path, action)
    fd = None
    tmp_path = None
    try:
        fd, tmp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent))
        tmp_path = Path(tmp_name)
        chmod_open_file(fd, tmp_path, mode)
        with os.fdopen(fd, "wb") as tmp_file:
            fd = None
            tmp_file.write(content)
            tmp_file.flush()
            os.fsync(tmp_file.fileno())
        reject_symlink_component(path, action)
        tmp_path.replace(path)
    except Exception:
        if fd is not None:
            os.close(fd)
        if tmp_path is not None:
            try:
                tmp_path.unlink()
            except FileNotFoundError:
                pass
        raise


def copy_template_file(src, dst, force, mode=None):
    if dst.exists() and not force:
        return "exists"

    if src.exists() and dst.exists() and is_same_path(src, dst):
        return "same"

    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    if mode is not None:
        dst.chmod(mode)
    return "copied"


def write_env(project_dir, force, session_seconds=None, host_port=None):
    env_example = project_dir / ".env.example"
    env_file = project_dir / ".env"

    if env_file.exists() and not force:
        status = "exists"
        lines = env_file.read_text().splitlines()
    else:
        if env_example.exists():
            lines = env_example.read_text().splitlines()
        else:
            lines = []
        status = "written"

    updates = {}
    if session_seconds is not None:
        updates["SSH_SESSION_SECONDS"] = str(session_seconds)
    if host_port is not None:
        updates["SSH_PORT_ON_HOST"] = str(host_port)

    if updates:
        seen = set()
        new_lines = []
        for line in lines:
            key = line.split("=", 1)[0] if "=" in line and not line.startswith("#") else None
            if key in updates:
                new_lines.append(f"{key}={updates[key]}")
                seen.add(key)
            else:
                new_lines.append(line)
        for key, value in updates.items():
            if key not in seen:
                new_lines.append(f"{key}={value}")
        lines = new_lines
        status = "written"

    if status == "written":
        env_file.write_text("\n".join(lines).rstrip() + "\n")
        env_file.chmod(0o600)

    return {"path": str(env_file), "status": status}


def require_project_file(project_dir, relative):
    path = project_dir / relative
    if not path.exists():
        raise SSHFlingError(
            f"Missing {relative}. Run `sshfling init` in this directory first.",
            2,
            path=str(path),
        )
    return path


def docker_compose_file(project_dir, kind):
    if kind == "server":
        return require_project_file(project_dir, "compose.server.yml")
    if kind == "client":
        return require_project_file(project_dir, "compose.client.yml")
    raise SSHFlingError(f"Unknown compose kind: {kind}", 2)


def compose_command(project_dir, kind):
    return ["docker", "compose", "-f", str(docker_compose_file(project_dir, kind))]


DEPENDENCY_MODES = {
    "client": [
        {"name": "ssh", "required": True, "kind": "openssh-client"},
        {"name": "ssh-keygen", "required": True, "kind": "openssh-client"},
        {"name": "ssh-keyscan", "required": True, "kind": "openssh-client"},
        {"name": "scp", "required": False, "kind": "openssh-client"},
        {"name": "rsync", "required": False, "kind": "file-transfer"},
    ],
    "password-server": [
        {"name": "sshd", "required": True, "kind": "openssh-server"},
        {"name": "jq", "required": True, "kind": "policy-parser"},
        {"name": "sshfling-unix-identity", "required": True, "kind": "native-backend"},
        {"name": "sshfling-linux-account", "required": True, "kind": "native-backend"},
        {"name": "useradd", "required": True, "kind": "account-tools"},
        {"name": "userdel", "required": True, "kind": "account-tools"},
        {"name": "chpasswd", "required": True, "kind": "account-tools"},
        {"name": "usermod", "required": True, "kind": "account-tools"},
        {"name": "passwd", "required": False, "kind": "account-tools"},
        {"name": "chage", "required": True, "kind": "account-tools"},
        {"name": "flock-or-lockf", "required": True, "kind": "session-lock"},
        {"name": "ps", "required": False, "kind": "process-tools"},
    ],
    "certificate-host": [
        {"name": "sshd", "required": True, "kind": "openssh-server"},
        {"name": "jq", "required": True, "kind": "policy-parser"},
        {"name": "sshfling-unix-identity", "required": True, "kind": "native-backend"},
        {"name": "sshfling-linux-account", "required": False, "kind": "native-backend"},
        {"name": "ssh-keygen", "required": True, "kind": "openssh-client"},
        {"name": "flock-or-lockf", "required": True, "kind": "session-lock"},
        {"name": "useradd", "required": False, "kind": "account-tools"},
        {"name": "userdel", "required": False, "kind": "account-tools"},
        {"name": "openssl", "required": False, "kind": "password-hash"},
        {"name": "ps", "required": False, "kind": "process-tools"},
    ],
}


def command_version(name, path=None):
    program = path or name
    commands = {
        "ssh": [program, "-V"],
        "sshd": [program, "-V"],
        "rsync": [program, "--version"],
        "openssl": [program, "version"],
    }
    command = commands.get(name)
    if not command:
        return None
    proc = run(command, capture=True, check=False, timeout=3)
    if proc.returncode != 0:
        return None
    output = (proc.stdout or proc.stderr or "").splitlines()
    return output[0].strip() if output else None


def dependency_inventory(mode="all"):
    if mode == "all":
        modes = list(DEPENDENCY_MODES)
    elif mode in DEPENDENCY_MODES:
        modes = [mode]
    else:
        allowed = ", ".join(["all", *DEPENDENCY_MODES])
        raise SSHFlingError(f"Unknown dependency mode {mode!r}. Use one of: {allowed}.", 2)

    results = []
    seen = set()
    for mode_name in modes:
        for item in DEPENDENCY_MODES[mode_name]:
            key = (mode_name, item["name"])
            if key in seen:
                continue
            seen.add(key)
            if item["name"] == "sshfling-unix-identity":
                helper = native_unix_identity_helper(required=False)
                path = str(helper) if helper else None
            elif item["name"] == "sshfling-linux-account":
                helper = native_linux_account_helper(required=False)
                path = str(helper) if helper else None
            elif item["name"] == "flock-or-lockf":
                path = native_session_lock_tool_path()
            else:
                path = command_path(item["name"])
            result = {
                "mode": mode_name,
                "name": item["name"],
                "kind": item["kind"],
                "required": bool(item["required"]),
                "present": path is not None,
                "path": path,
            }
            if path:
                version = command_version(item["name"], path)
                if version:
                    result["version"] = version
            results.append(result)

    required_missing = [
        item for item in results if item["required"] and not item["present"]
    ]
    return {
        "ok": not required_missing,
        "mode": mode,
        "dependency_ownership": "platform-managed",
        "dependency_cleanup": "sshfling does not remove or autoremove OpenSSH or account-tool packages",
        "dependencies": results,
        "missing_required": required_missing,
    }


def print_dependency_inventory(payload):
    print("dependency ownership: platform-managed")
    print("dependency cleanup: sshfling does not remove or autoremove OpenSSH or account-tool packages")
    for item in payload["dependencies"]:
        marker = "ok" if item["present"] else ("missing" if item["required"] else "optional-missing")
        suffix = ""
        if item.get("path"):
            suffix = f" ({item['path']})"
        if item.get("version"):
            suffix += f" {item['version']}"
        required = "required" if item["required"] else "optional"
        print(f"{marker:16} {item['mode']} {item['name']} [{required}]{suffix}")


def cmd_doctor(args):
    if getattr(args, "dependencies", False):
        payload = dependency_inventory(getattr(args, "dependency_mode", "all"))
        if args.json:
            emit_json(payload)
        else:
            print_dependency_inventory(payload)
        return 0 if payload["ok"] else 1

    project_dir = project_dir_from(args)
    checks = []

    def add_check(name, ok, **extra):
        checks.append({"name": name, "ok": bool(ok), **extra})

    add_check("python", True, path=sys.executable, version=sys.version.split()[0])

    for name in ["docker", "ssh", "ssh-keygen", "ssh-keyscan"]:
        path = command_path(name)
        add_check(name, path is not None, path=path)

    docker_compose_ok = False
    docker_compose_version = None
    if command_path("docker"):
        proc = run(["docker", "compose", "version"], capture=True, check=False)
        docker_compose_ok = proc.returncode == 0
        docker_compose_version = (proc.stdout or proc.stderr or "").strip()
    add_check("docker compose", docker_compose_ok, version=docker_compose_version)

    try:
        template_dir = find_template_dir()
        add_check("templates", True, path=str(template_dir))
    except SSHFlingError as exc:
        add_check("templates", False, message=exc.message)

    for rel in ["compose.server.yml", "compose.client.yml"]:
        add_check(rel, (project_dir / rel).exists(), path=str(project_dir / rel))

    add_check("public key", (project_dir / "secrets/client_ed25519.pub").exists())
    add_check("private key", (project_dir / "secrets/client_ed25519").exists())

    network_exists = False
    if command_path("docker"):
        proc = run(["docker", "network", "inspect", DEFAULT_NETWORK], capture=True, check=False)
        network_exists = proc.returncode == 0
    add_check("docker network", network_exists, network=DEFAULT_NETWORK)

    ok = all(
        check["ok"]
        for check in checks
        if check["name"] in ["python", "docker", "docker compose", "ssh", "ssh-keygen", "ssh-keyscan", "templates"]
    )
    payload = {"ok": ok, "command": "sshfling", "version": VERSION, "project_dir": str(project_dir), "checks": checks}

    if args.json:
        emit_json(payload)
    else:
        print(f"sshfling {VERSION}")
        print(f"Project: {project_dir}")
        for check in checks:
            marker = "ok" if check["ok"] else "missing"
            suffix = ""
            if "path" in check and check["path"]:
                suffix = f" ({check['path']})"
            elif "version" in check and check["version"]:
                suffix = f" ({check['version']})"
            elif check["name"] == "docker network":
                suffix = f" ({check.get('network', DEFAULT_NETWORK)})"
            print(f"{marker:7} {check['name']}{suffix}")

    return 0 if ok else 1


def cmd_init(args):
    project_dir = project_dir_from(args)
    template_dir = find_template_dir()
    project_dir.mkdir(parents=True, exist_ok=True)

    results = []
    for rel in TEMPLATE_ENTRIES:
        src = template_dir / rel
        dst = project_dir / rel
        if not src.exists():
            raise SSHFlingError(f"Template is missing: {src}", 2)
        mode = 0o755 if rel in EXECUTABLE_TEMPLATE_ENTRIES else None
        status = copy_template_file(src, dst, args.force, mode=mode)
        results.append({"path": rel, "status": status})

    env_result = write_env(project_dir, args.force, args.session_seconds, args.host_port)

    key_result = None
    if args.with_key:
        key_args = argparse.Namespace(
            project_dir=str(project_dir),
            path="secrets/client_ed25519",
            force=args.force,
            json=args.json,
        )
        key_result = generate_key(key_args, emit=False)

    payload = {
        "ok": True,
        "project_dir": str(project_dir),
        "template_dir": str(template_dir),
        "files": results,
        "env": env_result,
        "key": key_result,
    }

    if args.json:
        emit_json(payload)
    else:
        print(f"Initialized sshfling deployment in {project_dir}")
        print(f"Templates: {template_dir}")
        print(f"Env: {env_result['status']} {env_result['path']}")
        if key_result:
            print(f"Key: {key_result['status']} {key_result['private_key']}")

    return 0


def generate_key(args, emit=True):
    project_dir = project_dir_from(args)
    key_path = (project_dir / args.path).resolve()
    pub_path = Path(str(key_path) + ".pub")

    if (key_path.exists() or pub_path.exists()) and not args.force:
        result = {
            "ok": True,
            "status": "exists",
            "private_key": str(key_path),
            "public_key": str(pub_path),
        }
        if emit:
            if args.json:
                emit_json(result)
            else:
                print(f"Key already exists: {key_path}")
        return result

    if args.force:
        key_path.unlink(missing_ok=True)
        pub_path.unlink(missing_ok=True)

    key_path.parent.mkdir(parents=True, exist_ok=True)
    run(["ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-C", "sshfling-client", "-f", str(key_path)], capture=True)
    key_path.chmod(0o600)
    pub_path.chmod(0o644)

    result = {
        "ok": True,
        "status": "created",
        "private_key": str(key_path),
        "public_key": str(pub_path),
    }

    if emit:
        if args.json:
            emit_json(result)
        else:
            print(f"Created key: {key_path}")
            print(f"Created public key: {pub_path}")

    return result


def default_ca_key_path():
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        return Path("/etc/sshfling/ca_user_ed25519")
    return Path.home() / ".sshfling/ca_user_ed25519"


def default_policy():
    return {
        "version": 2,
        "default": {
            "max_time_seconds": MAX_TIME_SECONDS,
            "max_connections": MAX_CONNECTIONS,
            "access_level": DEFAULT_ACCESS_LEVEL,
        },
        "users": {},
    }


def policy_file_path(value=None):
    return Path(value or DEFAULT_POLICY_FILE).expanduser().resolve()


def format_duration(seconds):
    if seconds == 86400:
        return "24 hours"
    if seconds == 3600:
        return "1 hour"
    if seconds % 3600 == 0:
        return f"{seconds // 3600}h"
    if seconds % 60 == 0:
        return f"{seconds // 60}m"
    return f"{seconds}s"


def duration_input_value(seconds):
    if seconds % 3600 == 0:
        return f"{seconds // 3600}h"
    if seconds % 60 == 0:
        return f"{seconds // 60}m"
    return f"{seconds}s"


def normalize_access_level(value, default=DEFAULT_ACCESS_LEVEL):
    if value is None or str(value).strip() == "":
        value = default
    token = str(value).strip().lower().replace("_", "-").replace(" ", "-")
    normalized = ACCESS_LEVEL_ALIASES.get(token)
    if not normalized:
        allowed = ", ".join(ACCESS_LEVEL_ORDER)
        raise SSHFlingError(f"Invalid access level {value!r}. Use one of: {allowed}.", 2, access_level=value)
    return normalized


def access_level_catalog():
    return {
        name: {
            "rank": ACCESS_LEVEL_ORDER[name],
            "description": ACCESS_LEVEL_DESCRIPTIONS[name],
            "root_equivalent": name == "admin",
        }
        for name in ACCESS_LEVEL_ORDER
    }


def implied_access_level_for_username(username):
    if not username:
        return None
    if is_root_equivalent_user(username):
        return "admin"
    return None


def unix_user_identity(username):
    username = str(username or "")
    if not username:
        return None
    if native_unix_identity_helper(required=False) is None:
        return None
    result = run_native_unix_identity(username)
    if result.get("user") != username:
        raise SSHFlingError("Native Unix identity backend returned a result for the wrong user.", 1)
    if result.get("status") == "missing":
        return None
    if result.get("status") != "present":
        raise SSHFlingError("Native Unix identity backend returned an invalid identity result.", 1)
    return native_identity_from_result(result, username)


def native_identity_from_result(result, username):
    uid_text = result.get("uid", "")
    gid_text = result.get("gid", "")
    home = result.get("home", "")
    if (
        not re.fullmatch(r"0|[1-9][0-9]*", uid_text)
        or not re.fullmatch(r"0|[1-9][0-9]*", gid_text)
        or not home
        or any(character in home for character in "\t\r\n")
    ):
        raise SSHFlingError("Native Unix identity backend returned an invalid identity.", 1)
    return {
        "username": username,
        "uid": int(uid_text),
        "gid": int(gid_text),
        "home": home,
    }


def native_attempts(records, username):
    command_templates = {
        ("lock", "usermod"): f"usermod --lock {username}",
        ("lock", "passwd"): f"passwd -l {username}",
        ("expire", "chage"): f"chage -E 0 {username}",
        ("delete-home", "userdel"): f"userdel --remove {username}",
        ("delete", "userdel"): f"userdel {username}",
    }
    attempts = []
    for record in records:
        if record.get("record") != "attempt":
            continue
        key = (record.get("action"), record.get("tool"))
        try:
            returncode = int(record["returncode"])
        except (KeyError, TypeError, ValueError) as exc:
            raise SSHFlingError("Native Linux account backend returned an invalid attempt.", 1) from exc
        attempts.append(
            {
                "command": command_templates.get(key, f"{record.get('tool', 'unknown')} {record.get('action', '')}".strip()),
                "returncode": returncode,
            }
        )
    return attempts


def unix_identity_metadata(identity):
    if not identity:
        return {}
    result = {}
    for source_key, metadata_key in [("uid", "user_uid"), ("gid", "user_gid"), ("home", "user_home")]:
        if identity.get(source_key) is not None:
            result[metadata_key] = identity[source_key]
    return result


def expected_unix_identity(metadata):
    identity = {}
    if not isinstance(metadata, dict):
        return identity
    for metadata_key, target_key in [("user_uid", "uid"), ("user_gid", "gid"), ("user_home", "home")]:
        if metadata.get(metadata_key) is not None:
            identity[target_key] = metadata[metadata_key]
    return identity


def unix_identity_mismatch(username, expected):
    expected = expected or {}
    if not expected:
        return None
    current = unix_user_identity(username)
    if not current:
        return {"expected_identity": expected, "current_identity": None}
    for key in ["uid", "gid", "home"]:
        if key in expected and current.get(key) != expected[key]:
            return {"expected_identity": expected, "current_identity": current}
    return None


def is_root_equivalent_user(username):
    normalized = str(username or "").strip().lower()
    if normalized in ROOT_EQUIVALENT_USERS:
        return True
    identity = unix_user_identity(username)
    return bool(identity and identity.get("uid") == 0)


def reject_root_equivalent_user_deletion(username, action):
    if is_root_equivalent_user(username):
        raise SSHFlingError(
            f"Refusing to {action} root-equivalent Unix user {username!r}.",
            2,
            username=username,
        )


def validate_access_level_for_username(username, access_level):
    normalized = normalize_access_level(access_level)
    required = implied_access_level_for_username(username)
    if required and ACCESS_LEVEL_ORDER[normalized] < ACCESS_LEVEL_ORDER[required]:
        raise SSHFlingError(
            f"Account {username!r} is root-equivalent; use access level admin/root-equivalent.",
            2,
            username=username,
            access_level=normalized,
            required_access_level=required,
        )
    return normalized


def enforce_policy_access_level(policy_caps, username=None, requested_access_level=None):
    policy_level = normalize_access_level(policy_caps.get("access_level", DEFAULT_ACCESS_LEVEL))
    requested = normalize_access_level(requested_access_level, default=policy_level)
    validate_access_level_for_username(username, requested)
    if ACCESS_LEVEL_ORDER[requested] > ACCESS_LEVEL_ORDER[policy_level]:
        raise SSHFlingError(
            f"Requested access level {requested} exceeds policy access level {policy_level}.",
            2,
            username=username,
            requested_access_level=requested,
            policy_access_level=policy_level,
        )
    return requested


def access_level_help():
    return "Privilege classification only; does not grant OS sudo/root rights. Values: standard, operator, sudo-limited, admin/root-equivalent."


def access_level_label(value):
    normalized = normalize_access_level(value)
    if normalized == "admin":
        return "admin/root-equivalent"
    return normalized


def access_level_select_options(selected=None, include_preserve=False):
    selected = normalize_access_level(selected) if selected else None
    options = []
    if include_preserve:
        options.append('<option value="">Preserve current</option>')
    for name in ACCESS_LEVEL_ORDER:
        selected_attr = " selected" if name == selected else ""
        label = access_level_label(name)
        options.append(f'<option value="{html.escape(name)}"{selected_attr}>{html.escape(label)}</option>')
    return "\n".join(options)


def validate_policy_values(max_time_seconds, max_connections, access_level=None):
    if max_time_seconds < 1:
        raise SSHFlingError("Maximum time must be positive.", 2)
    if max_time_seconds > MAX_TIME_SECONDS:
        raise SSHFlingError(f"Maximum time cannot exceed {format_duration(MAX_TIME_SECONDS)}.", 2)
    if max_connections < 1:
        raise SSHFlingError("Maximum connections must be positive.", 2)
    if max_connections > MAX_CONNECTIONS:
        raise SSHFlingError(f"Maximum connections cannot exceed {MAX_CONNECTIONS}.", 2)
    return {
        "max_time_seconds": max_time_seconds,
        "max_connections": max_connections,
        "access_level": normalize_access_level(access_level),
    }


def normalize_policy(data):
    policy = default_policy()
    if "default" in data:
        default_data = data.get("default") or {}
        policy["default"] = validate_policy_values(
            int(default_data.get("max_time_seconds", policy["default"]["max_time_seconds"])),
            int(default_data.get("max_connections", policy["default"]["max_connections"])),
            default_data.get("access_level", policy["default"]["access_level"]),
        )
    else:
        policy["default"] = validate_policy_values(
            int(data.get("max_time_seconds", policy["default"]["max_time_seconds"])),
            int(data.get("max_connections", policy["default"]["max_connections"])),
            data.get("access_level", policy["default"]["access_level"]),
        )

    users = {}
    for username, user_policy in (data.get("users") or {}).items():
        if not username:
            continue
        users[str(username)] = validate_policy_values(
            int(user_policy.get("max_time_seconds", policy["default"]["max_time_seconds"])),
            int(user_policy.get("max_connections", policy["default"]["max_connections"])),
            user_policy.get("access_level", policy["default"]["access_level"]),
        )
    policy["users"] = users
    return policy


def load_policy(policy_file=None):
    path = policy_file_path(policy_file)
    data = default_policy()
    if path.exists():
        try:
            data = json.loads(path.read_text())
        except json.JSONDecodeError as exc:
            raise SSHFlingError(f"Invalid policy file: {path}", 2) from exc

    policy = normalize_policy(data)
    policy["path"] = str(path)
    return policy


def effective_policy(policy, username=None):
    caps = policy["default"].copy()
    if username and username in policy.get("users", {}):
        caps.update(policy["users"][username])
    caps["username"] = username
    caps["path"] = policy.get("path")
    return caps


def write_policy(policy_file, max_time_seconds, max_connections, username=None, access_level=None):
    existing = load_policy(policy_file)
    current_caps = effective_policy(existing, username) if username else effective_policy(existing)
    if max_time_seconds is None:
        max_time_seconds = current_caps["max_time_seconds"]
    if max_connections is None:
        max_connections = current_caps["max_connections"]
    caps = validate_policy_values(
        max_time_seconds,
        max_connections,
        access_level if access_level is not None else current_caps["access_level"],
    )
    if username:
        caps["access_level"] = validate_access_level_for_username(username, caps["access_level"])
    if username:
        existing.setdefault("users", {})[username] = caps
    else:
        existing["default"] = caps
    policy = normalize_policy(existing)
    path = policy_file_path(policy_file)
    reject_symlink_component(path, "write policy")
    write_text_atomic(path, json.dumps(policy, indent=2, sort_keys=True) + "\n", 0o644, "write policy")
    policy["path"] = str(path)
    return policy


def read_text_source(value, file_path, label):
    if value and file_path:
        raise SSHFlingError(f"Use either --{label} or --{label}-file, not both.", 2)
    if value:
        return value.strip()
    if file_path:
        return Path(file_path).expanduser().read_text().strip()
    raise SSHFlingError(f"Missing --{label} or --{label}-file.", 2)


def sign_user_certificate(
    ca_key,
    public_key_text,
    principal,
    seconds,
    key_id=None,
    out_file=None,
    serial=None,
    source_address=None,
    session_wrapper=DEFAULT_SESSION_WRAPPER,
    policy_file=DEFAULT_POLICY_FILE,
    login_user=None,
    permit_pty=True,
    access_level=None,
):
    principal = validate_certificate_principal(principal)
    session_wrapper = validate_forced_command_path(session_wrapper, "Session wrapper")
    if login_user:
        validate_unix_username(login_user)
    policy = load_policy(policy_file)
    policy_path = validate_forced_command_path(policy["path"], "Policy file")
    login_name = login_user or principal
    active_policy = effective_policy(policy, login_name)
    grant_access_level = enforce_policy_access_level(active_policy, login_name, access_level)
    if seconds < 1:
        raise SSHFlingError("Certificate lifetime must be positive.", 2)
    if seconds > active_policy["max_time_seconds"]:
        raise SSHFlingError(f"Certificate lifetime cannot exceed {format_duration(active_policy['max_time_seconds'])}.", 2)

    ca_key_path = Path(ca_key).expanduser().resolve()
    if not ca_key_path.exists():
        raise SSHFlingError(f"CA key does not exist: {ca_key_path}", 2)

    key_id = key_id or f"sshfling-{principal}-{dt.datetime.now(UTC).strftime('%Y%m%dT%H%M%SZ')}"
    serial = serial if serial is not None else secrets.randbits(63)
    force_command = (
        f"{shlex.quote(session_wrapper)} --max-seconds {seconds} "
        f"--username {shlex.quote(principal)} --login-user {shlex.quote(login_user or principal)} "
        f"--policy-file {shlex.quote(policy_path)}"
    )

    with tempfile.TemporaryDirectory(prefix="sshfling-cert-") as tmp:
        pub_path = Path(tmp) / "client.pub"
        pub_path.write_text(public_key_text.rstrip() + "\n")
        pub_path.chmod(0o600)

        cmd = [
            "ssh-keygen",
            "-q",
            "-s",
            str(ca_key_path),
            "-I",
            key_id,
            "-z",
            str(serial),
            "-n",
            principal,
            "-V",
            f"+{seconds}s",
            "-O",
            "clear",
            "-O",
            f"force-command={force_command}",
        ]
        if permit_pty:
            cmd += ["-O", "permit-pty"]
        if source_address:
            cmd += ["-O", f"source-address={source_address}"]
        cmd.append(str(pub_path))

        run(cmd, capture=True)

        cert_path = Path(tmp) / "client-cert.pub"
        certificate = cert_path.read_text().strip()

    if out_file:
        out_path = Path(out_file).expanduser().resolve()
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(certificate + "\n")
        out_path.chmod(0o644)
    else:
        out_path = None

    valid_before = dt.datetime.now(UTC) + dt.timedelta(seconds=seconds)
    return {
        "ok": True,
        "certificate": certificate,
        "username": principal,
        "principal": principal,
        "seconds": seconds,
        "valid_before": valid_before.isoformat().replace("+00:00", "Z"),
        "key_id": key_id,
        "serial": serial,
        "out": str(out_path) if out_path else None,
        "force_command": force_command,
        "policy": active_policy,
        "access_level": grant_access_level,
    }


def create_ca_key(args):
    requested_ca_key = Path(args.ca_key).expanduser()
    reject_symlink_component(requested_ca_key, "initialize CA key")
    ca_key = requested_ca_key.resolve()
    ca_pub = Path(str(ca_key) + ".pub")
    reject_symlink_component(ca_pub, "initialize CA public key")
    force_replaced = bool(args.force and (ca_key.exists() or ca_pub.exists()))

    if (ca_key.exists() != ca_pub.exists()) and not args.force:
        missing = str(ca_pub if ca_key.exists() else ca_key)
        raise SSHFlingError(
            "CA keypair is incomplete; rerun ca init with --force after verifying CA custody and host trust impact.",
            2,
            ca_key=str(ca_key),
            ca_public_key=str(ca_pub),
            missing=missing,
        )

    if (ca_key.exists() or ca_pub.exists()) and not args.force:
        result = {"ok": True, "status": "exists", "ca_key": str(ca_key), "ca_public_key": str(ca_pub)}
    else:
        ca_key.parent.mkdir(parents=True, exist_ok=True)
        reject_symlink_component(ca_key, "initialize CA key")
        reject_symlink_component(ca_pub, "initialize CA public key")
        with tempfile.TemporaryDirectory(prefix=".sshfling-ca.", dir=str(ca_key.parent)) as tmp:
            tmp_key = Path(tmp) / ca_key.name
            tmp_pub = Path(str(tmp_key) + ".pub")
            run(["ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-C", "sshfling-user-ca", "-f", str(tmp_key)], capture=True)
            if not tmp_key.exists() or not tmp_pub.exists():
                raise SSHFlingError("ssh-keygen did not produce a complete CA keypair.", 1)
            tmp_key.chmod(0o600)
            tmp_pub.chmod(0o644)
            reject_symlink_component(ca_key, "replace CA key")
            reject_symlink_component(ca_pub, "replace CA public key")
            tmp_key.replace(ca_key)
            tmp_pub.replace(ca_pub)
        result = {"ok": True, "status": "created", "ca_key": str(ca_key), "ca_public_key": str(ca_pub)}
    if force_replaced:
        result["warning"] = (
            "CA rotation: replaced the existing SSHFling user CA keypair. "
            "Update host trust and reissue affected certificates."
        )
    return result


def cmd_ca_init(args):
    require_root("ca init")
    result = create_ca_key(args)
    if args.json:
        emit_json(result)
    else:
        if result.get("warning"):
            eprint(f"warning: {result['warning']}")
        print(f"{result['status']}: {result['ca_key']}")
        print(f"public: {result['ca_public_key']}")
    return 0


def cmd_policy_show(args):
    policy = load_policy(args.policy_file)
    active = effective_policy(policy, getattr(args, "user", None))
    if args.json:
        emit_json({"ok": True, "policy": policy, "effective": active, "access_levels": access_level_catalog()})
    else:
        print(f"policy: {policy['path']}")
        if getattr(args, "user", None):
            print(f"user: {args.user}")
        print(f"max-time: {format_duration(active['max_time_seconds'])}")
        print(f"max-connections: {active['max_connections']}")
        print(f"access-level: {active['access_level']}")
        print("least-privilege: access levels classify existing OS privileges; they do not grant sudo/root rights.")
    return 0


def cmd_policy_install(args):
    require_root("policy install")
    if args.user and os.name != "nt":
        require_native_identity_backend()
    policy = write_policy(args.policy_file, args.max_time, args.max_connections, args.user, getattr(args, "access_level", None))
    active = effective_policy(policy, args.user)
    audit_log(
        "policy_updated",
        user=args.user or "default",
        max_time_seconds=active["max_time_seconds"],
        max_connections=active["max_connections"],
        access_level=active["access_level"],
        policy_file=policy.get("path"),
    )
    if args.json:
        emit_json({"ok": True, "policy": policy, "effective": active, "access_levels": access_level_catalog()})
    else:
        print(f"policy: {policy['path']}")
        if args.user:
            print(f"user: {args.user}")
        print(f"max-time: {format_duration(active['max_time_seconds'])}")
        print(f"max-connections: {active['max_connections']}")
        print(f"access-level: {active['access_level']}")
        print("least-privilege: access levels classify existing OS privileges; they do not grant sudo/root rights.")
    return 0


def cmd_cert_issue(args):
    if not getattr(args, "certificate", False):
        raise SSHFlingError("Certificate issuance requires --certificate.", 2)
    if getattr(args, "time", None) is None and getattr(args, "seconds", None) is None:
        raise SSHFlingError("Certificate issue requires an explicit -t/--time lifetime.", 2)
    require_root("cert issue")
    public_key_text = read_text_source(args.public_key, args.public_key_file, "public-key")
    seconds = lifetime_seconds(args)
    principal = args.username or args.principal
    if not principal:
        raise SSHFlingError("Missing --username.", 2)
    result = sign_user_certificate(
        ca_key=args.ca_key,
        public_key_text=public_key_text,
        principal=principal,
        seconds=seconds,
        key_id=args.key_id,
        serial=args.serial,
        out_file=args.out,
        source_address=args.source_address,
        session_wrapper=args.session_wrapper,
        policy_file=args.policy_file,
        login_user=args.login_user,
        permit_pty=not args.no_pty,
        access_level=getattr(args, "access_level", None),
    )
    audit_log(
        "access_grant_created",
        auth="certificate",
        via="cli-cert-issue",
        principal=result["principal"],
        login_user=args.login_user or result["principal"],
        seconds=result["seconds"],
        valid_before=result["valid_before"],
        key_id=result["key_id"],
        serial=result["serial"],
        source_address=args.source_address,
        permit_pty=not args.no_pty,
        access_level=result["access_level"],
    )

    if args.json:
        emit_json(result)
    else:
        if result["out"]:
            print(result["out"])
        else:
            print(result["certificate"])
    return 0


def default_cert_out(public_key_file):
    if not public_key_file:
        return None
    path = Path(public_key_file).expanduser()
    if path.name.endswith(".pub"):
        return str(path.with_name(path.name[:-4] + "-cert.pub"))
    return str(path.with_name(path.name + "-cert.pub"))


def private_key_hint(public_key_file):
    if not public_key_file:
        return None
    path = Path(public_key_file).expanduser()
    if path.name.endswith(".pub"):
        return str(path.with_name(path.name[:-4]))
    return str(path)


def create_temp_client_key(username, session_dir):
    stamp = dt.datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    safe_username = re.sub(r"[^A-Za-z0-9_.-]+", "_", username).strip("._-") or random_username()
    base_dir = Path(session_dir).expanduser().resolve() / f"{safe_username}-{stamp}-{secrets.token_hex(4)}"
    base_dir.mkdir(parents=True, exist_ok=False)
    key_path = base_dir / "id_ed25519"
    run(["ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-C", f"sshfling-{safe_username}", "-f", str(key_path)], capture=True)
    key_path.chmod(0o600)
    Path(str(key_path) + ".pub").chmod(0o644)
    return {"private_key": str(key_path), "public_key": str(key_path) + ".pub", "generated_key": True}


def path_within(path, root):
    path = Path(path).expanduser().resolve()
    root = Path(root).expanduser().resolve()
    return path == root or root in path.parents


def certificate_metadata_path(material_dir):
    return Path(material_dir).expanduser().resolve() / "sshfling-cert.json"


def write_certificate_session_metadata(material_dir, metadata, dry_run=False):
    path = certificate_metadata_path(material_dir)
    reject_symlink_component(path, "write certificate session metadata")
    if dry_run:
        return {"path": str(path), "dry_run": True}
    path.parent.mkdir(parents=True, exist_ok=True)
    path.parent.chmod(0o700)
    write_json_atomic(path, metadata)
    return {"path": str(path), "metadata": "written"}


def safe_certificate_material_path(metadata, key, material_dir):
    value = metadata.get(key)
    if not value:
        return None
    path = Path(value).expanduser().resolve()
    root = Path(material_dir).expanduser().resolve()
    if not path_within(path, root):
        raise SSHFlingError(f"Refusing to prune certificate material outside managed directory: {path}", 2)
    return path


def remove_certificate_material_file(path, dry_run=False):
    if path is None:
        return {"status": "not-tracked"}
    if not path.exists():
        return {"path": str(path), "status": "missing"}
    if path.is_dir():
        raise SSHFlingError(f"Refusing to remove directory as certificate material: {path}", 2)
    if dry_run:
        return {"path": str(path), "would_remove": True, "dry_run": True}
    path.unlink()
    return {"path": str(path), "removed": True}


def prune_certificate_sessions(session_dir, username=None, all_sessions=False, dry_run=False):
    if bool(username) == bool(all_sessions):
        raise SSHFlingError("Use exactly one of --username or --all for cert prune.", 2)
    if username:
        username = validate_certificate_principal(username)
    now = int(time.time())
    root = Path(session_dir).expanduser().resolve()
    if not root.exists():
        return []

    paths = sorted(root.glob("*/sshfling-cert.json"))
    results = []
    for path in paths:
        try:
            metadata = json.loads(path.read_text())
        except (OSError, json.JSONDecodeError):
            results.append({"metadata_path": str(path), "status": "skipped-invalid-metadata"})
            continue
        material_dir = path.parent
        session_username = metadata.get("username") or material_dir.name.split("-", 1)[0]
        try:
            session_username = validate_certificate_principal(session_username)
        except SSHFlingError:
            results.append({"metadata_path": str(path), "username": str(session_username), "status": "skipped-invalid-principal"})
            continue
        if username and session_username != username:
            continue
        if metadata.get("managed_by") != "sshfling" or metadata.get("auth") != "certificate":
            results.append({"metadata_path": str(path), "username": session_username, "status": "skipped-unmanaged"})
            continue
        try:
            expires_at = int(metadata["expires_at"])
        except (KeyError, TypeError, ValueError):
            results.append({"metadata_path": str(path), "username": session_username, "status": "skipped-invalid-metadata"})
            continue
        if expires_at > now:
            results.append({"metadata_path": str(path), "username": session_username, "status": "active", "expires_at": expires_at})
            continue

        item = {"metadata_path": str(path), "username": session_username, "expires_at": expires_at, "status": "pruned"}
        item["private_key"] = remove_certificate_material_file(safe_certificate_material_path(metadata, "private_key", material_dir), dry_run)
        item["public_key"] = remove_certificate_material_file(safe_certificate_material_path(metadata, "public_key", material_dir), dry_run)
        item["certificate"] = remove_certificate_material_file(safe_certificate_material_path(metadata, "certificate", material_dir), dry_run)
        if dry_run:
            item["metadata"] = {"path": str(path), "would_remove": True, "dry_run": True}
            item["directory"] = {"path": str(material_dir), "would_remove_if_empty": True, "dry_run": True}
        else:
            path.unlink(missing_ok=True)
            item["metadata"] = {"path": str(path), "removed": True}
            try:
                material_dir.rmdir()
                item["directory"] = {"path": str(material_dir), "removed": True}
            except OSError:
                item["directory"] = {"path": str(material_dir), "status": "not-empty"}
        results.append(item)

    if username and not results:
        results.append({"username": username, "status": "missing", "session_dir": str(root)})
    return results


def cmd_cert_prune(args):
    results = prune_certificate_sessions(
        args.session_dir,
        username=args.username,
        all_sessions=args.all,
        dry_run=args.dry_run,
    )
    payload = {"ok": True, "results": results, "count": len(results)}
    audit_log(
        "certificate_sessions_pruned",
        username=args.username,
        all_sessions=args.all,
        dry_run=args.dry_run,
        count=len(results),
    )
    if args.json:
        emit_json(payload)
    else:
        if not results:
            print("no certificate sessions to prune")
        for item in results:
            print(json.dumps(item, sort_keys=True))
    return 0


def random_username(prefix=DEFAULT_TEMP_USERNAME_PREFIX):
    return f"{prefix}{secrets.randbelow(1000000):06d}"


def managed_login_shell_path(session_wrapper):
    return Path(session_wrapper).expanduser().resolve().with_name("sshfling-login-shell")


def validate_forced_command_path(path, label):
    value = str(path)
    if not value.startswith("/") or not FORCED_COMMAND_PATH_PATTERN.fullmatch(value):
        raise SSHFlingError(
            f"{label} must be an absolute path containing only force-command-safe characters.",
            2,
            path=value,
        )
    return value


def is_ssh_connect_target(value):
    if value.startswith("-") or "/" in value or value.count("@") != 1:
        return False
    user, host = value.split("@", 1)
    return bool(user and host and not any(ch.isspace() for ch in value))


def maybe_connect_argv(argv):
    subcommands = {
        "doctor",
        "setup",
        "shutdown",
        "list",
        "ca",
        "cert",
        "policy",
        "host",
        "serve",
        "web",
        "web-hash",
        "init",
        "key",
        "network",
        "server",
        "client",
        "test-timeout",
        "compose",
        "package",
        "password",
        "detached",
        "scp",
        "rsync",
        "_detached-supervisor",
    }
    for index, token in enumerate(argv):
        if token == "--":
            continue
        if is_ssh_connect_target(token):
            return argv[:index], token, argv[index + 1 :]
        if not token.startswith("-"):
            if token in subcommands:
                return None
    return None


def audit_command_name(argv):
    subcommands = {
        "doctor",
        "setup",
        "shutdown",
        "list",
        "ca",
        "cert",
        "policy",
        "host",
        "serve",
        "web",
        "web-hash",
        "init",
        "key",
        "network",
        "server",
        "client",
        "test-timeout",
        "compose",
        "package",
        "password",
        "detached",
        "scp",
        "rsync",
    }
    for token in argv:
        if token == "--":
            break
        if token in subcommands:
            return token
        if is_ssh_connect_target(token):
            return "connect"
    if any(token in {"-k", "--kill"} or token.startswith("--kill=") for token in argv):
        return "kill"
    if not argv or any(token in {"-t", "--time", "-p", "--password", "--certificate", "--username", "--access-level", "--role"} for token in argv):
        return "setup"
    if any(token in {"--help", "-h"} for token in argv):
        return "help"
    if "--version" in argv:
        return "version"
    return "unknown"


def cmd_connect(before_args, target, after_args):
    ssh_bin = os.environ.get("SSHFLING_SSH_BIN", "ssh")
    ssh_args = [ssh_bin] + password_transfer_ssh_options() + before_args + [target] + after_args
    target_user, target_host = target.split("@", 1)
    audit_log(
        "client_connect",
        target_user=target_user,
        target_host=target_host,
        ssh_arg_count=len(before_args),
        remote_arg_count=len(after_args),
    )

    if os.environ.get("SSHFLING_CONNECT_DRY_RUN"):
        print(shlex.join(ssh_args))
        return 0

    try:
        os.execvp(ssh_bin, ssh_args)
    except FileNotFoundError as exc:
        raise SSHFlingError(f"Missing command: {ssh_bin}", 127) from exc


def password_transfer_ssh_options(extra_options=None):
    options = [
        "-o",
        "PreferredAuthentications=password,keyboard-interactive",
        "-o",
        "PubkeyAuthentication=no",
        "-o",
        "ForwardAgent=no",
        "-o",
        "ClearAllForwardings=yes",
    ]
    for option in extra_options or []:
        options.extend(["-o", option])
    return options


def transfer_dry_run_enabled(args):
    return bool(getattr(args, "dry_run", False) or env_truthy("SSHFLING_TRANSFER_DRY_RUN"))


def require_transfer_paths(paths, command_name):
    if len(paths) < 2:
        raise SSHFlingError(f"sshfling {command_name} requires at least one source and one destination.", 2)
    return paths[:-1], paths[-1]


def executable_exists(program):
    if not program:
        return False
    if os.path.dirname(program):
        path = Path(program)
        return path.is_file() and os.access(path, os.X_OK)
    return command_path(program) is not None


def validate_rsync_permission_value(value, label):
    value = str(value or "").strip()
    if not value:
        raise SSHFlingError(f"{label} must not be empty.", 2)
    if any(ch.isspace() for ch in value):
        raise SSHFlingError(f"{label} must not contain whitespace.", 2, value=value)
    return value


def cmd_scp(args):
    sources, destination = require_transfer_paths(args.paths, "scp")
    if args.mode:
        raise SSHFlingError(
            "sshfling scp cannot safely set explicit destination modes. Use `sshfling rsync --mode ...` for mode rewriting.",
            2,
        )
    if args.chown or args.owner_group:
        raise SSHFlingError(
            "sshfling scp cannot safely preserve or set owner/group. Use `sshfling rsync --owner-group` or `sshfling rsync --chown USER:GROUP` with a permitted account.",
            2,
        )

    scp_bin = os.environ.get("SSHFLING_SCP_BIN", "scp")
    scp_args = [scp_bin]
    if not args.sftp:
        scp_args.append("-O")
    if args.recursive:
        scp_args.append("-r")
    if args.preserve:
        scp_args.append("-p")
    if args.port:
        scp_args.extend(["-P", str(args.port)])
    scp_args.extend(password_transfer_ssh_options(args.ssh_option))
    scp_args.extend(sources)
    scp_args.append(destination)

    audit_log(
        "client_scp",
        source_count=len(sources),
        recursive=args.recursive,
        preserve=args.preserve,
        port=args.port,
        sftp=args.sftp,
    )

    if transfer_dry_run_enabled(args):
        print(shlex.join(scp_args))
        return 0

    try:
        os.execvp(scp_bin, scp_args)
    except FileNotFoundError as exc:
        raise SSHFlingError(f"Missing command: {scp_bin}", 127) from exc


def cmd_rsync(args):
    sources, destination = require_transfer_paths(args.paths, "rsync")
    rsync_bin = os.environ.get("SSHFLING_RSYNC_BIN", "rsync")
    ssh_bin = os.environ.get("SSHFLING_SSH_BIN", "ssh")
    dry_run = transfer_dry_run_enabled(args)
    if not dry_run and not executable_exists(rsync_bin):
        raise SSHFlingError(
            "rsync is required for sshfling rsync. Install rsync on the client and target, or use `sshfling scp` for basic copies.",
            127,
            command=rsync_bin,
        )

    ssh_command = [ssh_bin] + password_transfer_ssh_options(args.ssh_option)
    if args.port:
        ssh_command.extend(["-p", str(args.port)])

    rsync_args = [rsync_bin]
    if args.archive:
        rsync_args.append("-a")
    elif args.recursive:
        rsync_args.append("-r")
    if args.links and not args.archive:
        rsync_args.append("--links")
    if args.preserve:
        rsync_args.extend(["--perms", "--times"])
    if args.owner_group:
        rsync_args.extend(["--owner", "--group"])
    if args.mode:
        rsync_args.append(f"--chmod={validate_rsync_permission_value(args.mode, '--mode')}")
    if args.chown:
        rsync_args.append(f"--chown={validate_rsync_permission_value(args.chown, '--chown')}")
    rsync_args.extend(["-e", shlex.join(ssh_command)])
    rsync_args.extend(sources)
    rsync_args.append(destination)

    audit_log(
        "client_rsync",
        source_count=len(sources),
        recursive=args.recursive,
        archive=args.archive,
        preserve=args.preserve,
        owner_group=args.owner_group,
        mode_set=bool(args.mode),
        chown_set=bool(args.chown),
        port=args.port,
    )

    if dry_run:
        print(shlex.join(rsync_args))
        return 0

    try:
        os.execvp(rsync_bin, rsync_args)
    except FileNotFoundError as exc:
        raise SSHFlingError(f"Missing command: {rsync_bin}", 127) from exc


def validate_unix_username(username):
    if not re.fullmatch(r"[a-z_][a-z0-9_-]{0,31}", username):
        raise SSHFlingError(
            "Linux username must match [a-z_][a-z0-9_-]{0,31}.",
            2,
            username=username,
        )


def validate_certificate_principal(principal):
    value = str(principal or "")
    if not re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_.@-]{0,127}", value):
        raise SSHFlingError(
            "Certificate principal must match [A-Za-z0-9_][A-Za-z0-9_.@-]{0,127}.",
            2,
            principal=value,
        )
    return value


def require_password_host_tools():
    missing = [
        name
        for name in ["useradd", "userdel", "chpasswd", "usermod", "chage", "sshd", "jq"]
        if not command_path(name)
    ]
    if native_linux_account_helper(required=False) is None:
        missing.append("sshfling-linux-account")
    if native_unix_identity_helper(required=False) is None:
        missing.append("sshfling-unix-identity")
    if native_session_lock_tool_path() is None:
        missing.append("flock-or-lockf")
    if missing:
        raise SSHFlingError(
            "Password grant setup requires Linux account tools and OpenSSH server tooling. Install shadow/passwd and openssh-server tooling, or use certificate mode.",
            127,
            missing=missing,
        )


def require_native_policy_parser(dry_run=False):
    if not dry_run and not command_path("jq"):
        raise SSHFlingError(
            "jq is required for native forced-session policy enforcement. Install jq before configuring this SSH host.",
            127,
            missing=["jq"],
        )


def require_native_session_lock_tool(dry_run=False):
    if not dry_run and native_session_lock_tool_path() is None:
        raise SSHFlingError(
            "flock or lockf is required for native forced-session connection limits.",
            127,
            missing=["flock-or-lockf"],
        )


def require_native_identity_backend():
    native_unix_identity_helper(required=True)


def require_certificate_user_tools(dry_run=False):
    if dry_run:
        return
    missing = [name for name in ["useradd", "userdel", "openssl"] if not command_path(name)]
    if native_linux_account_helper(required=False) is None:
        missing.append("sshfling-linux-account")
    if missing:
        raise SSHFlingError(
            "Certificate host --create-user requires the native Linux account backend, shadow account tools, and OpenSSL.",
            127,
            missing=missing,
        )


def require_sshd_for_validation(validate=True, dry_run=False):
    if validate and not dry_run and not command_path("sshd"):
        raise SSHFlingError(
            "sshd is required to validate SSH host configuration. Install OpenSSH server tooling or pass --no-validate for a staged install.",
            127,
            missing=["sshd"],
        )


def unix_user_exists(username):
    proc, records = run_native_linux_account("exists", username, check=False)
    if proc.returncode not in {0, 1}:
        raise SSHFlingError((proc.stderr or "").strip() or f"Could not inspect Linux account: {username}", proc.returncode)
    result = native_result_for_user(records, "exists", username)
    exists = native_result_flag(result, "exists", "exists")
    expected_status = "present" if exists else "missing"
    expected_returncode = 0 if exists else 1
    if result.get("status") != expected_status or proc.returncode != expected_returncode:
        raise SSHFlingError("Native Linux account backend returned an invalid exists result.", 1)
    return exists


def set_user_password(username, password):
    _, records = run_native_linux_account("set-password", username, input_text=f"{password}\n")
    result = native_result_for_user(records, "set-password", username)
    password_set = native_result_flag(result, "password_set", "set-password")
    if result.get("status") != "updated" or not password_set:
        raise SSHFlingError("Native Linux account backend returned an invalid set-password result.", 1)


def provision_session_locks(session_wrapper, username, expected_identity=None, dry_run=False):
    wrapper = Path(session_wrapper).expanduser()
    if dry_run:
        return {
            "user": username,
            "session_locks": "would-provision",
            "slots": 10,
            "dry_run": True,
        }

    bash = trusted_root_executable("bash")
    proc = run([str(bash), "-p", str(wrapper), "--provision-locks", username], capture=True, check=False)
    records = parse_native_backend_records(proc.stdout) if proc.stdout else []
    if proc.returncode != 0:
        message = (proc.stderr or "").strip() or f"Could not provision session locks for {username}."
        raise SSHFlingError(message, proc.returncode, username=username, records=records)
    result = native_result_for_user(records, "provision-locks", username)
    uid_text = result.get("uid", "")
    slots_text = result.get("slots", "")
    lock_root = result.get("lock_root", "")
    if (
        result.get("status") != "provisioned"
        or not re.fullmatch(r"0|[1-9][0-9]*", uid_text)
        or slots_text != "10"
        or not Path(lock_root).is_absolute()
    ):
        raise SSHFlingError("Native session wrapper returned an invalid lock-provisioning result.", 1)
    uid = int(uid_text)
    if expected_identity and uid != int(expected_identity["uid"]):
        raise SSHFlingError("Native session locks were provisioned for the wrong uid.", 1)
    return {
        "user": username,
        "session_locks": "provisioned",
        "uid": uid,
        "slots": 10,
        "lock_root": lock_root,
    }


def ensure_unix_user(username, login_shell, allow_existing=False):
    if unix_user_exists(username):
        if not allow_existing:
            raise SSHFlingError(
                "Refusing to create a password grant because the Unix user appeared during setup.",
                2,
                username=username,
            )
        return {"user": username, "created": False, "identity": unix_user_identity(username)}
    requested_shell = str(login_shell)
    _, records = run_native_linux_account("create", username, requested_shell)
    result = native_result_for_user(records, "create", username)
    created = native_result_flag(result, "created", "create")
    expected_status = "created" if created else "present"
    if result.get("status") != expected_status:
        raise SSHFlingError("Native Linux account backend returned an invalid create result.", 1)
    if created and result.get("shell") != requested_shell:
        raise SSHFlingError("Native Linux account backend created the user with the wrong login shell.", 1)
    if not created and not allow_existing:
        raise SSHFlingError(
            "Refusing to create a password grant because the Unix user appeared during setup.",
            2,
            username=username,
        )
    identity = native_identity_from_result(result, username) if created else unix_user_identity(username)
    return {"user": username, "created": created, "identity": identity}


def password_force_command(username, seconds, expires_at, session_wrapper, policy_file):
    session_wrapper = validate_forced_command_path(session_wrapper, "Session wrapper")
    policy_file = validate_forced_command_path(policy_file, "Policy file")
    return (
        f"{shlex.quote(session_wrapper)} --max-seconds {seconds} --max-connections 1 "
        f"--username {shlex.quote(username)} --login-user {shlex.quote(username)} "
        f"--policy-file {shlex.quote(policy_file)} --expires-at {expires_at}"
    )


def password_grant_config(username, force_command):
    return f"""# Managed by sshfling password grant for {username}.
Match User {username}
    PasswordAuthentication yes
    KbdInteractiveAuthentication no
    PubkeyAuthentication no
    AuthenticationMethods password
    ForceCommand {force_command}
    AllowTcpForwarding no
    AllowAgentForwarding no
    AllowStreamLocalForwarding no
    PermitOpen none
    PermitListen none
    X11Forwarding no
    PermitTunnel no
"""


def cmd_setup_password(args):
    require_root("temporary password SSH access")
    require_password_host_tools()
    if not args.username:
        args.username = random_username()
    validate_unix_username(args.username)
    if is_root_equivalent_user(args.username):
        raise SSHFlingError(
            "Password grants cannot target root-equivalent Unix users. Use certificate mode with an explicit admin/root-equivalent access level for break-glass access.",
            2,
            username=args.username,
        )

    policy = load_policy(args.policy_file)
    active_policy = effective_policy(policy, args.username)
    grant_access_level = enforce_policy_access_level(active_policy, args.username, getattr(args, "access_level", None))
    seconds = lifetime_seconds(args, active_policy["max_time_seconds"])
    if seconds <= 0:
        raise SSHFlingError("Password lifetime must be positive.", 2)
    if seconds > active_policy["max_time_seconds"]:
        raise SSHFlingError(f"Password lifetime cannot exceed {format_duration(active_policy['max_time_seconds'])}.", 2)

    existing_user = unix_user_exists(args.username)
    if existing_user and not args.allow_existing_user:
        raise SSHFlingError(
            "Refusing to create a password grant for an existing Unix user. Use --allow-existing-user only for a documented break-glass case.",
            2,
            username=args.username,
        )
    pre_prune = prune_password_grants(args.password_grant_dir, username=args.username, dry_run=args.dry_run)
    blocking_pre_prune = [item for item in pre_prune if item.get("status") not in {"missing", "pruned"}]
    if blocking_pre_prune:
        active = next((item for item in blocking_pre_prune if item.get("status") == "active"), blocking_pre_prune[0])
        if active.get("status") == "active":
            raise SSHFlingError(
                f"Active password grant already exists for {args.username}. Wait until it expires or choose a different --username.",
                2,
                username=args.username,
                expires_at=active.get("expires_at"),
                metadata_path=active.get("metadata_path"),
            )
        raise SSHFlingError(
            f"Existing password grant metadata for {args.username} was not safely pruned.",
            2,
            username=args.username,
            status=active.get("status"),
            metadata_path=active.get("metadata_path"),
        )
    expires_at = int(time.time()) + seconds
    password = secrets.token_urlsafe(18)
    wrapper_path = Path(args.session_wrapper).expanduser().resolve()
    login_shell_path = managed_login_shell_path(wrapper_path)
    config_dir = Path(args.password_sshd_config_dir).expanduser().resolve()
    config_path = config_dir / f"91-sshfling-password-{args.username}.conf"
    metadata_path = password_grant_metadata_path(args.password_grant_dir, args.username)
    force_command = password_force_command(args.username, seconds, expires_at, str(wrapper_path), policy["path"])
    config = password_grant_config(args.username, force_command)
    expected_lines = [
        "passwordauthentication yes",
        "kbdinteractiveauthentication no",
        "pubkeyauthentication no",
        "authenticationmethods password",
        f"forcecommand {force_command}",
        "allowtcpforwarding no",
        "allowagentforwarding no",
        "allowstreamlocalforwarding no",
        "permitopen none",
        "permitlisten none",
    ]

    prepare_root_managed_parent(wrapper_path, "install forced-session executables", args.dry_run)
    rollback_paths = [wrapper_path, login_shell_path, config_path, metadata_path]
    for managed_path in rollback_paths:
        reject_symlink_component(managed_path, "manage password grant path")
    rollback_snapshots = [] if args.dry_run else [(path, snapshot_file(path)) for path in rollback_paths]
    created_user = False
    created_user_for_rollback = False
    user_identity = None
    user_result = {"user": args.username, "created": not existing_user, "dry_run": True}
    results = [{"pre_prune": pre_prune}]

    try:
        results.append(install_file(resource_file("production/sshfling-session"), wrapper_path, 0o755, args.dry_run))
        results.append(install_managed_login_shell(wrapper_path, policy["path"], login_shell_path, args.dry_run))
        results.append(write_if_changed(config_path, config, 0o644, args.dry_run))

        if not args.dry_run and args.validate:
            results.append(
                validate_sshd_effective(
                    args.username,
                    expected_lines,
                    config_path,
                    require_safe_environment=True,
                )
            )

        if not args.dry_run:
            results.append(reload_sshd())
            user_result = ensure_unix_user(
                args.username,
                allow_existing=args.allow_existing_user,
                login_shell=str(login_shell_path),
            )
            created_user = bool(user_result.get("created"))
            created_user_for_rollback = created_user
            user_identity = user_result.get("identity") or unix_user_identity(args.username)
            results.append(
                provision_session_locks(
                    wrapper_path,
                    args.username,
                    expected_identity=user_identity,
                )
            )

        metadata = {
            "version": 1,
            "auth": "password",
            "managed_by": "sshfling",
            "username": args.username,
            "created_user": bool(user_result.get("created")),
            "created_at": int(time.time()),
            "seconds": seconds,
            "expires_at": expires_at,
            "config_path": str(config_path),
            "session_wrapper": str(wrapper_path),
            "managed_login_shell": str(login_shell_path) if user_result.get("created") else None,
            "policy_file": policy["path"],
            "access_level": grant_access_level,
            **unix_identity_metadata(user_identity),
        }
        results.append(write_password_grant_metadata(args.password_grant_dir, args.username, metadata, args.dry_run))
        results.append(user_result)

        if not args.dry_run:
            set_user_password(args.username, password)
            results.append({"user": args.username, "password": "set"})
    except Exception as exc:
        rollback = []
        if not args.dry_run:
            preserve_rollback_paths = set()
            cleanup_failure = native_created_user_cleanup_failure(exc, args.username, "create")
            if cleanup_failure:
                preserve_rollback_paths.update({wrapper_path, login_shell_path, config_path})
                rollback.append({
                    "user": args.username,
                    "status": "preserved",
                    "reason": "native account helper could not confirm cleanup of the created user",
                    "native_result": cleanup_failure,
                })
            elif created_user_for_rollback:
                try:
                    rollback.append(rollback_delete_created_user(args.username, user_identity))
                except Exception as rollback_exc:
                    preserve_rollback_paths.update(
                        {wrapper_path, login_shell_path, config_path, metadata_path}
                    )
                    message = rollback_exc.message if isinstance(rollback_exc, SSHFlingError) else str(rollback_exc)
                    rollback.append({"user": args.username, "rollback_error": message})
            for path, snapshot in reversed(rollback_snapshots):
                if path in preserve_rollback_paths:
                    rollback.append({
                        "path": str(path),
                        "status": "preserved",
                        "reason": "created user could not be deleted",
                    })
                    continue
                try:
                    rollback.append(restore_file_snapshot(path, snapshot))
                except Exception as rollback_exc:
                    rollback.append({"path": str(path), "rollback_error": str(rollback_exc)})
            try:
                rollback.append(reload_sshd())
            except SSHFlingError as rollback_exc:
                rollback.append({"reload": "sshd", "rollback_error": rollback_exc.message})
        if isinstance(exc, SSHFlingError):
            exc.details["rollback"] = rollback
        raise

    created_user = bool(user_result.get("created"))
    server_host = detect_server_host()
    payload = {
        "ok": True,
        "auth": "password",
        "username": args.username,
        "password": password,
        "seconds": seconds,
        "expires_at": expires_at,
        "expires_at_utc": dt.datetime.fromtimestamp(expires_at, UTC).isoformat(),
        "server": server_host,
        "ssh_command": f"sshfling {args.username}@{server_host}",
        "access_level": grant_access_level,
        "policy": active_policy,
        "results": results,
    }
    audit_log(
        "access_grant_created",
        auth="password",
        via="cli-setup",
        username=args.username,
        seconds=seconds,
        expires_at=expires_at,
        expires_at_utc=payload["expires_at_utc"],
        created_user=created_user,
        existing_user=existing_user,
        access_level=grant_access_level,
        dry_run=args.dry_run,
    )

    if args.json:
        emit_json(payload)
    else:
        print(f"username: {payload['username']}")
        print(f"password: {payload['password']}")
        print(f"time: {seconds}s")
        print(f"access-level: {grant_access_level}")
        print(f"expires: {payload['expires_at_utc']}")
        print(f"connect: {payload['ssh_command']}")
    return 0


def certificate_setup_options(args):
    options = []
    for attr, label in [
        ("ca_key", "--ca-key"),
        ("login_user", "--login-user"),
        ("public_key", "--public-key"),
        ("public_key_file", "--public-key-file"),
        ("out", "--out"),
        ("session_dir", "--session-dir"),
        ("key_id", "--key-id"),
        ("source_address", "--source-address"),
    ]:
        if attr in {"ca_key", "session_dir"}:
            if getattr(args, f"{attr}_explicit", False):
                options.append(label)
        elif getattr(args, attr, None):
            options.append(label)
    if getattr(args, "no_pty", False):
        options.append("--no-pty")
    return options


def cmd_setup(args):
    if getattr(args, "password", False) and getattr(args, "certificate", False):
        raise SSHFlingError("Choose either password mode or --certificate, not both.", 2)
    if getattr(args, "certificate", False):
        if getattr(args, "time", None) is None and getattr(args, "seconds", None) is None:
            raise SSHFlingError("Temporary access requires an explicit -t/--time lifetime.", 2)
        return cmd_setup_certificate(args)

    cert_options = certificate_setup_options(args)
    if cert_options:
        raise SSHFlingError(
            "Certificate setup options require --certificate.",
            2,
            options=cert_options,
        )

    if getattr(args, "time", None) is None and getattr(args, "seconds", None) is None:
        raise SSHFlingError("Temporary access requires an explicit -t/--time lifetime.", 2)
    return cmd_setup_password(args)


def cmd_setup_certificate(args):
    if not getattr(args, "certificate", False):
        raise SSHFlingError("Certificate setup requires --certificate.", 2)
    require_root("temporary SSH access")
    if args.dry_run:
        raise SSHFlingError("Certificate setup does not support --dry-run because it signs key material.", 2)
    if not args.username:
        args.username = random_username()
    ca_key = Path(args.ca_key).expanduser().resolve()
    ca_pub = Path(str(ca_key) + ".pub")
    if not ca_key.exists() or not ca_pub.exists():
        raise SSHFlingError(f"CA keypair does not exist: {ca_key}. Run `sshfling ca init --ca-key {ca_key}` first.", 2)
    ca_result = {"ok": True, "status": "exists", "ca_key": str(ca_key), "ca_public_key": str(ca_pub)}

    key_material = {"generated_key": False, "private_key": None, "public_key": args.public_key_file}
    public_key_file = args.public_key_file
    if not args.public_key and not public_key_file:
        key_material = create_temp_client_key(args.username, args.session_dir)
        public_key_file = key_material["public_key"]
    public_key_text = read_text_source(args.public_key, public_key_file, "public-key")
    out_file = args.out if args.out else default_cert_out(public_key_file)
    seconds = lifetime_seconds(args)
    expires_at = int(time.time()) + seconds
    login_user = args.login_user or args.username

    result = sign_user_certificate(
        ca_key=str(ca_key),
        public_key_text=public_key_text,
        principal=args.username,
        seconds=seconds,
        key_id=args.key_id,
        out_file=out_file,
        source_address=args.source_address,
        session_wrapper=args.session_wrapper,
        policy_file=args.policy_file,
        login_user=login_user,
        permit_pty=not args.no_pty,
        access_level=getattr(args, "access_level", None),
    )
    result["ca"] = ca_result
    result.update(key_material)
    if key_material.get("generated_key") and key_material.get("private_key"):
        material_dir = Path(key_material["private_key"]).expanduser().resolve().parent
        metadata = {
            "version": 1,
            "managed_by": "sshfling",
            "auth": "certificate",
            "username": result["username"],
            "principal": result["principal"],
            "login_user": login_user,
            "created_at": expires_at - seconds,
            "created_at_utc": utc_iso(expires_at - seconds),
            "seconds": seconds,
            "expires_at": expires_at,
            "expires_at_utc": utc_iso(expires_at),
            "valid_before": result["valid_before"],
            "private_key": key_material["private_key"],
            "public_key": key_material["public_key"],
            "certificate": result["out"],
            "key_id": result["key_id"],
            "serial": result["serial"],
            "access_level": result["access_level"],
        }
        result["metadata"] = write_certificate_session_metadata(material_dir, metadata)

    key_hint = key_material["private_key"] or private_key_hint(public_key_file)
    server_host = detect_server_host()
    result["server"] = server_host
    if key_hint:
        result["ssh_command"] = f"ssh -i {key_hint} {login_user}@{server_host}"
    else:
        result["ssh_command"] = f"ssh {login_user}@{server_host}"
    audit_log(
        "access_grant_created",
        auth="certificate",
        via="cli-setup",
        principal=result["principal"],
        login_user=login_user,
        seconds=result["seconds"],
        valid_before=result["valid_before"],
        key_id=result["key_id"],
        serial=result["serial"],
        generated_key=bool(result.get("generated_key")),
        source_address=args.source_address,
        permit_pty=not args.no_pty,
        access_level=result["access_level"],
    )

    if args.json:
        emit_json(result)
    else:
        print(f"username: {args.username}")
        print(f"time: {seconds}s")
        print(f"access-level: {result['access_level']}")
        if result.get("private_key"):
            print(f"private-key: {result['private_key']}")
        if result["out"]:
            print(f"cert: {result['out']}")
        else:
            print(result["certificate"])
        print(f"ssh: {result['ssh_command']}")
    return 0


def process_exists(pid):
    if os.name == "nt":
        try:
            import ctypes
            from ctypes import wintypes

            access = 0x1000  # PROCESS_QUERY_LIMITED_INFORMATION
            kernel32 = ctypes.windll.kernel32
            kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
            kernel32.OpenProcess.restype = wintypes.HANDLE
            kernel32.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
            kernel32.GetExitCodeProcess.restype = wintypes.BOOL
            kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
            kernel32.CloseHandle.restype = wintypes.BOOL

            handle = kernel32.OpenProcess(access, False, int(pid))
            if not handle:
                return False
            try:
                exit_code = wintypes.DWORD()
                if not kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                    return False
                return exit_code.value == 259  # STILL_ACTIVE
            finally:
                kernel32.CloseHandle(handle)
        except Exception:
            return False
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


def terminate_windows_process(pid):
    try:
        import ctypes
        from ctypes import wintypes

        access = 0x0001  # PROCESS_TERMINATE
        kernel32 = ctypes.windll.kernel32
        kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel32.OpenProcess.restype = wintypes.HANDLE
        kernel32.TerminateProcess.argtypes = [wintypes.HANDLE, wintypes.UINT]
        kernel32.TerminateProcess.restype = wintypes.BOOL
        kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel32.CloseHandle.restype = wintypes.BOOL

        handle = kernel32.OpenProcess(access, False, int(pid))
        if not handle:
            return False
        try:
            return bool(kernel32.TerminateProcess(handle, 1))
        finally:
            kernel32.CloseHandle(handle)
    except Exception:
        return False


def child_pids(pid):
    if not command_path("pgrep"):
        return []
    proc = run(["pgrep", "-P", str(pid)], capture=True, check=False)
    if proc.returncode not in (0, 1):
        return []
    pids = []
    for line in proc.stdout.splitlines():
        try:
            pids.append(int(line.strip()))
        except ValueError:
            pass
    return pids


def kill_process_tree(pid, sig):
    for child in child_pids(pid):
        kill_process_tree(child, sig)
    try:
        os.kill(pid, sig)
    except ProcessLookupError:
        pass


def user_uid(username):
    proc = run(["id", "-u", username], capture=True, check=False)
    if proc.returncode != 0:
        raise SSHFlingError(f"Unknown login user: {username}", 2, stderr=proc.stderr)
    return proc.stdout.strip()


def find_sshfling_sessions(login_user=None, session_username=None):
    if not command_path("ps"):
        raise SSHFlingError("ps is required to inspect active sshfling sessions.", 127)

    target_uid = None
    if login_user:
        target_uid = user_uid(login_user)

    proc = run(["ps", "-eo", "pid=,ppid=,uid=,etimes=,args="], capture=True, check=False)
    if proc.returncode != 0:
        raise SSHFlingError("Could not find active sshfling sessions.", proc.returncode, stderr=proc.stderr)

    self_pid = os.getpid()
    process_rows = []
    matches = {}
    for line in proc.stdout.splitlines():
        parts = line.strip().split(None, 4)
        if len(parts) < 5:
            continue
        try:
            pid = int(parts[0])
            ppid = int(parts[1])
            age_seconds = int(parts[3])
        except ValueError:
            continue
        uid = parts[2]
        command = parts[4]
        process_rows.append({"pid": pid, "ppid": ppid, "uid": uid, "age_seconds": age_seconds, "command": command})
        if pid == self_pid:
            continue
        if target_uid is not None and uid != target_uid:
            continue
        try:
            tokens = shlex.split(command)
        except ValueError:
            tokens = command.split()
        if not tokens:
            continue
        first = Path(tokens[0]).name
        second = Path(tokens[1]).name if len(tokens) > 1 else ""
        is_session_wrapper = first == "sshfling-session" or (first in {"bash", "sh"} and second == "sshfling-session")
        if is_session_wrapper:
            username = None
            max_seconds = None
            for index, token in enumerate(tokens):
                if token == "--username" and index + 1 < len(tokens):
                    username = tokens[index + 1]
                elif token.startswith("--username="):
                    username = token.split("=", 1)[1]
                elif token == "--max-seconds" and index + 1 < len(tokens):
                    max_seconds = tokens[index + 1]
                elif token.startswith("--max-seconds="):
                    max_seconds = token.split("=", 1)[1]
            matches[pid] = {
                "pid": pid,
                "ppid": ppid,
                "uid": uid,
                "username": username,
                "age_seconds": age_seconds,
                "max_seconds": int(max_seconds) if max_seconds and max_seconds.isdigit() else None,
                "status": "processing",
                "command": command,
            }

    children_by_ppid = {}
    for row in process_rows:
        children_by_ppid.setdefault(row["ppid"], []).append(row["pid"])
    for children in children_by_ppid.values():
        children.sort()

    def descendant_pids(root_pid):
        descendants = []
        stack = list(children_by_ppid.get(root_pid, []))
        seen = set()
        while stack:
            child = stack.pop(0)
            if child in seen:
                continue
            seen.add(child)
            descendants.append(child)
            stack.extend(children_by_ppid.get(child, []))
        return descendants

    sessions = [item for pid, item in matches.items() if item["ppid"] not in matches]
    for session in sessions:
        process_pids = descendant_pids(session["pid"])
        session["process_pid"] = process_pids[0] if process_pids else None
        session["process_pids"] = process_pids
    if session_username:
        sessions = [item for item in sessions if item["username"] == session_username]
    return sorted(sessions, key=lambda item: (item["username"] or "", item["pid"]))


def find_sshfling_session_pids(login_user=None, session_username=None):
    return [session["pid"] for session in find_sshfling_sessions(login_user, session_username)]


def cmd_list(args):
    require_root("list")
    sessions = find_sshfling_sessions(getattr(args, "login_user", None), getattr(args, "username", None))
    payload = {"ok": True, "sessions": sessions, "count": len(sessions)}
    if args.json:
        emit_json(payload)
    else:
        if not sessions:
            print("no active sshfling sessions")
        else:
            print("username pid process-pid uid age max")
            for session in sessions:
                username = session["username"] or "-"
                process_pid = session["process_pid"] if session["process_pid"] is not None else "-"
                max_seconds = session["max_seconds"] if session["max_seconds"] is not None else "-"
                print(f"{username} {session['pid']} {process_pid} {session['uid']} {session['age_seconds']}s {max_seconds}")
    return 0


def cmd_kill(args):
    require_root("kill")
    login_user = getattr(args, "login_user", None)
    session_username = getattr(args, "session_username", None) or getattr(args, "username", None)
    kill_value = getattr(args, "kill", None)
    if isinstance(kill_value, str):
        session_username = kill_value
        login_user = getattr(args, "login_user", None)
    payload = kill_sshfling_sessions(login_user, session_username)
    audit_log(
        "sessions_killed",
        login_user=login_user,
        username=session_username,
        killed=payload["killed"],
        pids=payload["pids"],
    )
    if args.json:
        emit_json(payload)
    else:
        print(f"killed {payload['killed']} active sshfling session(s)")
    return 0


def kill_sshfling_sessions(login_user=None, session_username=None):
    pids = find_sshfling_session_pids(login_user, session_username)

    for pid in pids:
        kill_process_tree(pid, signal.SIGTERM)

    deadline = time.time() + 2
    while time.time() < deadline and any(process_exists(pid) for pid in pids):
        time.sleep(0.1)

    remaining = [pid for pid in pids if process_exists(pid)]
    for pid in remaining:
        kill_process_tree(pid, signal.SIGKILL)

    return {"ok": True, "killed": len(pids), "pids": pids, "login_user": login_user, "username": session_username}


def utc_timestamp():
    return int(time.time())


def utc_iso(timestamp=None):
    timestamp = utc_timestamp() if timestamp is None else int(timestamp)
    return dt.datetime.fromtimestamp(timestamp, UTC).isoformat().replace("+00:00", "Z")


def detached_root(path=None):
    if path:
        return Path(path).expanduser().resolve()
    env_path = os.environ.get("SSHFLING_DETACHED_DIR")
    if env_path:
        return Path(env_path).expanduser().resolve()
    return (Path.home() / DEFAULT_DETACHED_DIR).resolve()


def validate_detached_name(name):
    if not name or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}", name):
        raise SSHFlingError("Detached job name must match [A-Za-z0-9][A-Za-z0-9_.-]{0,79}.", 2, name=name)


def detached_paths(root, name):
    validate_detached_name(name)
    root = detached_root(root)
    return {
        "root": root,
        "metadata": root / f"{name}.json",
        "stdout": root / f"{name}.out.log",
        "stderr": root / f"{name}.err.log",
    }


def write_json_atomic(path, payload, mode=0o600):
    write_text_atomic(path, json.dumps(payload, indent=2, sort_keys=True) + "\n", mode, "write")


def read_json_file(path):
    return json.loads(Path(path).read_text())


def detached_command_from(args):
    command = list(args.detached_args or [])
    if command and command[0] == "--":
        command = command[1:]
    if not command:
        raise SSHFlingError("Pass the detached command after --.", 2)
    return command


def remaining_seconds_from_expires_at(expires_at):
    if not expires_at:
        return None
    try:
        return max(0, int(expires_at) - utc_timestamp())
    except (TypeError, ValueError):
        return None


def proc_cmdline(pid):
    try:
        raw = Path(f"/proc/{int(pid)}/cmdline").read_bytes()
    except (OSError, ValueError):
        return []
    return [part.decode("utf-8", "replace") for part in raw.split(b"\0") if part]


def proc_environ(pid):
    try:
        raw = Path(f"/proc/{int(pid)}/environ").read_bytes()
    except (OSError, ValueError):
        return {}
    env = {}
    for item in raw.split(b"\0"):
        if not item or b"=" not in item:
            continue
        key, value = item.split(b"=", 1)
        env[key.decode("utf-8", "replace")] = value.decode("utf-8", "replace")
    return env


def proc_parent_pid(pid):
    fields = proc_stat_fields(pid)
    if not fields:
        return None
    try:
        return int(fields[1])
    except (IndexError, ValueError):
        return None


def proc_stat_fields(pid):
    try:
        text = Path(f"/proc/{int(pid)}/stat").read_text()
    except (OSError, ValueError):
        return None
    try:
        return text.rsplit(")", 1)[1].strip().split()
    except IndexError:
        return None


def proc_boot_time():
    try:
        for line in Path("/proc/stat").read_text().splitlines():
            if line.startswith("btime "):
                return int(line.split()[1])
    except (OSError, ValueError, IndexError):
        return None
    return None


def proc_start_epoch(pid):
    fields = proc_stat_fields(pid)
    if not fields:
        return None
    try:
        start_ticks = int(fields[19])
        ticks_per_second = os.sysconf("SC_CLK_TCK")
    except (IndexError, OSError, ValueError):
        return None
    boot_time = proc_boot_time()
    if boot_time is None:
        return None
    return int(boot_time + (start_ticks / ticks_per_second))


def process_ancestry(max_depth=64):
    if os.name == "nt" or not hasattr(os, "getppid"):
        return []
    ancestry = []
    seen = set()
    pid = os.getppid()
    for _ in range(max_depth):
        if pid <= 1 or pid in seen:
            break
        seen.add(pid)
        ppid = proc_parent_pid(pid)
        if ppid is None:
            break
        ancestry.append({"pid": pid, "ppid": ppid, "argv": proc_cmdline(pid), "environ": proc_environ(pid)})
        pid = ppid
    return ancestry


def forced_session_wrapper_arg_index(argv):
    for index in (0, 1):
        if index < len(argv) and Path(argv[index]).name == FORCED_SESSION_WRAPPER:
            return index
    return None


def arg_value(args, name):
    for index, arg in enumerate(args):
        if arg == name and index + 1 < len(args):
            return args[index + 1]
    return None


def forced_session_remaining_from_wrapper(proc, wrapper_args):
    max_seconds = arg_value(wrapper_args, "--max-seconds")
    expires_at = arg_value(wrapper_args, "--expires-at")
    try:
        max_seconds = int(max_seconds) if max_seconds is not None else 300
    except ValueError:
        max_seconds = None
    try:
        expires_at = int(expires_at) if expires_at is not None else None
    except ValueError:
        expires_at = None

    deadline = None
    if max_seconds is not None:
        started_at = proc_start_epoch(proc.get("pid"))
        if started_at is not None:
            deadline = started_at + max_seconds
    if expires_at is not None:
        deadline = expires_at if deadline is None else min(deadline, expires_at)
    return remaining_seconds_from_expires_at(deadline)


def sshfling_forced_session_context():
    for proc in process_ancestry():
        argv = proc.get("argv") or []
        wrapper_index = forced_session_wrapper_arg_index(argv)
        if wrapper_index is None:
            continue
        wrapper_args = argv[wrapper_index + 1 :]
        env = proc.get("environ") or {}
        remaining = remaining_seconds_from_expires_at(
            env.get("SSHFLING_FORCED_SESSION_EXPIRES_AT") or env.get("SSHFLING_SESSION_EXPIRES_AT")
        )
        if remaining is None:
            remaining = forced_session_remaining_from_wrapper(proc, wrapper_args)
        return {
            "forced": True,
            "allow_detached": FORCED_SESSION_ALLOW_DETACHED_ARG in wrapper_args,
            "remaining_seconds": remaining,
            "source": f"ancestor:{proc.get('pid')}",
        }

    if (
        os.environ.get("SSHFLING_FORCED_SESSION") == "1"
        or os.environ.get("SSHFLING_SESSION_ACTIVE") == "1"
        or "SSH_ORIGINAL_COMMAND" in os.environ
    ):
        return {
            "forced": True,
            "allow_detached": False,
            "remaining_seconds": remaining_seconds_from_expires_at(
                os.environ.get("SSHFLING_FORCED_SESSION_EXPIRES_AT") or os.environ.get("SSHFLING_SESSION_EXPIRES_AT")
            ),
            "source": "environment",
        }

    return {"forced": False, "allow_detached": False, "remaining_seconds": None, "source": None}


def start_new_process_kwargs(detached=False):
    if os.name == "nt":
        flags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        if detached:
            flags |= getattr(subprocess, "DETACHED_PROCESS", 0)
        return {"creationflags": flags}
    return {"start_new_session": True}


def terminate_detached_process(pid, force=False):
    sig = signal.SIGKILL if force else signal.SIGTERM
    if os.name == "nt" and command_path("taskkill"):
        cmd = ["taskkill", "/PID", str(pid), "/T", "/F"]
        proc = run(cmd, capture=True, check=False, timeout=5)
        if proc.returncode == 0 or not process_exists(pid):
            return True
        return terminate_windows_process(pid)
    if os.name != "nt":
        try:
            os.killpg(pid, sig)
            return True
        except ProcessLookupError:
            return False
        except OSError:
            pass
    kill_process_tree(pid, sig)
    return True


def refresh_detached_job(job):
    status = job.get("status")
    pid = job.get("pid")
    supervisor_pid = job.get("supervisor_pid")
    if status in {"starting", "processing"}:
        pid_alive = bool(pid and process_exists(int(pid)))
        supervisor_alive = bool(supervisor_pid and process_exists(int(supervisor_pid)))
        if pid_alive:
            job["status"] = "processing"
        elif not supervisor_alive:
            job["status"] = "unknown"
            job.setdefault("completed_at", utc_timestamp())
            job.setdefault("completed_at_utc", utc_iso(job["completed_at"]))
    return job


def detached_metadata_claims_active(job, now=None):
    if job.get("status") not in {"starting", "processing"}:
        return False
    expires_at = job.get("expires_at")
    if expires_at is None:
        return True
    try:
        return int(expires_at) > (utc_timestamp() if now is None else int(now))
    except (TypeError, ValueError):
        return True


def active_detached_job_claims(root, exclude_name=None):
    root = detached_root(root)
    jobs = []
    if not root.exists():
        return jobs
    for path in sorted(root.glob("*.json")):
        try:
            job = read_json_file(path)
        except (OSError, json.JSONDecodeError):
            continue
        if job.get("managed_by") != "sshfling" or not job.get("name"):
            continue
        if exclude_name and job.get("name") == exclude_name:
            continue
        if detached_metadata_claims_active(job):
            jobs.append(job)
    return jobs


def load_detached_jobs(root):
    root = detached_root(root)
    jobs = []
    if not root.exists():
        return jobs
    for path in sorted(root.glob("*.json")):
        try:
            job = read_json_file(path)
        except (OSError, json.JSONDecodeError):
            continue
        if job.get("managed_by") != "sshfling" or not job.get("name"):
            continue
        job["metadata_path"] = str(path)
        jobs.append(refresh_detached_job(job))
    return jobs


def cmd_detached_start(args):
    seconds = lifetime_seconds(args, MAX_TIME_SECONDS)
    forced_context = sshfling_forced_session_context()
    if forced_context["forced"]:
        if not forced_context["allow_detached"]:
            raise SSHFlingError(
                "Refusing to start detached work from inside an SSH forced-command session. An administrator must add --allow-detached-start to the trusted sshfling-session ForceCommand only if this handoff is intentional.",
                75,
                source=forced_context.get("source"),
            )
        session_remaining = forced_context.get("remaining_seconds")
        if session_remaining is not None:
            if session_remaining < 1:
                raise SSHFlingError("The current sshfling SSH session is already expired.", 75)
            seconds = min(seconds, session_remaining)
    if seconds < 1:
        raise SSHFlingError("Detached job lifetime must be positive.", 2)
    if seconds > MAX_TIME_SECONDS:
        raise SSHFlingError(f"Detached job lifetime cannot exceed {format_duration(MAX_TIME_SECONDS)}.", 2)
    validate_detached_name(args.name)

    command = detached_command_from(args)
    paths = detached_paths(args.detached_dir, args.name)
    existing = read_json_file(paths["metadata"]) if paths["metadata"].exists() else None
    if existing:
        if detached_metadata_claims_active(existing):
            raise SSHFlingError(f"Detached job is already active: {args.name}", 2, pid=existing.get("pid"))
        existing = refresh_detached_job(existing)
        if existing.get("status") in {"starting", "processing"}:
            raise SSHFlingError(f"Detached job is already active: {args.name}", 2, pid=existing.get("pid"))
        if not args.replace:
            raise SSHFlingError(
                f"Detached job already exists: {args.name}. Use --replace after it is inactive.",
                2,
                status=existing.get("status"),
            )
    active_jobs = active_detached_job_claims(paths["root"], exclude_name=args.name)
    if len(active_jobs) >= MAX_DETACHED_JOBS:
        raise SSHFlingError(
            f"Maximum detached sshfling jobs reached ({MAX_DETACHED_JOBS}).",
            75,
            limit=MAX_DETACHED_JOBS,
            active=[job.get("name") for job in active_jobs],
        )

    root = paths["root"]
    root.mkdir(parents=True, exist_ok=True)
    try:
        root.chmod(0o700)
    except OSError:
        pass
    if existing and args.replace:
        for log_path in (paths["stdout"], paths["stderr"]):
            try:
                log_path.unlink()
            except FileNotFoundError:
                pass

    started_at = utc_timestamp()
    job = {
        "version": 1,
        "managed_by": "sshfling",
        "name": args.name,
        "status": "starting",
        "pid": None,
        "supervisor_pid": None,
        "command": command,
        "cwd": str(Path(args.cwd).expanduser().resolve()),
        "seconds": seconds,
        "started_at": started_at,
        "started_at_utc": utc_iso(started_at),
        "expires_at": started_at + seconds,
        "expires_at_utc": utc_iso(started_at + seconds),
        "metadata_path": str(paths["metadata"]),
        "stdout_path": str(paths["stdout"]),
        "stderr_path": str(paths["stderr"]),
    }
    write_json_atomic(paths["metadata"], job)

    supervisor_cmd = [
        sys.executable,
        str(Path(__file__).resolve()),
        "_detached-supervisor",
        "--metadata",
        str(paths["metadata"]),
        "--",
    ] + command
    try:
        supervisor = subprocess.Popen(
            supervisor_cmd,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
            **start_new_process_kwargs(detached=True),
        )
    except OSError as exc:
        job["status"] = "failed"
        job["error"] = str(exc)
        job["completed_at"] = utc_timestamp()
        job["completed_at_utc"] = utc_iso(job["completed_at"])
        write_json_atomic(paths["metadata"], job)
        raise SSHFlingError(f"Could not start detached supervisor: {exc}", 1) from exc

    deadline = time.time() + 5
    while time.time() < deadline:
        try:
            current = read_json_file(paths["metadata"])
        except (OSError, json.JSONDecodeError):
            current = job
        if current.get("pid") or current.get("status") not in {"starting", "processing"}:
            job = current
            break
        time.sleep(0.05)
    else:
        job = read_json_file(paths["metadata"])

    job = refresh_detached_job(job)
    if job.get("status") == "failed" and not job.get("pid"):
        error = job.get("error") or "detached command exited before it could start"
        raise SSHFlingError(f"Detached job failed to start: {error}", 1, job=job)

    payload = {"ok": True, "job": job}
    audit_log(
        "detached_job_started",
        name=job.get("name"),
        status=job.get("status"),
        pid=job.get("pid"),
        supervisor_pid=job.get("supervisor_pid"),
        seconds=job.get("seconds"),
        expires_at=job.get("expires_at"),
        forced_session=forced_context.get("forced"),
        forced_session_source=forced_context.get("source"),
    )
    if args.json:
        emit_json(payload)
    else:
        item = payload["job"]
        print(f"name: {item['name']}")
        print(f"status: {item['status']}")
        print(f"pid: {item.get('pid') or '-'}")
        print(f"supervisor-pid: {item.get('supervisor_pid') or '-'}")
        print(f"stdout: {item['stdout_path']}")
        print(f"stderr: {item['stderr_path']}")
    return 0


def cmd_detached_list(args):
    jobs = load_detached_jobs(args.detached_dir)
    if args.name:
        jobs = [job for job in jobs if job.get("name") == args.name]
    payload = {"ok": True, "jobs": jobs, "count": len(jobs)}
    if args.json:
        emit_json(payload)
    else:
        if not jobs:
            print("no detached sshfling jobs")
        else:
            print("name status pid supervisor-pid age max stdout")
            now = utc_timestamp()
            for job in jobs:
                age = max(0, now - int(job.get("started_at", now)))
                print(
                    f"{job.get('name', '-')} {job.get('status', '-')} {job.get('pid') or '-'} "
                    f"{job.get('supervisor_pid') or '-'} {age}s {job.get('seconds', '-')} {job.get('stdout_path', '-')}"
                )
    return 0


def cmd_detached_kill(args):
    paths = detached_paths(args.detached_dir, args.name)
    if not paths["metadata"].exists():
        raise SSHFlingError(f"Detached job does not exist: {args.name}", 2)
    job = read_json_file(paths["metadata"])
    targeted = []
    live_targets = []
    for pid_key in ["pid", "supervisor_pid"]:
        pid = job.get(pid_key)
        if not pid:
            continue
        pid = int(pid)
        if pid in targeted:
            continue
        targeted.append(pid)
        if process_exists(pid):
            live_targets.append(pid)
        terminate_detached_process(pid, force=False)

    deadline = time.time() + 2
    while time.time() < deadline:
        live = [pid for pid in targeted if process_exists(pid)]
        if not live:
            break
        time.sleep(0.1)

    remaining = [pid for pid in targeted if process_exists(pid)]
    for pid in remaining:
        terminate_detached_process(pid, force=True)

    job["status"] = "killed"
    job["killed_at"] = utc_timestamp()
    job["killed_at_utc"] = utc_iso(job["killed_at"])
    job["killed_pids"] = targeted
    job["live_pids_before_kill"] = live_targets
    write_json_atomic(paths["metadata"], job)
    payload = {"ok": True, "job": job, "killed": len(targeted), "pids": targeted}
    audit_log(
        "detached_job_killed",
        name=args.name,
        killed=payload["killed"],
        pids=targeted,
        live_pids_before_kill=live_targets,
    )
    if args.json:
        emit_json(payload)
    else:
        print(f"killed {payload['killed']} detached process(es)")
    return 0


def cmd_detached_supervisor(args):
    metadata_path = Path(args.metadata).expanduser().resolve()
    job = read_json_file(metadata_path)
    command = detached_command_from(args)
    job["supervisor_pid"] = os.getpid()
    write_json_atomic(metadata_path, job)
    stdout_path = Path(job["stdout_path"])
    stderr_path = Path(job["stderr_path"])
    stdout_path.parent.mkdir(parents=True, exist_ok=True)
    stderr_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        with stdout_path.open("ab", buffering=0) as stdout, stderr_path.open("ab", buffering=0) as stderr:
            try:
                proc = subprocess.Popen(
                    command,
                    cwd=job["cwd"],
                    stdin=subprocess.DEVNULL,
                    stdout=stdout,
                    stderr=stderr,
                    close_fds=True,
                    **start_new_process_kwargs(detached=False),
                )
            except OSError as exc:
                job.update(
                    {
                        "status": "failed",
                        "error": str(exc),
                        "supervisor_pid": os.getpid(),
                        "completed_at": utc_timestamp(),
                    }
                )
                job["completed_at_utc"] = utc_iso(job["completed_at"])
                write_json_atomic(metadata_path, job)
                return 127

            job["pid"] = proc.pid
            job["supervisor_pid"] = os.getpid()
            job["status"] = "processing"
            write_json_atomic(metadata_path, job)

            timed_out = False
            while proc.poll() is None:
                if utc_timestamp() >= int(job["expires_at"]):
                    timed_out = True
                    terminate_detached_process(proc.pid, force=False)
                    try:
                        proc.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        terminate_detached_process(proc.pid, force=True)
                    break
                time.sleep(0.5)

            exit_code = proc.wait()
            job["exit_code"] = exit_code
            job["completed_at"] = utc_timestamp()
            job["completed_at_utc"] = utc_iso(job["completed_at"])
            if timed_out:
                job["status"] = "timed_out"
            elif exit_code == 0:
                job["status"] = "completed"
            else:
                job["status"] = "failed"
            write_json_atomic(metadata_path, job)
            return 0
    except Exception as exc:
        try:
            job.update({"status": "failed", "error": str(exc), "completed_at": utc_timestamp()})
            job["completed_at_utc"] = utc_iso(job["completed_at"])
            write_json_atomic(metadata_path, job)
        except Exception:
            pass
        return 1


def write_if_changed(path, content, mode=0o644, dry_run=False):
    path = Path(path)
    reject_symlink_component(path, "write")
    if dry_run:
        return {"path": str(path), "changed": not path.exists() or path.read_text() != content, "dry_run": True}
    changed = not path.exists() or path.read_text() != content
    write_text_atomic(path, content, mode, "write")
    return {"path": str(path), "changed": changed}


def install_file(src, dst, mode=0o755, dry_run=False):
    src = Path(src)
    dst = Path(dst)
    reject_symlink_component(dst, "install")
    if dry_run:
        return {"path": str(dst), "source": str(src), "dry_run": True}
    write_bytes_atomic(dst, src.read_bytes(), mode, "install")
    return {"path": str(dst), "source": str(src)}


def install_managed_login_shell(session_wrapper, policy_file, destination, dry_run=False):
    wrapper = validate_forced_command_path(session_wrapper, "Session wrapper")
    policy = validate_forced_command_path(policy_file, "Policy file")
    bash = validate_forced_command_path(trusted_root_executable("bash"), "Bash executable")
    source = resource_file("production/sshfling-login-shell")
    template = source.read_text()
    assignments = (
        LOGIN_SHELL_WRAPPER_ASSIGNMENT,
        LOGIN_SHELL_POLICY_ASSIGNMENT,
        LOGIN_SHELL_BASH_ASSIGNMENT,
    )
    if any(template.count(assignment) != 1 for assignment in assignments):
        raise SSHFlingError("Managed login-shell template is missing a required assignment.", 2, path=str(source))
    rendered = template.replace(
        LOGIN_SHELL_WRAPPER_ASSIGNMENT,
        f"expected_wrapper={shlex.quote(wrapper)}",
    )
    rendered = rendered.replace(
        LOGIN_SHELL_POLICY_ASSIGNMENT,
        f"expected_policy={shlex.quote(policy)}",
    )
    rendered = rendered.replace(
        LOGIN_SHELL_BASH_ASSIGNMENT,
        f"expected_bash={shlex.quote(bash)}",
    )
    result = write_if_changed(destination, rendered, 0o755, dry_run)
    result["source"] = str(source)
    return result


def snapshot_file(path):
    path = Path(path)
    try:
        stat = path.stat()
    except FileNotFoundError:
        return {"exists": False}
    if path.is_dir():
        return {"exists": True, "directory": True}
    return {"exists": True, "content": path.read_bytes(), "mode": stat.st_mode & 0o7777}


def restore_file_snapshot(path, snapshot):
    path = Path(path)
    reject_symlink_component(path, "restore file snapshot")
    if snapshot.get("directory"):
        return {"path": str(path), "status": "left-directory"}
    if snapshot.get("exists"):
        path.parent.mkdir(parents=True, exist_ok=True)
        write_bytes_atomic(path, snapshot["content"], snapshot.get("mode", 0o644), "restore file snapshot")
        return {"path": str(path), "restored": True}
    if not path.exists():
        return {"path": str(path), "status": "missing"}
    if path.is_dir():
        return {"path": str(path), "status": "left-directory"}
    path.unlink()
    return {"path": str(path), "removed": True}


def reload_sshd():
    override = os.environ.get("SSHFLING_SSHD_RELOAD_CMD")
    attempts = []
    commands = []

    if override:
        commands.append(shlex.split(override))
    if command_path("systemctl"):
        commands.extend([["systemctl", "reload", "sshd"], ["systemctl", "reload", "ssh"]])
    if command_path("service"):
        commands.extend([["service", "sshd", "reload"], ["service", "ssh", "reload"]])
    if command_path("rc-service"):
        commands.extend([["rc-service", "sshd", "reload"], ["rc-service", "ssh", "reload"]])
    if command_path("rcctl"):
        commands.append(["rcctl", "reload", "sshd"])
    if command_path("pkill"):
        commands.append(["pkill", "-HUP", "sshd"])

    for command in commands:
        proc = run(command, capture=True, check=False)
        attempts.append({"command": shlex.join(command), "returncode": proc.returncode})
        if proc.returncode == 0:
            return {"reloaded": "sshd", "command": shlex.join(command), "attempts": attempts}

    raise SSHFlingError("Could not reload sshd automatically; reload sshd manually.", 127, attempts=attempts)


def sshd_configuration_files(root=Path("/etc/ssh/sshd_config")):
    root = Path(root)
    if not root.exists():
        return []
    queue = [root]
    files = []
    seen = set()
    while queue:
        path = queue.pop(0)
        try:
            path = path.resolve(strict=True)
        except OSError as exc:
            raise SSHFlingError(f"Could not resolve sshd configuration file: {path}", 2) from exc
        if path in seen:
            continue
        seen.add(path)
        if not path.is_file():
            continue
        files.append(path)
        try:
            lines = path.read_text().splitlines()
        except OSError as exc:
            raise SSHFlingError(f"Could not read sshd configuration file: {path}", 2) from exc
        for line_number, line in enumerate(lines, 1):
            try:
                fields = shlex.split(line, comments=True, posix=True)
            except ValueError as exc:
                raise SSHFlingError(
                    f"Could not parse sshd configuration include at {path}:{line_number}.",
                    2,
                ) from exc
            if not fields or fields[0].lower() != "include":
                continue
            for pattern in fields[1:]:
                include_pattern = Path(pattern)
                if not include_pattern.is_absolute():
                    include_pattern = root.parent / include_pattern
                queue.extend(Path(match) for match in sorted(glob.glob(str(include_pattern))))
    return files


def configured_accept_env_patterns():
    patterns = []
    for path in sshd_configuration_files():
        for line_number, line in enumerate(path.read_text().splitlines(), 1):
            fields = shlex.split(line, comments=True, posix=True)
            if fields and fields[0].lower() == "acceptenv":
                patterns.extend(
                    {"pattern": pattern, "source": str(path), "line": line_number}
                    for pattern in fields[1:]
                )
    return patterns


def dangerous_accept_env_matches(pattern_records):
    matches = []
    seen = set()
    for record in pattern_records:
        pattern = record["pattern"]
        variables = [
            variable
            for variable in DANGEROUS_SSH_ENVIRONMENT_NAMES
            if fnmatch.fnmatchcase(variable, pattern)
        ]
        if pattern.startswith("BASH_FUNC_"):
            variables.append("BASH_FUNC_*")
        for variable in variables:
            key = (pattern, variable, record.get("source"), record.get("line"))
            if key in seen:
                continue
            seen.add(key)
            matches.append({**record, "variable": variable})
    return matches


def validate_sshd_effective(
    username=None,
    expected_lines=None,
    config_hint=None,
    require_safe_environment=False,
):
    run(["sshd", "-t"], capture=True)
    result = {"validated": "sshd -t"}
    if not expected_lines and not require_safe_environment:
        return result

    proc = run(["sshd", "-T", "-C", f"user={username},host=localhost,addr=127.0.0.1"], capture=True)
    effective_lines = [line.strip() for line in proc.stdout.splitlines() if line.strip()]
    effective_normalized = {" ".join(line.lower().split()) for line in effective_lines}
    missing = [
        line for line in (expected_lines or [])
        if " ".join(line.strip().lower().split()) not in effective_normalized
    ]
    if missing:
        raise SSHFlingError(
            "sshd syntax is valid, but the sshfling Match configuration is not active. Ensure sshd_config includes the managed config path.",
            2,
            missing=missing,
            config=str(config_hint) if config_hint else None,
        )

    if require_safe_environment:
        permit_values = []
        accept_patterns = []
        for line in effective_lines:
            fields = line.split()
            if not fields:
                continue
            directive = fields[0].lower()
            if directive == "permituserenvironment":
                permit_values.extend(value.lower() for value in fields[1:])
            elif directive == "acceptenv":
                accept_patterns.extend(fields[1:])
        pattern_records = [
            {"pattern": pattern, "source": "sshd -T", "line": None}
            for pattern in accept_patterns
        ]
        pattern_records.extend(configured_accept_env_patterns())
        dangerous_matches = dangerous_accept_env_matches(pattern_records)
        if not permit_values or any(value != "no" for value in permit_values) or dangerous_matches:
            raise SSHFlingError(
                "Unsafe sshd environment policy for an SSHFling-managed session. Disable PermitUserEnvironment and remove dangerous AcceptEnv patterns before validating the install.",
                2,
                permit_user_environment=permit_values,
                dangerous_accept_env=dangerous_matches,
                config=str(config_hint) if config_hint else None,
            )
        result["validated_environment"] = "sshd -T"
    result["validated_effective"] = "sshd -T"
    return result


def password_grant_metadata_path(grant_dir, username):
    validate_unix_username(username)
    return Path(grant_dir).expanduser() / f"{username}.json"


def host_user_marker_path(marker_dir, username):
    validate_unix_username(username)
    return Path(marker_dir).expanduser() / f"{username}.json"


def write_host_user_marker(marker_dir, username, metadata, dry_run=False):
    path = host_user_marker_path(marker_dir, username)
    reject_symlink_component(path, "write host user marker")
    if dry_run:
        return {"path": str(path), "dry_run": True}
    path.parent.mkdir(parents=True, exist_ok=True)
    path.parent.chmod(0o700)
    write_text_atomic(path, json.dumps(metadata, indent=2, sort_keys=True) + "\n", 0o600, "write host user marker")
    return {"path": str(path), "host_user_marker": "written"}


def read_host_user_marker(marker_dir, username):
    path = host_user_marker_path(marker_dir, username)
    reject_symlink_component(path, "read host user marker")
    if not path.exists():
        return None, path
    try:
        metadata = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError) as exc:
        raise SSHFlingError(f"Invalid host user marker: {path}", 2) from exc
    return metadata, path


def delete_host_user(username, marker_dir=DEFAULT_HOST_USER_MARKER_DIR, dry_run=False):
    metadata, marker_path = read_host_user_marker(marker_dir, username)
    if (
        not metadata
        or metadata.get("managed_by") != "sshfling"
        or metadata.get("auth") != "certificate-host"
        or metadata.get("created_user") is not True
        or metadata.get("username") != username
    ):
        raise SSHFlingError(
            f"Refusing to delete Unix user {username!r} without a SSHFling-created host-user marker.",
            2,
            username=username,
            marker_path=str(marker_path),
        )
    reject_root_equivalent_user_deletion(username, "delete")
    result = delete_password_user(username, dry_run, expected_identity=expected_unix_identity(metadata))
    result["marker_path"] = str(marker_path)
    removable_marker = bool(
        result.get("deleted")
        or result.get("would_delete")
        or result.get("status") == "missing"
    )
    if not removable_marker:
        result["marker_preserved"] = True
        return result
    if dry_run:
        result["would_remove_marker"] = True
    else:
        marker_path.unlink(missing_ok=True)
        result["removed_marker"] = True
    return result


def read_password_grant_metadata(grant_dir, username):
    path = password_grant_metadata_path(grant_dir, username)
    if not path.exists():
        return None
    return json.loads(path.read_text())


def write_password_grant_metadata(grant_dir, username, metadata, dry_run=False):
    path = password_grant_metadata_path(grant_dir, username)
    reject_symlink_component(path, "write password grant metadata")
    if dry_run:
        return {"path": str(path), "dry_run": True}
    path.parent.mkdir(parents=True, exist_ok=True)
    path.parent.chmod(0o700)
    write_text_atomic(path, json.dumps(metadata, indent=2, sort_keys=True) + "\n", 0o600, "write password grant metadata")
    return {"path": str(path), "metadata": "written"}


def remove_password_grant_config(path, username, dry_run=False):
    path = Path(path)
    reject_symlink_component(path, "remove password grant config")
    if not path.exists():
        return {"path": str(path), "status": "missing"}
    content = path.read_text()
    marker = f"# Managed by sshfling password grant for {username}."
    if marker not in content:
        raise SSHFlingError(f"Refusing to remove unmanaged sshd config: {path}", 2)
    if dry_run:
        return {"path": str(path), "would_remove": True, "dry_run": True}
    path.unlink()
    return {"path": str(path), "removed": True}


def remove_file(path, dry_run=False):
    path = Path(path)
    reject_symlink_component(path, "remove file")
    if not path.exists():
        return {"path": str(path), "status": "missing"}
    if path.is_dir():
        raise SSHFlingError(f"Refusing to remove directory as a file: {path}", 2)
    if dry_run:
        return {"path": str(path), "would_remove": True, "dry_run": True}
    path.unlink()
    return {"path": str(path), "removed": True}


def remove_managed_file(path, marker, dry_run=False, force=False):
    path = Path(path)
    if not path.exists():
        return {"path": str(path), "status": "missing"}
    content = path.read_text()
    if marker not in content and not force:
        raise SSHFlingError(f"Refusing to remove unmanaged file: {path}", 2)
    return remove_file(path, dry_run)


def remove_matching_file(path, expected_content, dry_run=False, force=False):
    path = Path(path)
    if not path.exists():
        return {"path": str(path), "status": "missing"}
    content = path.read_text()
    if content != expected_content and not force:
        raise SSHFlingError(
            f"Refusing to remove file with unexpected content: {path}. Re-run with matching --principal values or --force.",
            2,
        )
    return remove_file(path, dry_run)


def remove_empty_dir(path, dry_run=False):
    path = Path(path)
    if not path.exists():
        return {"path": str(path), "status": "missing"}
    if not path.is_dir():
        return {"path": str(path), "status": "not-directory"}
    if any(path.iterdir()):
        return {"path": str(path), "status": "not-empty"}
    if dry_run:
        return {"path": str(path), "would_remove_empty_dir": True, "dry_run": True}
    try:
        path.rmdir()
        return {"path": str(path), "removed_empty_dir": True}
    except OSError:
        return {"path": str(path), "status": "not-empty"}


def remove_policy_user(policy_file, username, dry_run=False):
    path = policy_file_path(policy_file)
    reject_symlink_component(path, "update policy")
    if not path.exists():
        return {"path": str(path), "status": "missing"}

    try:
        data = json.loads(path.read_text())
    except json.JSONDecodeError as exc:
        raise SSHFlingError(f"Invalid policy file: {path}", 2) from exc

    policy = normalize_policy(data)
    if username not in policy.get("users", {}):
        return {"path": str(path), "user": username, "status": "missing"}

    if dry_run:
        return {"path": str(path), "user": username, "would_remove": True, "dry_run": True}

    del policy["users"][username]
    write_text_atomic(path, json.dumps(policy, indent=2, sort_keys=True) + "\n", 0o644, "update policy")
    return {"path": str(path), "user": username, "removed": True}


def lock_password_user(username, dry_run=False, expected_identity=None):
    reject_root_equivalent_user_deletion(username, "lock")
    if not unix_user_exists(username):
        return {"user": username, "status": "missing"}
    mismatch = unix_identity_mismatch(username, expected_identity)
    if mismatch:
        return {"user": username, "status": "skipped-user-mismatch", **mismatch}
    if dry_run:
        return {"user": username, "would_lock": True, "dry_run": True}

    proc, records = run_native_linux_account("lock", username, check=False)
    attempts = native_attempts(records, username)
    if proc.returncode != 0:
        raise SSHFlingError(f"Could not lock expired password user: {username}", proc.returncode, attempts=attempts)
    result = native_result_for_user(records, "lock", username)
    locked = native_result_flag(result, "locked", "lock")
    expired = native_result_flag(result, "expired", "lock")
    if result.get("status") != "locked" or not locked:
        raise SSHFlingError("Native Linux account backend returned an invalid lock result.", 1)
    return {
        "user": username,
        "locked": locked,
        "expired": expired,
        "attempts": attempts,
    }


def delete_password_user(username, dry_run=False, expected_identity=None):
    reject_root_equivalent_user_deletion(username, "delete")
    if not unix_user_exists(username):
        return {"user": username, "status": "missing"}
    mismatch = unix_identity_mismatch(username, expected_identity)
    if mismatch:
        return {"user": username, "status": "skipped-user-mismatch", **mismatch}
    if dry_run:
        return {"user": username, "would_delete": True, "dry_run": True}
    proc, records = run_native_linux_account("delete", username, check=False)
    if proc.returncode != 0:
        raise SSHFlingError(f"Could not delete password user: {username}", proc.returncode, stderr=proc.stderr)
    result = native_result_for_user(records, "delete", username)
    deleted = native_result_flag(result, "deleted", "delete")
    if result.get("status") != "deleted" or not deleted:
        raise SSHFlingError("Native Linux account backend returned an invalid delete result.", 1)
    return {"user": username, "deleted": deleted}


def rollback_delete_created_user(username, expected_identity=None):
    result = delete_password_user(username, expected_identity=expected_identity)
    if result.get("deleted") is True or result.get("status") == "missing":
        return result
    raise SSHFlingError(
        f"Rollback could not confirm deletion of created Unix user: {username}",
        1,
        delete_result=result,
    )


def cleanup_password_grant_sessions(username, dry_run=False):
    if not command_path("ps"):
        return {"username": username, "status": "unsupported", "reason": "ps is required to inspect active sessions"}
    if dry_run:
        sessions = find_sshfling_sessions(session_username=username)
        return {
            "username": username,
            "would_kill": len(sessions),
            "pids": [session["pid"] for session in sessions],
            "dry_run": True,
        }
    result = kill_sshfling_sessions(session_username=username)
    result["username"] = username
    return result


def prune_password_grants(grant_dir, username=None, all_grants=False, delete_users=False, dry_run=False):
    if bool(username) == bool(all_grants):
        raise SSHFlingError("Use exactly one of --username or --all for password prune.", 2)
    now = int(time.time())
    root = Path(grant_dir).expanduser()
    if username:
        validate_unix_username(username)
        paths = [password_grant_metadata_path(root, username)]
    elif root.exists():
        paths = sorted(root.glob("*.json"))
    else:
        paths = []

    results = []
    for path in paths:
        if not path.exists():
            results.append({"metadata_path": str(path), "status": "missing"})
            continue

        try:
            metadata = json.loads(path.read_text())
        except (OSError, json.JSONDecodeError):
            results.append({"metadata_path": str(path), "status": "skipped-invalid-metadata"})
            continue
        grant_username = metadata.get("username") or path.stem
        try:
            validate_unix_username(grant_username)
        except SSHFlingError:
            results.append({"metadata_path": str(path), "username": str(grant_username), "status": "skipped-invalid-username"})
            continue
        if metadata.get("managed_by") != "sshfling" or metadata.get("auth") != "password":
            results.append(
                {
                    "metadata_path": str(path),
                    "username": grant_username,
                    "status": "skipped-unmanaged",
                }
            )
            continue
        if path.stem != grant_username:
            results.append(
                {
                    "metadata_path": str(path),
                    "username": grant_username,
                    "status": "skipped-unmanaged",
                    "reason": "metadata username does not match file name",
                }
            )
            continue
        if is_root_equivalent_user(grant_username):
            results.append(
                {
                    "metadata_path": str(path),
                    "username": grant_username,
                    "status": "skipped-root-equivalent",
                    "reason": "refusing to mutate root-equivalent Unix user from password grant metadata",
                }
            )
            continue
        try:
            expires_at = int(metadata["expires_at"])
        except (KeyError, TypeError, ValueError):
            results.append({"metadata_path": str(path), "username": grant_username, "status": "skipped-invalid-metadata"})
            continue
        if expires_at < 1:
            results.append({"metadata_path": str(path), "username": grant_username, "status": "skipped-invalid-metadata"})
            continue
        if expires_at > now:
            results.append({"metadata_path": str(path), "username": grant_username, "status": "active", "expires_at": expires_at})
            continue

        item = {"metadata_path": str(path), "username": grant_username, "expires_at": expires_at, "status": "pruned"}
        expected_identity = expected_unix_identity(metadata)
        current_identity = unix_user_identity(grant_username)
        if expected_identity and current_identity:
            mismatch = unix_identity_mismatch(grant_username, expected_identity)
            if mismatch:
                item["status"] = "skipped-user-mismatch"
                item["user"] = {"user": grant_username, "status": "skipped-user-mismatch", **mismatch}
                item["reason"] = "current Unix account identity does not match SSHFling grant metadata"
                results.append(item)
                continue
        if (
            delete_users
            and metadata.get("created_user") is True
            and expected_identity
            and current_identity
            and not dry_run
            and not command_path("userdel")
        ):
            item["status"] = "skipped-delete-prerequisite"
            item["reason"] = "userdel is required before removing managed sshd config for --delete-users"
            results.append(item)
            continue
        config_path = metadata.get("config_path")
        config_verified_for_removal = False
        if config_path:
            item["config"] = remove_password_grant_config(config_path, grant_username, dry_run)
            config_verified_for_removal = bool(
                item["config"].get("removed")
                or item["config"].get("would_remove")
                or item["config"].get("status") == "missing"
            )

        item["sessions"] = cleanup_password_grant_sessions(grant_username, dry_run)
        if metadata.get("created_user") is True:
            if delete_users and config_verified_for_removal:
                if expected_identity:
                    item["user"] = delete_password_user(grant_username, dry_run, expected_identity=expected_identity)
                else:
                    item["user"] = lock_password_user(grant_username, dry_run, expected_identity=expected_identity)
                    item["user"]["delete_skipped"] = "Unix identity evidence is required before deleting an SSHFling-created user"
            else:
                item["user"] = lock_password_user(grant_username, dry_run, expected_identity=expected_identity)
                if delete_users:
                    item["user"]["delete_skipped"] = "managed sshd config was not verified for removal"
        else:
            item["user"] = lock_password_user(grant_username, dry_run, expected_identity=expected_identity)
            item["user"]["existing_user"] = True
            if delete_users:
                item["user"]["delete_skipped"] = "existing Unix user was not created by sshfling"

        if dry_run:
            item["metadata"] = {"path": str(path), "would_remove": True, "dry_run": True}
        else:
            path.unlink()
            item["metadata"] = {"path": str(path), "removed": True}
        results.append(item)
    return results


def cmd_password_prune(args):
    require_root("password prune")
    grant_results = prune_password_grants(
        args.password_grant_dir,
        username=args.username,
        all_grants=args.all,
        delete_users=args.delete_users,
        dry_run=args.dry_run,
    )
    results = list(grant_results)
    if not args.dry_run and any(item.get("config", {}).get("removed") for item in grant_results):
        results.append(reload_sshd())

    payload = {"ok": True, "results": results, "count": len(grant_results)}
    audit_log(
        "password_grants_pruned",
        username=args.username,
        all_grants=args.all,
        delete_users=args.delete_users,
        dry_run=args.dry_run,
        count=len(grant_results),
    )
    if args.json:
        emit_json(payload)
    else:
        if not grant_results:
            print("no password grants to prune")
        for item in grant_results:
            print(json.dumps(item, sort_keys=True))
    return 0


def cmd_host_install(args):
    require_root("host install")
    require_native_policy_parser(args.dry_run)
    require_native_session_lock_tool(args.dry_run)
    require_native_identity_backend()
    if args.create_user:
        require_certificate_user_tools(args.dry_run)
    validate_unix_username(args.user)
    ca_pub = Path(args.ca_pub).expanduser().resolve()
    if not ca_pub.exists():
        raise SSHFlingError(f"CA public key does not exist: {ca_pub}", 2)

    trusted_ca = Path(args.trusted_ca).expanduser()
    principals_dir = Path(args.principals_dir).expanduser()
    principals_file = principals_dir / args.user
    wrapper_path = Path(args.session_wrapper).expanduser().resolve()
    validate_forced_command_path(wrapper_path, "Session wrapper")
    login_shell_path = managed_login_shell_path(wrapper_path)
    managed_policy_path = policy_file_path(args.policy_file)
    validate_forced_command_path(managed_policy_path, "Policy file")
    sshd_config = Path(args.sshd_config).expanduser()
    host_user_marker_dir = getattr(args, "host_user_marker_dir", DEFAULT_HOST_USER_MARKER_DIR)
    marker_path = host_user_marker_path(host_user_marker_dir, args.user)
    principals = [validate_certificate_principal(principal) for principal in (args.principal or [args.user])]
    principal_lines = "\n".join(dict.fromkeys(principals)) + "\n"

    config = f"""# Managed by sshfling.
TrustedUserCAKeys {trusted_ca}
ExposeAuthInfo yes

Match User {args.user}
    AuthorizedPrincipalsFile {principals_dir}/%u
    AuthorizedKeysFile none
    PasswordAuthentication no
    KbdInteractiveAuthentication no
    AuthenticationMethods publickey
    AllowTcpForwarding no
    AllowAgentForwarding no
    AllowStreamLocalForwarding no
    PermitOpen none
    PermitListen none
    X11Forwarding no
    PermitTunnel no
"""

    prepare_root_managed_parent(wrapper_path, "install forced-session executables", args.dry_run)
    rollback_paths = [wrapper_path, login_shell_path, trusted_ca, principals_file, sshd_config]
    requested_access_level = getattr(args, "access_level", None)
    installed_access_level = None
    if args.max_time or args.max_connections or requested_access_level:
        rollback_paths.append(managed_policy_path)
    if args.create_user:
        rollback_paths.append(marker_path)
    for managed_path in rollback_paths:
        reject_symlink_component(managed_path, "manage host install path")
    require_sshd_for_validation(args.validate, args.dry_run)
    rollback_snapshots = [] if args.dry_run else [(path, snapshot_file(path)) for path in rollback_paths]
    created_user_for_rollback = False
    created_identity = None

    results = []
    try:
        results.append(install_file(resource_file("production/sshfling-session"), wrapper_path, 0o755, args.dry_run))
        results.append(
            install_managed_login_shell(
                wrapper_path,
                managed_policy_path,
                login_shell_path,
                args.dry_run,
            )
        )
        results.append(write_if_changed(trusted_ca, ca_pub.read_text(), 0o644, args.dry_run))
        results.append(write_if_changed(principals_file, principal_lines, 0o644, args.dry_run))
        results.append(write_if_changed(sshd_config, config, 0o644, args.dry_run))
        if args.max_time or args.max_connections or requested_access_level:
            current = load_policy(args.policy_file)
            current_user_policy = effective_policy(current, args.user)
            max_time = args.max_time if args.max_time else current_user_policy["max_time_seconds"]
            max_connections = args.max_connections if args.max_connections else current_user_policy["max_connections"]
            access_level = requested_access_level if requested_access_level else current_user_policy["access_level"]
            access_level = validate_access_level_for_username(args.user, access_level)
            installed_access_level = access_level
            if args.dry_run:
                results.append({
                    "path": str(policy_file_path(args.policy_file)),
                    "dry_run": True,
                    "user": args.user,
                    "max_time_seconds": max_time,
                    "max_connections": max_connections,
                    "access_level": access_level,
                })
            else:
                results.append(write_policy(args.policy_file, max_time, max_connections, args.user, access_level))

        if args.create_user and not args.dry_run:
            if not unix_user_exists(args.user):
                _, records = run_native_linux_account(
                    "create-certificate-user",
                    args.user,
                    str(login_shell_path),
                )
                create_result = native_result_for_user(records, "create-certificate-user", args.user)
                created_user_for_rollback = native_result_flag(
                    create_result,
                    "created",
                    "create-certificate-user",
                )
                expected_status = "created" if created_user_for_rollback else "present"
                if create_result.get("status") != expected_status:
                    raise SSHFlingError(
                        "Native Linux account backend returned an invalid certificate-user create result.",
                        1,
                    )
                if created_user_for_rollback:
                    unlocked = native_result_flag(
                        create_result,
                        "unlocked",
                        "create-certificate-user",
                    )
                    if not unlocked:
                        raise SSHFlingError(
                            "Native Linux account backend did not unlock the created certificate user.",
                            1,
                        )
                    if create_result.get("shell") != str(login_shell_path):
                        raise SSHFlingError(
                            "Native Linux account backend created the certificate user with the wrong login shell.",
                            1,
                        )
                created_identity = (
                    native_identity_from_result(create_result, args.user)
                    if created_user_for_rollback
                    else unix_user_identity(args.user)
                )
                if created_user_for_rollback:
                    marker = {
                        "version": 1,
                        "managed_by": "sshfling",
                        "auth": "certificate-host",
                        "username": args.user,
                        "created_user": True,
                        "created_at": int(time.time()),
                        "created_at_utc": utc_iso(),
                        "managed_login_shell": str(login_shell_path),
                        **unix_identity_metadata(created_identity),
                    }
                    results.append(write_host_user_marker(host_user_marker_dir, args.user, marker))
                    results.append({"created_user": args.user})
                else:
                    results.append({"user": args.user, "created": False, "status": "present"})

        if args.dry_run:
            results.append(provision_session_locks(wrapper_path, args.user, dry_run=True))
        else:
            session_identity = created_identity or unix_user_identity(args.user)
            if not session_identity:
                raise SSHFlingError(
                    f"Cannot provision forced-session locks for missing Unix user: {args.user}",
                    1,
                )
            results.append(
                provision_session_locks(
                    wrapper_path,
                    args.user,
                    expected_identity=session_identity,
                )
            )

        if not args.dry_run and args.validate:
            results.append(
                validate_sshd_effective(
                    args.user,
                    [
                        f"trustedusercakeys {trusted_ca}",
                        f"authorizedprincipalsfile {principals_dir}/%u",
                        "passwordauthentication no",
                        "authenticationmethods publickey",
                        "allowtcpforwarding no",
                        "allowagentforwarding no",
                        "allowstreamlocalforwarding no",
                        "permitopen none",
                        "permitlisten none",
                    ],
                    sshd_config,
                    require_safe_environment=True,
                )
            )

        if not args.dry_run and args.reload:
            results.append(reload_sshd())
    except Exception as exc:
        rollback = []
        if not args.dry_run:
            preserve_rollback_paths = set()
            cleanup_failure = native_created_user_cleanup_failure(
                exc,
                args.user,
                "create-certificate-user",
            )
            if cleanup_failure:
                preserve_rollback_paths.update({wrapper_path, login_shell_path, sshd_config})
                if managed_policy_path in rollback_paths:
                    preserve_rollback_paths.add(managed_policy_path)
                rollback.append({
                    "user": args.user,
                    "status": "preserved",
                    "reason": "native account helper could not confirm cleanup of the created user",
                    "native_result": cleanup_failure,
                })
            elif created_user_for_rollback:
                try:
                    rollback.append(rollback_delete_created_user(args.user, created_identity))
                except Exception as rollback_exc:
                    preserve_rollback_paths.update(
                        {wrapper_path, login_shell_path, sshd_config, marker_path}
                    )
                    if managed_policy_path in rollback_paths:
                        preserve_rollback_paths.add(managed_policy_path)
                    message = rollback_exc.message if isinstance(rollback_exc, SSHFlingError) else str(rollback_exc)
                    rollback.append({"user": args.user, "rollback_error": message})
            for path, snapshot in reversed(rollback_snapshots):
                if path in preserve_rollback_paths:
                    rollback.append({
                        "path": str(path),
                        "status": "preserved",
                        "reason": "created user could not be deleted",
                    })
                    continue
                try:
                    rollback.append(restore_file_snapshot(path, snapshot))
                except Exception as rollback_exc:
                    rollback.append({"path": str(path), "rollback_error": str(rollback_exc)})
        if isinstance(exc, SSHFlingError):
            exc.details["rollback"] = rollback
        raise

    payload = {"ok": True, "results": results}
    audit_log(
        "host_config_installed",
        login_user=args.user,
        principals=principals,
        trusted_ca=trusted_ca,
        principals_file=principals_file,
        sshd_config=sshd_config,
        session_wrapper=wrapper_path,
        access_level=installed_access_level,
        requested_access_level=requested_access_level,
        dry_run=args.dry_run,
        reload=args.reload,
    )
    if args.json:
        emit_json(payload)
    else:
        for item in results:
            print(json.dumps(item, sort_keys=True))
    return 0


def cmd_host_uninstall(args):
    require_root("host uninstall")
    validate_unix_username(args.user)
    trusted_ca = Path(args.trusted_ca).expanduser()
    principals_dir = Path(args.principals_dir).expanduser()
    principals_file = principals_dir / args.user
    wrapper_path = Path(args.session_wrapper).expanduser()
    sshd_config = Path(args.sshd_config).expanduser()
    principals = [validate_certificate_principal(principal) for principal in (args.principal or [args.user])]
    principal_lines = "\n".join(dict.fromkeys(principals)) + "\n"

    results = [
        remove_managed_file(sshd_config, "# Managed by sshfling.", args.dry_run, args.force),
        remove_matching_file(principals_file, principal_lines, args.dry_run, args.force),
        remove_empty_dir(principals_dir, args.dry_run),
    ]

    if args.remove_ca:
        results.append(remove_file(trusted_ca, args.dry_run))
    if args.remove_wrapper:
        results.append(remove_file(wrapper_path, args.dry_run))
    if args.remove_policy_user:
        results.append(remove_policy_user(args.policy_file, args.user, args.dry_run))
    if args.delete_user:
        results.append(delete_host_user(args.user, getattr(args, "host_user_marker_dir", DEFAULT_HOST_USER_MARKER_DIR), args.dry_run))

    if not args.dry_run and args.validate:
        results.append(validate_sshd_effective())

    if not args.dry_run and args.reload:
        results.append(reload_sshd())

    payload = {"ok": True, "results": results}
    audit_log(
        "host_config_uninstalled",
        login_user=args.user,
        principals=principals,
        remove_ca=args.remove_ca,
        remove_wrapper=args.remove_wrapper,
        remove_policy_user=args.remove_policy_user,
        delete_user=args.delete_user,
        dry_run=args.dry_run,
        reload=args.reload,
    )
    if args.json:
        emit_json(payload)
    else:
        for item in results:
            print(json.dumps(item, sort_keys=True))
    return 0


class IssuerHandler(http.server.BaseHTTPRequestHandler):
    server_version = "sshflingd/0.1"

    def send_json(self, status, payload):
        body = json.dumps(payload, sort_keys=True).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/healthz":
            self.send_json(200, {"ok": True, "service": "sshflingd", "version": VERSION})
            return
        self.send_json(404, {"ok": False, "error": "not found"})

    def do_POST(self):
        if self.path != "/v1/certificates":
            self.send_json(404, {"ok": False, "error": "not found"})
            return

        if not rate_limit_allowed(self.server, "issuer", remote_addr(self), ISSUER_POST_RATE_LIMIT, RATE_LIMIT_WINDOW_SECONDS):
            self.send_json(429, {"ok": False, "error": "too many requests"})
            return

        expected = self.server.auth_token
        actual = self.headers.get("Authorization", "")
        if not bearer_token_matches(actual, expected):
            self.send_json(401, {"ok": False, "error": "unauthorized"})
            return

        try:
            body_bytes = read_http_body(self, MAX_HTTP_BODY_BYTES)
            if not body_bytes:
                raise SSHFlingError("Missing request body.", 400)
            body = body_bytes.decode("utf-8")
            request = json.loads(body)
            principal = request.get("principal")
            seconds = int(request.get("seconds", self.server.default_seconds))
            if principal not in self.server.allowed_principals:
                raise SSHFlingError(f"Principal is not allowed: {principal}", 403)
            if seconds > self.server.max_seconds:
                raise SSHFlingError(f"Requested seconds exceeds max_seconds={self.server.max_seconds}", 400)
            public_key = request.get("public_key", "").strip()
            if not public_key:
                raise SSHFlingError("Missing public_key.", 400)
            if "login_user" in request and request.get("login_user") not in (None, "", principal):
                raise SSHFlingError("login_user cannot be set through the issuer API.", 400)

            result = sign_user_certificate(
                ca_key=self.server.ca_key,
                public_key_text=public_key,
                principal=principal,
                seconds=seconds,
                key_id=request.get("key_id"),
                source_address=request.get("source_address"),
                session_wrapper=self.server.session_wrapper,
                policy_file=self.server.policy_file,
                login_user=principal,
                permit_pty=bool(request.get("permit_pty", True)),
            )
            audit_log(
                "access_grant_created",
                auth="certificate",
                via="issuer-api",
                remote_addr=remote_addr(self),
                principal=result["principal"],
                login_user=principal,
                seconds=result["seconds"],
                valid_before=result["valid_before"],
                key_id=result["key_id"],
                serial=result["serial"],
                source_address=request.get("source_address"),
                permit_pty=bool(request.get("permit_pty", True)),
                access_level=result["access_level"],
            )
            self.send_json(200, result)
        except SSHFlingError as exc:
            self.send_json(exc.code if exc.code >= 100 else 400, {"ok": False, "error": exc.message})
        except (json.JSONDecodeError, UnicodeDecodeError, ValueError):
            self.send_json(400, {"ok": False, "error": "invalid request"})
        except Exception:
            self.send_json(500, {"ok": False, "error": "internal server error"})

    def log_message(self, fmt, *args):
        eprint(f"{self.address_string()} - {fmt % args}")


def cmd_serve(args):
    policy = load_policy(args.policy_file)
    default_policy_caps = effective_policy(policy)
    token = validate_bearer_token(args.token or os.environ.get(args.token_env), args.token_env)
    if args.max_seconds > default_policy_caps["max_time_seconds"]:
        raise SSHFlingError(f"Maximum issuer lifetime cannot exceed {format_duration(default_policy_caps['max_time_seconds'])}.", 2)
    if args.default_seconds > args.max_seconds:
        raise SSHFlingError("--default-seconds cannot exceed --max-seconds.", 2)

    if ":" not in args.listen:
        raise SSHFlingError("--listen must be host:port.", 2)
    host, port_text = args.listen.rsplit(":", 1)
    allow_remote = args.allow_remote or env_truthy("SSHFLING_ALLOW_REMOTE")
    if not is_loopback_host(host) and not allow_remote:
        raise SSHFlingError("Refusing non-local issuer bind without --allow-remote or SSHFLING_ALLOW_REMOTE=1.", 2)
    port = int(port_text)

    allowed = set()
    for raw in args.allowed_principal:
        allowed.update(validate_certificate_principal(part.strip()) for part in raw.split(",") if part.strip())
    if not allowed:
        raise SSHFlingError("At least one --allowed-principal is required.", 2)

    server = http.server.ThreadingHTTPServer((host, port), IssuerHandler)
    server.auth_token = token
    server.ca_key = str(Path(args.ca_key).expanduser().resolve())
    server.allowed_principals = allowed
    server.max_seconds = args.max_seconds
    server.default_seconds = args.default_seconds
    server.session_wrapper = args.session_wrapper
    server.policy_file = policy["path"]
    server.rate_limits = {}
    server.rate_limit_lock = threading.Lock()

    audit_log(
        "issuer_service_started",
        listen_host=host,
        listen_port=port,
        allow_remote=allow_remote,
        allowed_principals=sorted(allowed),
        max_seconds=args.max_seconds,
        default_seconds=args.default_seconds,
        policy_file=policy["path"],
    )
    eprint(f"sshflingd listening on {host}:{port}; allowed principals: {', '.join(sorted(allowed))}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        return 130
    return 0


def b64url(data):
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def b64url_decode(value):
    padding = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode((value + padding).encode("ascii"))


def make_password_hash(password, iterations=260000):
    salt = secrets.token_urlsafe(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), iterations)
    return f"pbkdf2_sha256${iterations}${salt}${b64url(digest)}"


def verify_web_password(password, password_hash=None, plain_password=None):
    if password_hash:
        try:
            scheme, iterations, salt, expected = password_hash.split("$", 3)
            if scheme != "pbkdf2_sha256":
                return False
            digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), int(iterations))
            return hmac.compare_digest(b64url(digest), expected)
        except Exception:
            return False
    if plain_password is not None:
        return hmac.compare_digest(password, plain_password)
    return False


def make_web_session(user, secret, max_age=28800):
    payload = {
        "user": user,
        "exp": int(time.time()) + max_age,
        "csrf": secrets.token_urlsafe(24),
    }
    body = b64url(json.dumps(payload, separators=(",", ":")).encode("utf-8"))
    sig = b64url(hmac.new(secret, body.encode("ascii"), hashlib.sha256).digest())
    return f"{body}.{sig}"


def verify_web_session(token, secret):
    try:
        body, sig = token.split(".", 1)
        expected = b64url(hmac.new(secret, body.encode("ascii"), hashlib.sha256).digest())
        if not hmac.compare_digest(sig, expected):
            return None
        payload = json.loads(b64url_decode(body).decode("utf-8"))
        if int(payload.get("exp", 0)) < int(time.time()):
            return None
        return payload
    except Exception:
        return None


def parse_cookie(header):
    cookies = {}
    for part in (header or "").split(";"):
        if "=" in part:
            key, value = part.strip().split("=", 1)
            cookies[key] = value
    return cookies


def web_session_cookie(value, max_age, secure=False):
    secure_attr = "; Secure" if secure else ""
    return f"sshfling_web={value}; Path=/; HttpOnly; SameSite=Strict{secure_attr}; Max-Age={max_age}"


def render_web_page(title, body):
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{html.escape(title)}</title>
  <style>
    body {{ margin: 0; font: 14px/1.45 system-ui, -apple-system, Segoe UI, sans-serif; color: #172026; background: #f5f7f8; }}
    header {{ display: flex; align-items: center; justify-content: space-between; padding: 14px 20px; background: #172026; color: white; }}
    main {{ max-width: 1040px; margin: 0 auto; padding: 20px; }}
    h1 {{ margin: 0; font-size: 18px; font-weight: 650; }}
    h2 {{ margin: 0 0 12px; font-size: 15px; }}
    section, .login {{ background: white; border: 1px solid #d8e0e5; border-radius: 6px; padding: 16px; margin-bottom: 16px; }}
    label {{ display: block; font-weight: 600; margin: 10px 0 4px; }}
    input, select {{ box-sizing: border-box; width: 100%; max-width: 320px; padding: 8px 10px; border: 1px solid #b8c4cc; border-radius: 4px; font: inherit; }}
    button {{ padding: 8px 12px; border: 1px solid #172026; border-radius: 4px; background: #172026; color: white; font: inherit; cursor: pointer; }}
    button.secondary {{ background: white; color: #172026; }}
    table {{ width: 100%; border-collapse: collapse; }}
    th, td {{ padding: 8px; border-bottom: 1px solid #e4eaee; text-align: left; }}
    th {{ font-size: 12px; color: #4d5c66; text-transform: uppercase; }}
    .row {{ display: flex; gap: 12px; flex-wrap: wrap; align-items: end; }}
    .notice {{ color: #31516b; margin-bottom: 12px; }}
    .error {{ color: #9b1c1c; margin-bottom: 12px; }}
    .inline {{ display: inline; }}
    .inline input {{ width: auto; }}
  </style>
</head>
<body>
  <header><h1>SSHFling</h1></header>
  <main>{body}</main>
</body>
</html>
"""


def render_login(error=""):
    error_html = f"<div class=\"error\">{html.escape(error)}</div>" if error else ""
    return render_web_page(
        "SSHFling Login",
        f"""<div class="login">
  <h2>Login</h2>
  {error_html}
  <form method="post" action="/login">
    <label for="username">Username</label>
    <input id="username" name="username" autocomplete="username" required>
    <label for="password">Password</label>
    <input id="password" name="password" type="password" autocomplete="current-password" required>
    <p><button type="submit">Login</button></p>
  </form>
</div>""",
    )


def render_dashboard(policy, sessions, csrf, message=""):
    default_caps = effective_policy(policy)
    user_rows = []
    for username, caps in sorted(policy.get("users", {}).items()):
        user_rows.append(
            f"<tr><td>{html.escape(username)}</td><td>{format_duration(caps['max_time_seconds'])}</td><td>{caps['max_connections']}</td><td>{html.escape(access_level_label(caps['access_level']))}</td></tr>"
        )
    user_table = "".join(user_rows) or "<tr><td colspan=\"4\">No user overrides</td></tr>"

    session_rows = []
    for session in sessions:
        username = html.escape(session.get("username") or "-")
        process_pid = session.get("process_pid")
        process_pid = process_pid if process_pid is not None else "-"
        max_seconds = session["max_seconds"] if session["max_seconds"] is not None else "-"
        session_rows.append(
            f"""<tr>
  <td>{username}</td><td>{session['pid']}</td><td>{process_pid}</td><td>{session['uid']}</td><td>{session['age_seconds']}s</td><td>{max_seconds}</td>
  <td><form class="inline" method="post" action="/kill"><input type="hidden" name="csrf" value="{html.escape(csrf)}"><input type="hidden" name="username" value="{username}"><button type="submit">Kill</button></form></td>
</tr>"""
        )
    sessions_table = "".join(session_rows) or "<tr><td colspan=\"7\">No active sessions</td></tr>"
    message_html = f"<div class=\"notice\">{html.escape(message)}</div>" if message else ""

    return render_web_page(
        "SSHFling",
        f"""{message_html}
<section>
  <h2>Policy</h2>
  <table>
    <tr><th>User</th><th>Max Time</th><th>Max Connections</th><th>Access Level</th></tr>
    <tr><td>default</td><td>{format_duration(default_caps['max_time_seconds'])}</td><td>{default_caps['max_connections']}</td><td>{html.escape(access_level_label(default_caps['access_level']))}</td></tr>
    {user_table}
  </table>
</section>
<section>
  <h2>Set Policy</h2>
  <form method="post" action="/policy">
    <input type="hidden" name="csrf" value="{html.escape(csrf)}">
    <div class="row">
      <div><label for="user">User</label><input id="user" name="user" placeholder="default"></div>
      <div><label for="max_time">Max Time</label><input id="max_time" name="max_time" value="{duration_input_value(default_caps['max_time_seconds'])}" required></div>
      <div><label for="max_connections">Max Connections</label><input id="max_connections" name="max_connections" type="number" min="1" max="10" value="{default_caps['max_connections']}" required></div>
      <div><label for="access_level">Access Level</label><select id="access_level" name="access_level">{access_level_select_options(include_preserve=True)}</select></div>
      <button type="submit">Save</button>
    </div>
  </form>
</section>
<section>
  <h2>Sessions</h2>
  <table>
    <tr><th>Name</th><th>PID</th><th>Process PID</th><th>UID</th><th>Age</th><th>Max</th><th></th></tr>
    {sessions_table}
  </table>
</section>
<section>
  <h2>Kill Session</h2>
  <form method="post" action="/kill">
    <input type="hidden" name="csrf" value="{html.escape(csrf)}">
    <div class="row">
      <div><label for="kill_username">Name</label><input id="kill_username" name="username" placeholder="s432"></div>
      <button type="submit">Kill</button>
    </div>
  </form>
</section>
<form method="post" action="/logout">
  <input type="hidden" name="csrf" value="{html.escape(csrf)}">
  <button class="secondary" type="submit">Logout</button>
</form>""",
    )


class WebHandler(http.server.BaseHTTPRequestHandler):
    server_version = "sshfling-web/0.1"

    def send_html(self, status, body, headers=None):
        data = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        for key, value in (headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(data)

    def redirect(self, location, headers=None):
        self.send_response(303)
        self.send_header("Location", location)
        for key, value in (headers or {}).items():
            self.send_header(key, value)
        self.end_headers()

    def read_form(self):
        raw = read_http_body(self, MAX_HTTP_BODY_BYTES).decode("utf-8")
        parsed = urllib.parse.parse_qs(raw, keep_blank_values=True)
        return {key: values[-1] for key, values in parsed.items()}

    def session_payload(self):
        token = parse_cookie(self.headers.get("Cookie")).get("sshfling_web")
        return verify_web_session(token, self.server.session_secret) if token else None

    def require_session(self):
        payload = self.session_payload()
        if not payload:
            self.redirect("/login")
            return None
        return payload

    def check_csrf(self, payload, form):
        return hmac.compare_digest(str(payload.get("csrf", "")), str(form.get("csrf", "")))

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == "/healthz":
            body = json.dumps({"ok": True, "service": "sshfling-web", "version": VERSION}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if parsed.path == "/login":
            if self.session_payload():
                self.redirect("/")
            else:
                self.send_html(200, render_login())
            return
        if parsed.path != "/":
            self.send_html(404, render_web_page("Not Found", "<section>Not found</section>"))
            return

        payload = self.require_session()
        if not payload:
            return
        query = urllib.parse.parse_qs(parsed.query)
        message = query.get("message", [""])[-1]
        policy = load_policy(self.server.policy_file)
        sessions = find_sshfling_sessions()
        self.send_html(200, render_dashboard(policy, sessions, payload["csrf"], message))

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        try:
            form = self.read_form()
        except SSHFlingError as exc:
            self.send_html(exc.code if exc.code >= 100 else 400, render_web_page("Bad Request", f"<section>{html.escape(exc.message)}</section>"))
            return
        except UnicodeDecodeError:
            self.send_html(400, render_web_page("Bad Request", "<section>Invalid request body.</section>"))
            return
        if parsed.path == "/login":
            client = remote_addr(self)
            if not rate_limit_allowed(self.server, "web-login", client, WEB_LOGIN_RATE_LIMIT, RATE_LIMIT_WINDOW_SECONDS):
                self.send_html(429, render_login("Too many login attempts."))
                return
            username = form.get("username", "")
            password = form.get("password", "")
            if username == self.server.web_user and verify_web_password(password, self.server.password_hash, self.server.plain_password):
                rate_limit_reset(self.server, "web-login", client)
                token = make_web_session(username, self.server.session_secret)
                audit_log("web_login", result="success", remote_addr=client, username=username)
                self.redirect("/", {"Set-Cookie": web_session_cookie(token, 28800, self.server.cookie_secure)})
            else:
                audit_log("web_login", result="failure", remote_addr=client, username=username)
                self.send_html(401, render_login("Invalid login."))
            return

        payload = self.require_session()
        if not payload:
            return
        if not self.check_csrf(payload, form):
            self.send_html(403, render_web_page("Forbidden", "<section>Invalid request</section>"))
            return

        try:
            if parsed.path == "/logout":
                self.redirect("/login", {"Set-Cookie": web_session_cookie("", 0, self.server.cookie_secure)})
                return
            if parsed.path == "/policy":
                user = form.get("user", "").strip() or None
                max_time = duration_seconds(form.get("max_time", ""))
                max_connections = positive_int(form.get("max_connections", ""))
                access_level = form.get("access_level", "").strip() or None
                policy = write_policy(self.server.policy_file, max_time, max_connections, user, access_level)
                active = effective_policy(policy, user)
                audit_log(
                    "web_policy_updated",
                    actor=payload.get("user"),
                    user=user or "default",
                    max_time_seconds=max_time,
                    max_connections=max_connections,
                    access_level=active["access_level"],
                    remote_addr=remote_addr(self),
                )
                self.redirect("/?message=policy+saved")
                return
            if parsed.path == "/kill":
                username = form.get("username", "").strip() or None
                result = kill_sshfling_sessions(session_username=username)
                audit_log(
                    "web_sessions_killed",
                    actor=payload.get("user"),
                    username=username,
                    killed=result["killed"],
                    pids=result["pids"],
                    remote_addr=remote_addr(self),
                )
                self.redirect(f"/?message=killed+{result['killed']}+session(s)")
                return
            self.send_html(404, render_web_page("Not Found", "<section>Not found</section>"))
        except (SSHFlingError, argparse.ArgumentTypeError, ValueError) as exc:
            policy = load_policy(self.server.policy_file)
            sessions = find_sshfling_sessions()
            self.send_html(400, render_dashboard(policy, sessions, payload["csrf"], str(exc)))

    def log_message(self, fmt, *args):
        eprint(f"{self.address_string()} - {fmt % args}")


def cmd_web_hash(args):
    password = os.environ.get(args.password_env)
    if password is None:
        password = getpass.getpass("Web password: ")
    print(make_password_hash(password))
    return 0


def cmd_web(args):
    require_root("web")
    password_hash = args.password_hash or os.environ.get(args.password_hash_env)
    plain_password = os.environ.get(args.password_env)
    if not password_hash and plain_password is None:
        raise SSHFlingError(f"Set {args.password_hash_env}, set {args.password_env}, or pass --password-hash.", 2)

    if ":" not in args.listen:
        raise SSHFlingError("--listen must be host:port.", 2)
    host, port_text = args.listen.rsplit(":", 1)
    if host not in {"127.0.0.1", "localhost", "::1"} and not args.allow_remote:
        raise SSHFlingError("Refusing non-local web bind without --allow-remote.", 2)
    port = int(port_text)

    session_secret_text = os.environ.get(args.session_secret_env) or secrets.token_urlsafe(32)
    server = http.server.ThreadingHTTPServer((host, port), WebHandler)
    server.web_user = args.user
    server.password_hash = password_hash
    server.plain_password = plain_password
    server.session_secret = session_secret_text.encode("utf-8")
    server.policy_file = str(policy_file_path(args.policy_file))
    server.cookie_secure = not is_loopback_host(host)
    server.rate_limits = {}
    server.rate_limit_lock = threading.Lock()

    audit_log(
        "web_service_started",
        listen_host=host,
        listen_port=port,
        allow_remote=args.allow_remote,
        cookie_secure=server.cookie_secure,
        policy_file=server.policy_file,
    )
    eprint(f"sshfling web listening on http://{host}:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        return 130
    return 0


def cmd_key_generate(args):
    generate_key(args)
    return 0


def cmd_network_create(args):
    name = args.name
    proc = run(["docker", "network", "inspect", name], capture=True, check=False)
    created = False
    if proc.returncode != 0:
        run(["docker", "network", "create", name])
        created = True

    payload = {"ok": True, "name": name, "created": created}
    if args.json:
        emit_json(payload)
    else:
        print(("Created" if created else "Exists") + f": {name}")
    return 0


def cmd_server(args):
    project_dir = project_dir_from(args)
    env = {}
    if getattr(args, "session_seconds", None):
        env["SSH_SESSION_SECONDS"] = args.session_seconds

    if args.server_command == "up":
        cmd = compose_command(project_dir, "server") + ["up", "-d"]
        if args.build:
            cmd.append("--build")
        if args.force_recreate:
            cmd.append("--force-recreate")
        run(cmd, cwd=project_dir, env=env)
        return 0

    if args.server_command == "down":
        run(compose_command(project_dir, "server") + ["down"], cwd=project_dir)
        return 0

    if args.server_command == "restart":
        run(compose_command(project_dir, "server") + ["restart"], cwd=project_dir)
        return 0

    if args.server_command == "status":
        run(compose_command(project_dir, "server") + ["ps"], cwd=project_dir)
        return 0

    if args.server_command == "logs":
        cmd = compose_command(project_dir, "server") + ["logs"]
        if args.follow:
            cmd.append("--follow")
        if args.tail:
            cmd += ["--tail", str(args.tail)]
        run(cmd, cwd=project_dir)
        return 0

    raise SSHFlingError(f"Unknown server command: {args.server_command}", 2)


def cmd_client_run(args):
    project_dir = project_dir_from(args)
    remote_command = args.remote_command
    if remote_command and remote_command[0] == "--":
        remote_command = remote_command[1:]

    cmd = compose_command(project_dir, "client") + ["run", "--rm", "ssh-client"] + remote_command
    run(cmd, cwd=project_dir)
    return 0


def cmd_test_timeout(args):
    require_root("test-timeout")
    project_dir = project_dir_from(args)
    env = {"SSH_SESSION_SECONDS": args.seconds}
    run(
        compose_command(project_dir, "server") + ["up", "-d", "--build", "--force-recreate"],
        cwd=project_dir,
        env=env,
    )
    remote = f"echo start; date -u; sleep {args.sleep}; echo should-not-print"
    proc = run(
        compose_command(project_dir, "client") + ["run", "--rm", "ssh-client", remote],
        cwd=project_dir,
        check=False,
    )
    if proc.returncode != 124:
        raise SSHFlingError(
            f"Timeout test expected exit code 124, got {proc.returncode}",
            proc.returncode or 1,
        )
    return 0


def cmd_compose(args):
    project_dir = project_dir_from(args)
    compose_args = args.compose_args
    if compose_args and compose_args[0] == "--":
        compose_args = compose_args[1:]
    if not compose_args:
        raise SSHFlingError("Pass docker compose arguments after --.", 2)
    run(compose_command(project_dir, args.kind) + compose_args, cwd=project_dir)
    return 0


def cmd_package_build(args):
    root = source_root()
    package_types = ["deb", "rpm", "msi", "pkg"] if args.type == "all" else [args.type]
    results = []

    for package_type in package_types:
        if package_type == "deb":
            script = root / "packaging/build-deb.sh"
            cmd = ["bash", str(script)]
        elif package_type == "rpm":
            script = root / "packaging/build-rpm.sh"
            cmd = ["bash", str(script)]
        elif package_type == "msi":
            script = root / "packaging/build-msi.ps1"
            pwsh = command_path("pwsh") or command_path("powershell")
            if not pwsh:
                results.append(
                    {
                        "type": "msi",
                        "ok": False,
                        "message": "PowerShell is required to run packaging/build-msi.ps1.",
                    }
                )
                continue
            cmd = [pwsh, "-NoProfile", "-File", str(script)]
        elif package_type == "pkg":
            script = root / "packaging/build-pkg.sh"
            cmd = ["bash", str(script)]
        else:
            raise SSHFlingError(f"Unknown package type: {package_type}", 2)

        proc = run(cmd, cwd=root, capture=True, check=False)
        results.append(
            {
                "type": package_type,
                "ok": proc.returncode == 0,
                "exit_code": proc.returncode,
                "stdout": proc.stdout.strip(),
                "stderr": proc.stderr.strip(),
            }
        )

        if proc.returncode != 0 and args.type != "all":
            if args.json:
                emit_json({"ok": False, "results": results})
            else:
                sys.stdout.write(proc.stdout)
                sys.stderr.write(proc.stderr)
            return proc.returncode

    ok = all(result["ok"] for result in results)
    if args.json:
        emit_json({"ok": ok, "results": results})
    else:
        for result in results:
            status = "built" if result["ok"] else "skipped/failed"
            print(f"{status}: {result['type']}")
            if result.get("stdout"):
                print(result["stdout"])
            if result.get("stderr"):
                eprint(result["stderr"])

    return 0 if ok else 1


def positive_int(value):
    try:
        parsed = int(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("must be an integer") from exc
    if parsed < 1:
        raise argparse.ArgumentTypeError("must be positive")
    return parsed


def duration_seconds(value):
    raw = str(value).strip().lower()
    match = re.fullmatch(r"([1-9][0-9]*)([smhd]?)", raw)
    if not match:
        raise argparse.ArgumentTypeError("use seconds or a duration like 30s, 5m, 2h, or 1d")
    number = int(match.group(1))
    unit = match.group(2) or "s"
    return number * {"s": 1, "m": 60, "h": 3600, "d": 86400}[unit]


def lifetime_seconds(args, default=300):
    if getattr(args, "time", None) is not None:
        return args.time
    if getattr(args, "seconds", None) is not None:
        return args.seconds
    return default


class StoreExplicit(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None):
        setattr(namespace, self.dest, values)
        setattr(namespace, f"{self.dest}_explicit", True)


def build_parser():
    parser = argparse.ArgumentParser(
        prog="sshfling",
        usage="sshfling [-t TIME] [--username USERNAME] [--certificate] [-k] [command ...]",
        description="Grant or kill temporary SSH access.",
        epilog="""examples:
  sudo sshfling -t 10m
  sudo sshfling -t 5m --username temp-remote
  sudo sshfling --certificate -t 10m --public-key-file ~/.ssh/id_ed25519.pub
  sudo sshfling list
  sudo sshfling -k s432
  sudo sshfling web
  sudo sshfling shutdown
  sudo sshfling -k
  sshfling s234@1.0.0.1
  sshfling scp --recursive ./logs s234@1.0.0.1:/tmp/
  sshfling rsync --recursive --preserve ./dist/ s234@1.0.0.1:/srv/app/
""",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--version", action="version", version=f"sshfling {VERSION}")
    parser.add_argument("--json", action="store_true", help="Emit stable JSON where supported.")
    parser.add_argument("-t", "--time", type=duration_seconds, help="Grant access for this long, for example 30s, 5m, 1h, or 24h.")
    parser.add_argument("--username", help="Temporary SSH username. Defaults to a random name like s123456.")
    parser.add_argument("--login-user", action=StoreExplicit, help="Actual Unix login account if different from --username.")
    parser.add_argument("--access-level", "--role", dest="access_level", help=access_level_help())
    parser.add_argument("-p", "--password", action="store_true", help="Create temporary password SSH access. This is the default; kept for compatibility.")
    parser.add_argument("--certificate", action="store_true", help="Create temporary certificate SSH access instead of the default password access.")
    parser.add_argument("-k", "--kill", nargs="?", const=True, metavar="USERNAME", help="Kill active sshfling SSH session(s), optionally by name like s432.")
    parser.add_argument(
        "--project-dir",
        default=".",
        help="Deployment directory. Defaults to the current directory.",
    )
    parser.add_argument("--ca-key", action=StoreExplicit, default=str(default_ca_key_path()), help=argparse.SUPPRESS)
    parser.add_argument("--public-key", help=argparse.SUPPRESS)
    parser.add_argument("--public-key-file", help=argparse.SUPPRESS)
    parser.add_argument("--out", help=argparse.SUPPRESS)
    parser.add_argument("--session-dir", action=StoreExplicit, default=DEFAULT_SESSION_DIR, help=argparse.SUPPRESS)
    parser.add_argument("--key-id", help=argparse.SUPPRESS)
    parser.add_argument("--source-address", help=argparse.SUPPRESS)
    parser.add_argument("--session-wrapper", default=DEFAULT_SESSION_WRAPPER, help=argparse.SUPPRESS)
    parser.add_argument("--policy-file", default=DEFAULT_POLICY_FILE, help=argparse.SUPPRESS)
    parser.add_argument("--password-sshd-config-dir", default="/etc/ssh/sshd_config.d", help=argparse.SUPPRESS)
    parser.add_argument("--password-grant-dir", default=DEFAULT_PASSWORD_GRANT_DIR, help=argparse.SUPPRESS)
    parser.add_argument("--allow-existing-user", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--no-validate", dest="validate", action="store_false", help=argparse.SUPPRESS)
    parser.add_argument("--dry-run", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--no-pty", action="store_true", help=argparse.SUPPRESS)
    parser.set_defaults(validate=True, ca_key_explicit=False, login_user_explicit=False, session_dir_explicit=False)

    subparsers = parser.add_subparsers(dest="command")

    doctor = subparsers.add_parser("doctor", help="Check local tooling and deployment files.")
    doctor.add_argument("--dependencies", action="store_true", help="Report SSHFling client/server dependency state without changing packages.")
    doctor.add_argument(
        "--mode",
        dest="dependency_mode",
        choices=["all", "client", "password-server", "certificate-host"],
        default="all",
        help="Dependency mode to report with --dependencies.",
    )
    doctor.set_defaults(func=cmd_doctor)

    setup = subparsers.add_parser("setup", help="Create a temporary SSH login. Password access is the default.")
    setup.add_argument("-t", "--time", type=duration_seconds, help="Access lifetime, for example 30s, 5m, 1h, or 24h.")
    setup.add_argument("--username", help="Temporary SSH username. Defaults to a random name like s123456.")
    setup.add_argument("--login-user", action=StoreExplicit, help="Actual Unix login account if different from --username.")
    setup.add_argument("--access-level", "--role", dest="access_level", help=access_level_help())
    setup.add_argument("-p", "--password", action="store_true", help="Create temporary password SSH access. This is the default; kept for compatibility.")
    setup.add_argument("--certificate", action="store_true", help="Create temporary certificate SSH access instead of the default password access.")
    setup.add_argument("--ca-key", action=StoreExplicit, default=str(default_ca_key_path()), help="CA private key path.")
    setup.add_argument("--public-key", help="Public key text to sign.")
    setup.add_argument("--public-key-file", help="Public key file to sign. If omitted, sshfling generates a temporary keypair.")
    setup.add_argument("--out", help="Certificate output path. Defaults beside the public key.")
    setup.add_argument("--session-dir", action=StoreExplicit, default=DEFAULT_SESSION_DIR, help=argparse.SUPPRESS)
    setup.add_argument("--key-id", help="Audit identifier stored in the certificate.")
    setup.add_argument("--source-address", help="Optional CIDR source-address certificate restriction.")
    setup.add_argument("--session-wrapper", default=DEFAULT_SESSION_WRAPPER, help="Forced command wrapper path on target hosts.")
    setup.add_argument("--policy-file", default=DEFAULT_POLICY_FILE, help=argparse.SUPPRESS)
    setup.add_argument("--password-sshd-config-dir", default="/etc/ssh/sshd_config.d", help=argparse.SUPPRESS)
    setup.add_argument("--password-grant-dir", default=DEFAULT_PASSWORD_GRANT_DIR, help=argparse.SUPPRESS)
    setup.add_argument("--allow-existing-user", action="store_true", help="Allow password mode to reset an existing Unix user's password. Use only for documented break-glass cases.")
    setup.add_argument("--no-validate", dest="validate", action="store_false", help="Skip sshd -t validation in password mode.")
    setup.add_argument("--dry-run", action="store_true", help="Show intended password-mode changes without writing files.")
    setup.add_argument("--no-pty", action="store_true", help="Do not permit interactive PTY sessions.")
    setup.set_defaults(func=cmd_setup, validate=True)

    password = subparsers.add_parser("password", help="Manage temporary password grants.")
    password_sub = password.add_subparsers(dest="password_command")
    password_prune = password_sub.add_parser("prune", help="Remove expired temporary password grants.")
    password_prune.add_argument("--username", help="Only prune this temporary password username.")
    password_prune.add_argument("--password-grant-dir", default=DEFAULT_PASSWORD_GRANT_DIR, help=argparse.SUPPRESS)
    password_prune.add_argument("--all", action="store_true", help="Scan all tracked password grants and prune expired grants.")
    password_prune.add_argument("--delete-users", action="store_true", help="Delete sshfling-created Unix users instead of locking them.")
    password_prune.add_argument("--dry-run", action="store_true", help="Show grants that would be pruned without changing files.")
    password_prune.set_defaults(func=cmd_password_prune)

    shutdown = subparsers.add_parser("shutdown", help="Kill active sshfling SSH session(s).")
    shutdown.add_argument("session_username", nargs="?", help="SSHFling session name to kill, for example s432.")
    shutdown.add_argument("--username", help="SSHFling session name to kill, for example s432.")
    shutdown.add_argument("--login-user", help="Login user whose sshfling sessions should be killed.")
    shutdown.set_defaults(func=cmd_kill)

    list_cmd = subparsers.add_parser("list", help="List active sshfling SSH sessions.")
    list_cmd.add_argument("--username", help="Only list this sshfling session name.")
    list_cmd.add_argument("--login-user", help="Only list sessions for this Unix login user.")
    list_cmd.set_defaults(func=cmd_list)

    ca = subparsers.add_parser("ca", help="Manage the SSH user certificate authority.")
    ca_sub = ca.add_subparsers(dest="ca_command")
    ca_init = ca_sub.add_parser("init", help="Create the SSH user CA keypair.")
    ca_init.add_argument("--ca-key", default=str(default_ca_key_path()), help="CA private key path.")
    ca_init.add_argument(
        "--force",
        action="store_true",
        help="Replace an existing CA keypair; requires planned host trust rotation and certificate reissue.",
    )
    ca_init.set_defaults(func=cmd_ca_init)

    cert = subparsers.add_parser("cert", help="Issue temporary SSH user certificates.")
    cert.add_argument("--certificate", action="store_true", default=argparse.SUPPRESS, help="Explicitly allow certificate issuance.")
    cert_sub = cert.add_subparsers(dest="cert_command")
    cert_issue = cert_sub.add_parser("issue", help="Sign a public key for temporary SSH access.")
    cert_issue.add_argument("--certificate", action="store_true", default=argparse.SUPPRESS, help="Explicitly allow certificate issuance.")
    cert_issue.add_argument("--ca-key", default=str(default_ca_key_path()), help="CA private key path.")
    cert_issue.add_argument("--public-key", help="Public key text to sign.")
    cert_issue.add_argument("--public-key-file", help="Public key file to sign.")
    cert_issue.add_argument("--username", help="Temporary SSH username/certificate principal.")
    cert_issue.add_argument("--login-user", help="Unix login user for policy lookup and forced-command metadata.")
    cert_issue.add_argument("--access-level", "--role", dest="access_level", help=access_level_help())
    cert_issue.add_argument("--principal", help=argparse.SUPPRESS)
    cert_issue.add_argument("-t", "--time", type=duration_seconds, help="Access lifetime, for example 30s, 5m, 1h, or 24h.")
    cert_issue.add_argument("--seconds", type=positive_int, help="Certificate and session lifetime.")
    cert_issue.add_argument("--key-id", help="Audit identifier stored in the certificate.")
    cert_issue.add_argument("--serial", type=positive_int, help=argparse.SUPPRESS)
    cert_issue.add_argument("--source-address", help="Optional CIDR source-address certificate restriction.")
    cert_issue.add_argument("--session-wrapper", default=DEFAULT_SESSION_WRAPPER, help="Forced command wrapper path on target hosts.")
    cert_issue.add_argument("--policy-file", default=DEFAULT_POLICY_FILE, help=argparse.SUPPRESS)
    cert_issue.add_argument("--no-pty", action="store_true", help="Do not permit interactive PTY sessions.")
    cert_issue.add_argument("--out", help="Write certificate to this path instead of stdout.")
    cert_issue.set_defaults(func=cmd_cert_issue)
    cert_prune = cert_sub.add_parser("prune", help="Remove expired generated certificate key/cert material.")
    cert_prune.add_argument("--username", help="Only prune generated certificate material for this temporary username.")
    cert_prune.add_argument("--session-dir", default=DEFAULT_SESSION_DIR, help="Directory containing generated SSHFling certificate sessions.")
    cert_prune.add_argument("--all", action="store_true", help="Scan all tracked generated certificate sessions and prune expired material.")
    cert_prune.add_argument("--dry-run", action="store_true", help="Show certificate material that would be pruned without changing files.")
    cert_prune.set_defaults(func=cmd_cert_prune)

    policy = subparsers.add_parser("policy", help="Show or install max time, connection, and access-level limits.")
    policy_sub = policy.add_subparsers(dest="policy_command")
    policy_show = policy_sub.add_parser("show", help="Show the active policy.")
    policy_show.add_argument("--policy-file", default=DEFAULT_POLICY_FILE, help="Policy file path.")
    policy_show.add_argument("--user", help="Show the effective policy for this Unix login user.")
    policy_show.set_defaults(func=cmd_policy_show)
    policy_install = policy_sub.add_parser("install", help="Install the host policy.")
    policy_install.add_argument("--policy-file", default=DEFAULT_POLICY_FILE, help="Policy file path.")
    policy_install.add_argument("--user", help="Set policy for this Unix login user. Omit to set the default policy.")
    policy_install.add_argument("--max-time", type=duration_seconds, help="Maximum SSH lifetime. Omit to preserve the current effective value. Hard cap is 24h.")
    policy_install.add_argument("--max-connections", type=positive_int, help="Maximum active sessions. Omit to preserve the current effective value. Hard cap is 10.")
    policy_install.add_argument("--access-level", "--role", dest="access_level", help=access_level_help())
    policy_install.set_defaults(func=cmd_policy_install)

    host = subparsers.add_parser("host", help="Configure a production SSH host for temporary access.")
    host_sub = host.add_subparsers(dest="host_command")
    host_install = host_sub.add_parser("install", help="Trust the CA and install the forced session wrapper.")
    host_install.add_argument("--ca-pub", required=True, help="CA public key to trust.")
    host_install.add_argument("--username", "--user", dest="user", default="deploy", help="Unix account that may receive temporary SSH access.")
    host_install.add_argument("--principal", action="append", help="Allowed certificate principal. Defaults to --user. Repeatable.")
    host_install.add_argument("--trusted-ca", default="/etc/ssh/sshfling_user_ca.pub", help="Installed CA public key path.")
    host_install.add_argument("--principals-dir", default="/etc/ssh/auth_principals", help="Authorized principals directory.")
    host_install.add_argument("--sshd-config", default="/etc/ssh/sshd_config.d/90-sshfling-temp-access.conf", help="Managed sshd config snippet.")
    host_install.add_argument("--session-wrapper", default=DEFAULT_SESSION_WRAPPER, help="Installed session wrapper path.")
    host_install.add_argument("--policy-file", default=DEFAULT_POLICY_FILE, help="Installed policy file path.")
    host_install.add_argument("--host-user-marker-dir", default=DEFAULT_HOST_USER_MARKER_DIR, help=argparse.SUPPRESS)
    host_install.add_argument("--max-time", type=duration_seconds, help="Install a maximum SSH lifetime policy. Hard cap is 24h.")
    host_install.add_argument("--max-connections", type=positive_int, help="Install a maximum active session policy. Hard cap is 10.")
    host_install.add_argument("--access-level", "--role", dest="access_level", help="Install a policy access level for this Unix account. " + access_level_help())
    host_install.add_argument("--create-user", action="store_true", help="Create the Unix user if missing.")
    host_install.add_argument("--no-validate", dest="validate", action="store_false", help="Skip sshd -t validation.")
    host_install.add_argument("--reload", action="store_true", help="Reload sshd after writing config.")
    host_install.add_argument("--dry-run", action="store_true", help="Show intended changes without writing files.")
    host_install.set_defaults(func=cmd_host_install, validate=True)
    host_uninstall = host_sub.add_parser("uninstall", help="Remove sshfling host SSH configuration.")
    host_uninstall.add_argument("--username", "--user", dest="user", default="deploy", help="Unix account configured for temporary SSH access.")
    host_uninstall.add_argument("--principal", action="append", help="Expected authorized principal. Defaults to --user. Repeatable.")
    host_uninstall.add_argument("--trusted-ca", default="/etc/ssh/sshfling_user_ca.pub", help="Installed CA public key path.")
    host_uninstall.add_argument("--principals-dir", default="/etc/ssh/auth_principals", help="Authorized principals directory.")
    host_uninstall.add_argument("--sshd-config", default="/etc/ssh/sshd_config.d/90-sshfling-temp-access.conf", help="Managed sshd config snippet.")
    host_uninstall.add_argument("--session-wrapper", default=DEFAULT_SESSION_WRAPPER, help="Installed session wrapper path.")
    host_uninstall.add_argument("--policy-file", default=DEFAULT_POLICY_FILE, help="Installed policy file path.")
    host_uninstall.add_argument("--host-user-marker-dir", default=DEFAULT_HOST_USER_MARKER_DIR, help=argparse.SUPPRESS)
    host_uninstall.add_argument("--remove-ca", action="store_true", help="Also remove the installed trusted CA file.")
    host_uninstall.add_argument("--remove-wrapper", action="store_true", help="Also remove the installed session wrapper.")
    host_uninstall.add_argument("--remove-policy-user", action="store_true", help="Remove this user's policy override from the policy file.")
    host_uninstall.add_argument("--delete-user", action="store_true", help="Delete the Unix account. Use only for accounts created solely for sshfling.")
    host_uninstall.add_argument("--force", action="store_true", help="Remove files even when managed-content checks do not match.")
    host_uninstall.add_argument("--no-validate", dest="validate", action="store_false", help="Skip sshd -t validation.")
    host_uninstall.add_argument("--reload", action="store_true", help="Reload sshd after removing config.")
    host_uninstall.add_argument("--dry-run", action="store_true", help="Show intended removals without changing files.")
    host_uninstall.set_defaults(func=cmd_host_uninstall, validate=True)

    serve = subparsers.add_parser("serve", help="Run the temporary SSH certificate issuer service.")
    serve.add_argument("--listen", default=DEFAULT_ISSUER_LISTEN, help="Issuer listen address as host:port.")
    serve.add_argument("--ca-key", default=str(default_ca_key_path()), help="CA private key path.")
    serve.add_argument("--allowed-principal", action="append", default=["deploy"], help="Allowed principal or comma list. Repeatable.")
    serve.add_argument("--default-seconds", type=positive_int, default=300, help="Default certificate lifetime.")
    serve.add_argument("--max-seconds", type=positive_int, default=MAX_TIME_SECONDS, help="Maximum certificate lifetime.")
    serve.add_argument("--session-wrapper", default=DEFAULT_SESSION_WRAPPER, help="Forced command wrapper path on target hosts.")
    serve.add_argument("--policy-file", default=DEFAULT_POLICY_FILE, help=argparse.SUPPRESS)
    serve.add_argument("--token-env", default="SSHFLING_ISSUER_TOKEN", help="Environment variable containing the bearer token.")
    serve.add_argument("--token", help="Bearer token. Prefer --token-env for production.")
    serve.add_argument("--allow-remote", action="store_true", help="Allow binding the issuer to a non-local address. Put it behind TLS, mTLS, or a private network.")
    serve.set_defaults(func=cmd_serve)

    web = subparsers.add_parser("web", help="Run the local admin web console.")
    web.add_argument("--listen", default="127.0.0.1:8790", help="Web listen address as host:port.")
    web.add_argument("--user", default=os.environ.get("SSHFLING_WEB_USER", "admin"), help="Login username.")
    web.add_argument("--password-hash", help="PBKDF2 password hash. Prefer SSHFLING_WEB_PASSWORD_HASH.")
    web.add_argument("--password-hash-env", default="SSHFLING_WEB_PASSWORD_HASH", help="Environment variable containing the password hash.")
    web.add_argument("--password-env", default="SSHFLING_WEB_PASSWORD", help="Environment variable containing a plaintext password.")
    web.add_argument("--session-secret-env", default="SSHFLING_WEB_SESSION_SECRET", help="Environment variable containing the cookie signing secret.")
    web.add_argument("--policy-file", default=DEFAULT_POLICY_FILE, help="Policy file path.")
    web.add_argument("--allow-remote", action="store_true", help="Allow binding to a non-local address.")
    web.set_defaults(func=cmd_web)

    web_hash = subparsers.add_parser("web-hash", help="Hash a web login password.")
    web_hash.add_argument("--password-env", default="SSHFLING_WEB_PASSWORD", help="Environment variable containing the password.")
    web_hash.set_defaults(func=cmd_web_hash)

    detached = subparsers.add_parser("detached", help="Manage detached local jobs with PIDs and logs.")
    detached_sub = detached.add_subparsers(dest="detached_command")
    detached_start = detached_sub.add_parser("start", help="Start a detached local command.")
    detached_start.add_argument("--name", required=True, help="Detached job name.")
    detached_start.add_argument("-t", "--time", type=duration_seconds, default=MAX_TIME_SECONDS, help="Maximum runtime, up to 24h.")
    detached_start.add_argument("--cwd", default=".", help="Working directory for the command.")
    detached_start.add_argument("--detached-dir", help="Detached job metadata directory.")
    detached_start.add_argument("--replace", action="store_true", help="Replace an inactive job with the same name.")
    detached_start.add_argument("detached_args", nargs=argparse.REMAINDER, help="Command to run after --.")
    detached_start.set_defaults(func=cmd_detached_start)
    detached_list = detached_sub.add_parser("list", help="List detached local jobs.")
    detached_list.add_argument("--name", help="Only show this detached job.")
    detached_list.add_argument("--detached-dir", help="Detached job metadata directory.")
    detached_list.set_defaults(func=cmd_detached_list)
    detached_kill = detached_sub.add_parser("kill", help="Kill a detached local job.")
    detached_kill.add_argument("name", help="Detached job name.")
    detached_kill.add_argument("--detached-dir", help="Detached job metadata directory.")
    detached_kill.set_defaults(func=cmd_detached_kill)

    detached_supervisor = subparsers.add_parser("_detached-supervisor", help=argparse.SUPPRESS)
    detached_supervisor.add_argument("--metadata", required=True)
    detached_supervisor.add_argument("detached_args", nargs=argparse.REMAINDER)
    detached_supervisor.set_defaults(func=cmd_detached_supervisor)

    scp = subparsers.add_parser("scp", help="Copy files through native OpenSSH scp using temporary password access.")
    scp.add_argument("-r", "--recursive", action="store_true", help="Copy directories recursively.")
    scp.add_argument("--preserve", "-p", action="store_true", help="Preserve source mode and mtime using scp -p.")
    scp.add_argument("--mode", help="Unsupported for scp; use rsync --mode for safe destination mode rewriting.")
    scp.add_argument("--owner-group", action="store_true", help="Unsupported for scp; use rsync when owner/group metadata is required.")
    scp.add_argument("--chown", help="Unsupported for scp; use rsync --chown USER:GROUP when permitted.")
    scp.add_argument("--sftp", action="store_true", help="Use scp's SFTP transport instead of forced-command-compatible legacy scp protocol.")
    scp.add_argument("-P", "--port", type=positive_int, help="SSH port.")
    scp.add_argument("-o", "--ssh-option", action="append", default=[], help="Extra ssh option passed to scp as -o OPTION. Repeatable.")
    scp.add_argument("--dry-run", action="store_true", help="Print the native scp command without running it.")
    scp.add_argument("paths", nargs="+", help="One or more sources followed by a destination.")
    scp.set_defaults(func=cmd_scp)

    rsync = subparsers.add_parser("rsync", help="Copy files through rsync over SSH using temporary password access.")
    rsync.add_argument("-r", "--recursive", action="store_true", help="Recurse into directories without archive metadata.")
    rsync.add_argument("-a", "--archive", action="store_true", help="Use rsync archive mode. Owner/group preservation still depends on account privileges.")
    rsync.add_argument("--preserve", action="store_true", help="Preserve source mode and mtime with --perms --times.")
    rsync.add_argument("--links", action="store_true", help="Preserve symlinks as symlinks when not using --archive.")
    rsync.add_argument("--mode", help="Pass a safe rsync --chmod value such as u=rwX,go=rX.")
    rsync.add_argument("--owner-group", action="store_true", help="Request rsync owner/group preservation. Requires a permitted receiving account.")
    rsync.add_argument("--chown", help="Pass rsync --chown=USER:GROUP to set destination owner/group when permitted.")
    rsync.add_argument("-P", "--port", type=positive_int, help="SSH port.")
    rsync.add_argument("-o", "--ssh-option", action="append", default=[], help="Extra ssh option passed to the rsync SSH transport. Repeatable.")
    rsync.add_argument("--dry-run", action="store_true", help="Print the native rsync command without running it.")
    rsync.add_argument("paths", nargs="+", help="One or more sources followed by a destination.")
    rsync.set_defaults(func=cmd_rsync)

    init = subparsers.add_parser("init", help="Copy deployment templates into a directory.")
    init.add_argument("path", nargs="?", default=None, help="Target directory. Defaults to --project-dir.")
    init.add_argument("--force", action="store_true", help="Overwrite existing template files.")
    init.add_argument("--with-key", action="store_true", help="Generate the client SSH keypair.")
    init.add_argument("--session-seconds", type=positive_int, help="Write SSH_SESSION_SECONDS to .env.")
    init.add_argument("--host-port", type=positive_int, help="Write SSH_PORT_ON_HOST to .env.")
    init.set_defaults(func=lambda args: cmd_init(normalize_init_path(args)))

    key = subparsers.add_parser("key", help="Manage the client SSH keypair.")
    key_sub = key.add_subparsers(dest="key_command")
    key_generate = key_sub.add_parser("generate", help="Generate an ed25519 client keypair.")
    key_generate.add_argument("--path", default="secrets/client_ed25519", help="Private key path.")
    key_generate.add_argument("--force", action="store_true", help="Replace an existing keypair.")
    key_generate.set_defaults(func=cmd_key_generate)

    network = subparsers.add_parser("network", help="Manage the shared Docker network.")
    network_sub = network.add_subparsers(dest="network_command")
    network_create = network_sub.add_parser("create", help="Create the shared Docker network.")
    network_create.add_argument("--name", default=DEFAULT_NETWORK)
    network_create.set_defaults(func=cmd_network_create)

    server = subparsers.add_parser("server", help="Manage the SSH server Compose deployment.")
    server_sub = server.add_subparsers(dest="server_command")
    server_up = server_sub.add_parser("up", help="Start the SSH server.")
    server_up.add_argument("--build", action="store_true", help="Build the server image first.")
    server_up.add_argument("--force-recreate", action="store_true", help="Recreate the container.")
    server_up.add_argument("--session-seconds", type=positive_int, help="Override SSH_SESSION_SECONDS.")
    server_up.set_defaults(func=cmd_server)
    server_sub.add_parser("down", help="Stop and remove the SSH server.").set_defaults(func=cmd_server)
    server_sub.add_parser("restart", help="Restart the SSH server.").set_defaults(func=cmd_server)
    server_sub.add_parser("status", help="Show server container status.").set_defaults(func=cmd_server)
    server_logs = server_sub.add_parser("logs", help="Show server logs.")
    server_logs.add_argument("--follow", "-f", action="store_true")
    server_logs.add_argument("--tail", type=positive_int)
    server_logs.set_defaults(func=cmd_server)

    client = subparsers.add_parser("client", help="Run SSH client commands.")
    client_sub = client.add_subparsers(dest="client_command")
    client_run = client_sub.add_parser("run", help="Run a remote command through the SSH client container.")
    client_run.add_argument("remote_command", nargs=argparse.REMAINDER)
    client_run.set_defaults(func=cmd_client_run)

    test_timeout = subparsers.add_parser("test-timeout", help="Run a server-side timeout smoke test.")
    test_timeout.add_argument("--seconds", type=positive_int, default=5, help="Session limit for the test.")
    test_timeout.add_argument("--sleep", type=positive_int, default=20, help="Remote sleep duration.")
    test_timeout.set_defaults(func=cmd_test_timeout)

    compose = subparsers.add_parser("compose", help="Raw docker compose escape hatch.")
    compose.add_argument("kind", choices=["server", "client"])
    compose.add_argument("compose_args", nargs=argparse.REMAINDER)
    compose.set_defaults(func=cmd_compose)

    package = subparsers.add_parser("package", help="Build OS packages.")
    package_sub = package.add_subparsers(dest="package_command")
    package_build = package_sub.add_parser("build", help="Build deb, rpm, msi, or all packages.")
    package_build.add_argument("--type", choices=["deb", "rpm", "msi", "pkg", "all"], default="all")
    package_build.set_defaults(func=cmd_package_build)

    return parser


def normalize_init_path(args):
    if args.path:
        args.project_dir = args.path
    return args


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    audit_log("command_invoked", command=audit_command_name(argv), argc=len(argv))
    connect_args = maybe_connect_argv(argv)
    if connect_args:
        before_args, target, after_args = connect_args
        try:
            return cmd_connect(before_args, target, after_args)
        except SSHFlingError as exc:
            eprint(f"sshfling: {exc.message}")
            if exc.details.get("stderr"):
                eprint(exc.details["stderr"].rstrip())
            return exc.code

    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        if args.kill:
            if args.command:
                parser.error("-k/--kill cannot be combined with a subcommand")
            if args.time is not None:
                parser.error("-k/--kill cannot be combined with -t/--time")
            return cmd_kill(args)

        if not args.command:
            return cmd_setup(args)

        if not hasattr(args, "func"):
            parser.error(f"missing subcommand for {args.command}")

        return args.func(args)
    except SSHFlingError as exc:
        if getattr(args, "json", False):
            emit_json({"ok": False, "error": {"message": exc.message, "details": exc.details}})
        else:
            eprint(f"sshfling: {exc.message}")
            if exc.details.get("stderr"):
                eprint(exc.details["stderr"].rstrip())
        return exc.code


if __name__ == "__main__":
    sys.exit(main())
