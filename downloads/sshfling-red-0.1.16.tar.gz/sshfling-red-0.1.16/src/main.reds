Red/System [
    Title: "SSHFling CLI"
    Version: 0.1.16
]

#include %sshfling.reds

quit sshfling-main system/args-count system/args-list
