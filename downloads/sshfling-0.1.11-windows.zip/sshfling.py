#!/usr/bin/env python3
import argparse
import base64
import datetime as dt
import getpass
import hashlib
import hmac
import html
import http.server
import json
import os
import urllib.parse
import shlex
import re
import secrets
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

VERSION = "0.1.11"
DEFAULT_NETWORK = "timed-ssh-net"
DEFAULT_SESSION_WRAPPER = "/usr/local/libexec/sshfling-session"
DEFAULT_ISSUER_LISTEN = "127.0.0.1:8787"
DEFAULT_SESSION_DIR = "/var/lib/sshfling/sessions"
DEFAULT_POLICY_FILE = "/etc/sshfling/policy.json"
DEFAULT_PASSWORD_GRANT_DIR = "/var/lib/sshfling/password-grants"
DEFAULT_TEMP_USERNAME_PREFIX = "s"
DEFAULT_DETACHED_DIR = ".sshfling/detached"
MAX_TIME_SECONDS = 86400
MAX_CONNECTIONS = 10
UTC = getattr(dt, "UTC", dt.timezone.utc)

TEMPLATE_ENTRIES = [
    ".env.example",
    "LICENSE",
    "README.md",
    "compose.server.yml",
    "compose.client.yml",
    "scripts/install-local.sh",
    "scripts/uninstall-local.sh",
    "scripts/create-network.sh",
    "scripts/generate-ssh-key.sh",
    "secrets/.gitkeep",
    "ssh-client/Dockerfile",
    "ssh-client/entrypoint.sh",
    "ssh-server/Dockerfile",
    "ssh-server/entrypoint.sh",
    "ssh-server/limited-session.sh",
    "ssh-server/sshd_config",
    "production/sshfling-session",
    "systemd/sshflingd.service",
    "systemd/sshflingd.env.example",
]


class SSHFlingError(Exception):
    def __init__(self, message, code=1, **details):
        super().__init__(message)
        self.message = message
        self.code = code
        self.details = details


def eprint(*parts):
    print(*parts, file=sys.stderr)


def emit_json(payload):
    print(json.dumps(payload, indent=2, sort_keys=True))


def command_path(name):
    return shutil.which(name)


def is_usable_server_host(value):
    value = (value or "").strip()
    if not value or any(ch.isspace() for ch in value):
        return False
    lowered = value.lower()
    if lowered in {"localhost", "localhost.localdomain", "::1"}:
        return False
    if lowered.startswith("127."):
        return False
    if lowered.startswith("169.254."):
        return False
    return True


def detect_server_host():
    override = os.environ.get("SSHFLING_SERVER_HOST")
    if is_usable_server_host(override):
        return override.strip()

    candidates = []
    if command_path("hostname"):
        proc = run(["hostname", "-I"], capture=True, check=False)
        if proc.returncode == 0:
            candidates.extend((proc.stdout or "").split())

    try:
        candidates.append(socket.gethostbyname(socket.gethostname()))
    except OSError:
        pass

    for candidate in candidates:
        if is_usable_server_host(candidate) and "." in candidate:
            return candidate.strip()
    for candidate in candidates:
        if is_usable_server_host(candidate):
            return candidate.strip()

    try:
        fqdn = socket.getfqdn()
    except OSError:
        fqdn = ""
    if is_usable_server_host(fqdn):
        return fqdn

    return "SERVER_IP"


def is_admin():
    if hasattr(os, "geteuid"):
        return os.geteuid() == 0
    if os.name == "nt":
        try:
            import ctypes

            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        except Exception:
            return False
    return False


def require_root(action):
    if not is_admin():
        raise SSHFlingError(f"{action} requires root/admin privileges. Run it with sudo or from an elevated shell.", 77)


def run(args, cwd=None, env=None, capture=False, check=True, timeout=None):
    merged_env = os.environ.copy()
    if env:
        merged_env.update({k: str(v) for k, v in env.items() if v is not None})

    try:
        proc = subprocess.run(
            args,
            cwd=str(cwd) if cwd else None,
            env=merged_env,
            universal_newlines=True,
            stdout=subprocess.PIPE if capture else None,
            stderr=subprocess.PIPE if capture else None,
            check=False,
            timeout=timeout,
        )
    except FileNotFoundError as exc:
        raise SSHFlingError(f"Missing command: {args[0]}", 127) from exc
    except subprocess.TimeoutExpired as exc:
        if check:
            raise SSHFlingError(f"Command timed out after {timeout}s: {' '.join(args)}", 124) from exc
        return subprocess.CompletedProcess(
            args,
            124,
            stdout=exc.stdout or "",
            stderr=exc.stderr or f"timed out after {timeout}s",
        )

    if check and proc.returncode != 0:
        details = {}
        if capture:
            details = {"stdout": proc.stdout, "stderr": proc.stderr}
        raise SSHFlingError(
            f"Command failed with exit code {proc.returncode}: {' '.join(args)}",
            proc.returncode,
            **details,
        )

    return proc


def run_with_input(args, input_text, cwd=None, env=None, capture=False, check=True):
    merged_env = os.environ.copy()
    if env:
        merged_env.update({k: str(v) for k, v in env.items() if v is not None})

    try:
        proc = subprocess.run(
            args,
            cwd=str(cwd) if cwd else None,
            env=merged_env,
            input=input_text,
            universal_newlines=True,
            stdout=subprocess.PIPE if capture else None,
            stderr=subprocess.PIPE if capture else None,
            check=False,
        )
    except FileNotFoundError as exc:
        raise SSHFlingError(f"Missing command: {args[0]}", 127) from exc

    if check and proc.returncode != 0:
        details = {}
        if capture:
            details = {"stdout": proc.stdout, "stderr": proc.stderr}
        raise SSHFlingError(
            f"Command failed with exit code {proc.returncode}: {' '.join(args)}",
            proc.returncode,
            **details,
        )

    return proc


def project_dir_from(args):
    return Path(args.project_dir).expanduser().resolve()


def source_root():
    return Path(__file__).resolve().parents[1]


def find_template_dir():
    candidates = []

    env_dir = os.environ.get("SSHFLING_TEMPLATE_DIR")
    if env_dir:
        candidates.append(Path(env_dir).expanduser())

    candidates.extend(
        [
            Path(__file__).resolve().parent / "templates",
            source_root(),
            Path(__file__).resolve().parents[1] / "share/sshfling/templates",
            Path("/usr/share/sshfling/templates"),
            Path.home() / ".local/share/sshfling/templates",
        ]
    )

    for candidate in candidates:
        candidate = candidate.resolve()
        if (candidate / "compose.server.yml").exists() and (candidate / "ssh-server").is_dir():
            return candidate

    raise SSHFlingError(
        "Could not find sshfling templates. Set SSHFLING_TEMPLATE_DIR or reinstall sshfling.",
        2,
        checked=[str(p) for p in candidates],
    )


def resource_file(relative):
    base = find_template_dir()
    path = base / relative
    if not path.exists():
        raise SSHFlingError(f"Missing sshfling resource: {relative}", 2, path=str(path))
    return path


def is_same_path(a, b):
    try:
        return a.resolve().samefile(b.resolve())
    except FileNotFoundError:
        return False


def copy_template_file(src, dst, force):
    if dst.exists() and not force:
        return "exists"

    if src.exists() and dst.exists() and is_same_path(src, dst):
        return "same"

    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    return "copied"


def write_env(project_dir, force, session_seconds=None, host_port=None):
    env_example = project_dir / ".env.example"
    env_file = project_dir / ".env"

    if env_file.exists() and not force:
        status = "exists"
        lines = env_file.read_text().splitlines()
    else:
        if env_example.exists():
            lines = env_example.read_text().splitlines()
        else:
            lines = []
        status = "written"

    updates = {}
    if session_seconds is not None:
        updates["SSH_SESSION_SECONDS"] = str(session_seconds)
    if host_port is not None:
        updates["SSH_PORT_ON_HOST"] = str(host_port)

    if updates:
        seen = set()
        new_lines = []
        for line in lines:
            key = line.split("=", 1)[0] if "=" in line and not line.startswith("#") else None
            if key in updates:
                new_lines.append(f"{key}={updates[key]}")
                seen.add(key)
            else:
                new_lines.append(line)
        for key, value in updates.items():
            if key not in seen:
                new_lines.append(f"{key}={value}")
        lines = new_lines
        status = "written"

    if status == "written":
        env_file.write_text("\n".join(lines).rstrip() + "\n")
        env_file.chmod(0o600)

    return {"path": str(env_file), "status": status}


def require_project_file(project_dir, relative):
    path = project_dir / relative
    if not path.exists():
        raise SSHFlingError(
            f"Missing {relative}. Run `sshfling init` in this directory first.",
            2,
            path=str(path),
        )
    return path


def docker_compose_file(project_dir, kind):
    if kind == "server":
        return require_project_file(project_dir, "compose.server.yml")
    if kind == "client":
        return require_project_file(project_dir, "compose.client.yml")
    raise SSHFlingError(f"Unknown compose kind: {kind}", 2)


def compose_command(project_dir, kind):
    return ["docker", "compose", "-f", str(docker_compose_file(project_dir, kind))]


def cmd_doctor(args):
    project_dir = project_dir_from(args)
    checks = []

    def add_check(name, ok, **extra):
        checks.append({"name": name, "ok": bool(ok), **extra})

    add_check("python", True, path=sys.executable, version=sys.version.split()[0])

    for name in ["docker", "ssh-keygen"]:
        path = command_path(name)
        add_check(name, path is not None, path=path)

    docker_compose_ok = False
    docker_compose_version = None
    if command_path("docker"):
        proc = run(["docker", "compose", "version"], capture=True, check=False)
        docker_compose_ok = proc.returncode == 0
        docker_compose_version = (proc.stdout or proc.stderr or "").strip()
    add_check("docker compose", docker_compose_ok, version=docker_compose_version)

    try:
        template_dir = find_template_dir()
        add_check("templates", True, path=str(template_dir))
    except SSHFlingError as exc:
        add_check("templates", False, message=exc.message)

    for rel in ["compose.server.yml", "compose.client.yml"]:
        add_check(rel, (project_dir / rel).exists(), path=str(project_dir / rel))

    add_check("public key", (project_dir / "secrets/client_ed25519.pub").exists())
    add_check("private key", (project_dir / "secrets/client_ed25519").exists())

    network_exists = False
    if command_path("docker"):
        proc = run(["docker", "network", "inspect", DEFAULT_NETWORK], capture=True, check=False)
        network_exists = proc.returncode == 0
    add_check("docker network", network_exists, network=DEFAULT_NETWORK)

    ok = all(check["ok"] for check in checks if check["name"] in ["python", "docker", "docker compose", "ssh-keygen", "templates"])
    payload = {"ok": ok, "command": "sshfling", "version": VERSION, "project_dir": str(project_dir), "checks": checks}

    if args.json:
        emit_json(payload)
    else:
        print(f"sshfling {VERSION}")
        print(f"Project: {project_dir}")
        for check in checks:
            marker = "ok" if check["ok"] else "missing"
            suffix = ""
            if "path" in check and check["path"]:
                suffix = f" ({check['path']})"
            elif "version" in check and check["version"]:
                suffix = f" ({check['version']})"
            elif check["name"] == "docker network":
                suffix = f" ({check.get('network', DEFAULT_NETWORK)})"
            print(f"{marker:7} {check['name']}{suffix}")

    return 0 if ok else 1


def cmd_init(args):
    project_dir = project_dir_from(args)
    template_dir = find_template_dir()
    project_dir.mkdir(parents=True, exist_ok=True)

    results = []
    for rel in TEMPLATE_ENTRIES:
        src = template_dir / rel
        dst = project_dir / rel
        if not src.exists():
            raise SSHFlingError(f"Template is missing: {src}", 2)
        status = copy_template_file(src, dst, args.force)
        results.append({"path": rel, "status": status})

    env_result = write_env(project_dir, args.force, args.session_seconds, args.host_port)

    key_result = None
    if args.with_key:
        key_args = argparse.Namespace(
            project_dir=str(project_dir),
            path="secrets/client_ed25519",
            force=args.force,
            json=args.json,
        )
        key_result = generate_key(key_args, emit=False)

    payload = {
        "ok": True,
        "project_dir": str(project_dir),
        "template_dir": str(template_dir),
        "files": results,
        "env": env_result,
        "key": key_result,
    }

    if args.json:
        emit_json(payload)
    else:
        print(f"Initialized sshfling deployment in {project_dir}")
        print(f"Templates: {template_dir}")
        print(f"Env: {env_result['status']} {env_result['path']}")
        if key_result:
            print(f"Key: {key_result['status']} {key_result['private_key']}")

    return 0


def generate_key(args, emit=True):
    project_dir = project_dir_from(args)
    key_path = (project_dir / args.path).resolve()
    pub_path = Path(str(key_path) + ".pub")

    if (key_path.exists() or pub_path.exists()) and not args.force:
        result = {
            "ok": True,
            "status": "exists",
            "private_key": str(key_path),
            "public_key": str(pub_path),
        }
        if emit:
            if args.json:
                emit_json(result)
            else:
                print(f"Key already exists: {key_path}")
        return result

    if args.force:
        key_path.unlink(missing_ok=True)
        pub_path.unlink(missing_ok=True)

    key_path.parent.mkdir(parents=True, exist_ok=True)
    run(["ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-C", "sshfling-client", "-f", str(key_path)], capture=True)
    key_path.chmod(0o600)
    pub_path.chmod(0o644)

    result = {
        "ok": True,
        "status": "created",
        "private_key": str(key_path),
        "public_key": str(pub_path),
    }

    if emit:
        if args.json:
            emit_json(result)
        else:
            print(f"Created key: {key_path}")
            print(f"Created public key: {pub_path}")

    return result


def default_ca_key_path():
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        return Path("/etc/sshfling/ca_user_ed25519")
    return Path.home() / ".sshfling/ca_user_ed25519"


def default_policy():
    return {
        "version": 2,
        "default": {"max_time_seconds": MAX_TIME_SECONDS, "max_connections": MAX_CONNECTIONS},
        "users": {},
    }


def policy_file_path(value=None):
    return Path(value or DEFAULT_POLICY_FILE).expanduser().resolve()


def format_duration(seconds):
    if seconds == 86400:
        return "24 hours"
    if seconds == 3600:
        return "1 hour"
    if seconds % 3600 == 0:
        return f"{seconds // 3600}h"
    if seconds % 60 == 0:
        return f"{seconds // 60}m"
    return f"{seconds}s"


def duration_input_value(seconds):
    if seconds % 3600 == 0:
        return f"{seconds // 3600}h"
    if seconds % 60 == 0:
        return f"{seconds // 60}m"
    return f"{seconds}s"


def validate_policy_values(max_time_seconds, max_connections):
    if max_time_seconds < 1:
        raise SSHFlingError("Maximum time must be positive.", 2)
    if max_time_seconds > MAX_TIME_SECONDS:
        raise SSHFlingError(f"Maximum time cannot exceed {format_duration(MAX_TIME_SECONDS)}.", 2)
    if max_connections < 1:
        raise SSHFlingError("Maximum connections must be positive.", 2)
    if max_connections > MAX_CONNECTIONS:
        raise SSHFlingError(f"Maximum connections cannot exceed {MAX_CONNECTIONS}.", 2)
    return {"max_time_seconds": max_time_seconds, "max_connections": max_connections}


def normalize_policy(data):
    policy = default_policy()
    if "default" in data:
        default_data = data.get("default") or {}
        policy["default"] = validate_policy_values(
            int(default_data.get("max_time_seconds", policy["default"]["max_time_seconds"])),
            int(default_data.get("max_connections", policy["default"]["max_connections"])),
        )
    else:
        policy["default"] = validate_policy_values(
            int(data.get("max_time_seconds", policy["default"]["max_time_seconds"])),
            int(data.get("max_connections", policy["default"]["max_connections"])),
        )

    users = {}
    for username, user_policy in (data.get("users") or {}).items():
        if not username:
            continue
        users[str(username)] = validate_policy_values(
            int(user_policy.get("max_time_seconds", policy["default"]["max_time_seconds"])),
            int(user_policy.get("max_connections", policy["default"]["max_connections"])),
        )
    policy["users"] = users
    return policy


def load_policy(policy_file=None):
    path = policy_file_path(policy_file)
    data = default_policy()
    if path.exists():
        try:
            data = json.loads(path.read_text())
        except json.JSONDecodeError as exc:
            raise SSHFlingError(f"Invalid policy file: {path}", 2) from exc

    policy = normalize_policy(data)
    policy["path"] = str(path)
    return policy


def effective_policy(policy, username=None):
    caps = policy["default"].copy()
    if username and username in policy.get("users", {}):
        caps.update(policy["users"][username])
    caps["username"] = username
    caps["path"] = policy.get("path")
    return caps


def write_policy(policy_file, max_time_seconds, max_connections, username=None):
    existing = load_policy(policy_file)
    caps = validate_policy_values(max_time_seconds, max_connections)
    if username:
        existing.setdefault("users", {})[username] = caps
    else:
        existing["default"] = caps
    policy = normalize_policy(existing)
    path = policy_file_path(policy_file)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(policy, indent=2, sort_keys=True) + "\n")
    path.chmod(0o644)
    policy["path"] = str(path)
    return policy


def read_text_source(value, file_path, label):
    if value and file_path:
        raise SSHFlingError(f"Use either --{label} or --{label}-file, not both.", 2)
    if value:
        return value.strip()
    if file_path:
        return Path(file_path).expanduser().read_text().strip()
    raise SSHFlingError(f"Missing --{label} or --{label}-file.", 2)


def sign_user_certificate(
    ca_key,
    public_key_text,
    principal,
    seconds,
    key_id=None,
    out_file=None,
    serial=None,
    source_address=None,
    session_wrapper=DEFAULT_SESSION_WRAPPER,
    policy_file=DEFAULT_POLICY_FILE,
    login_user=None,
    permit_pty=True,
):
    policy = load_policy(policy_file)
    active_policy = effective_policy(policy, login_user or principal)
    if seconds < 1:
        raise SSHFlingError("Certificate lifetime must be positive.", 2)
    if seconds > active_policy["max_time_seconds"]:
        raise SSHFlingError(f"Certificate lifetime cannot exceed {format_duration(active_policy['max_time_seconds'])}.", 2)

    ca_key_path = Path(ca_key).expanduser().resolve()
    if not ca_key_path.exists():
        raise SSHFlingError(f"CA key does not exist: {ca_key_path}", 2)

    key_id = key_id or f"sshfling-{principal}-{dt.datetime.now(UTC).strftime('%Y%m%dT%H%M%SZ')}"
    serial = serial if serial is not None else secrets.randbits(63)
    force_command = (
        f"{shlex.quote(session_wrapper)} --max-seconds {seconds} "
        f"--username {shlex.quote(principal)} --login-user {shlex.quote(login_user or principal)} "
        f"--policy-file {shlex.quote(policy['path'])}"
    )

    with tempfile.TemporaryDirectory(prefix="sshfling-cert-") as tmp:
        pub_path = Path(tmp) / "client.pub"
        pub_path.write_text(public_key_text.rstrip() + "\n")
        pub_path.chmod(0o600)

        cmd = [
            "ssh-keygen",
            "-q",
            "-s",
            str(ca_key_path),
            "-I",
            key_id,
            "-z",
            str(serial),
            "-n",
            principal,
            "-V",
            f"+{seconds}s",
            "-O",
            "clear",
            "-O",
            f"force-command={force_command}",
        ]
        if permit_pty:
            cmd += ["-O", "permit-pty"]
        if source_address:
            cmd += ["-O", f"source-address={source_address}"]
        cmd.append(str(pub_path))

        run(cmd, capture=True)

        cert_path = Path(tmp) / "client-cert.pub"
        certificate = cert_path.read_text().strip()

    if out_file:
        out_path = Path(out_file).expanduser().resolve()
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(certificate + "\n")
        out_path.chmod(0o644)
    else:
        out_path = None

    valid_before = dt.datetime.now(UTC) + dt.timedelta(seconds=seconds)
    return {
        "ok": True,
        "certificate": certificate,
        "username": principal,
        "principal": principal,
        "seconds": seconds,
        "valid_before": valid_before.isoformat().replace("+00:00", "Z"),
        "key_id": key_id,
        "serial": serial,
        "out": str(out_path) if out_path else None,
        "force_command": force_command,
        "policy": active_policy,
    }


def create_ca_key(args):
    ca_key = Path(args.ca_key).expanduser().resolve()
    ca_pub = Path(str(ca_key) + ".pub")

    if (ca_key.exists() or ca_pub.exists()) and not args.force:
        result = {"ok": True, "status": "exists", "ca_key": str(ca_key), "ca_public_key": str(ca_pub)}
    else:
        if args.force:
            ca_key.unlink(missing_ok=True)
            ca_pub.unlink(missing_ok=True)
        ca_key.parent.mkdir(parents=True, exist_ok=True)
        run(["ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-C", "sshfling-user-ca", "-f", str(ca_key)], capture=True)
        ca_key.chmod(0o600)
        ca_pub.chmod(0o644)
        result = {"ok": True, "status": "created", "ca_key": str(ca_key), "ca_public_key": str(ca_pub)}
    return result


def cmd_ca_init(args):
    require_root("ca init")
    result = create_ca_key(args)
    if args.json:
        emit_json(result)
    else:
        print(f"{result['status']}: {result['ca_key']}")
        print(f"public: {result['ca_public_key']}")
    return 0


def cmd_policy_show(args):
    policy = load_policy(args.policy_file)
    active = effective_policy(policy, getattr(args, "user", None))
    if args.json:
        emit_json({"ok": True, "policy": policy, "effective": active})
    else:
        print(f"policy: {policy['path']}")
        if getattr(args, "user", None):
            print(f"user: {args.user}")
        print(f"max-time: {format_duration(active['max_time_seconds'])}")
        print(f"max-connections: {active['max_connections']}")
    return 0


def cmd_policy_install(args):
    require_root("policy install")
    policy = write_policy(args.policy_file, args.max_time, args.max_connections, args.user)
    active = effective_policy(policy, args.user)
    if args.json:
        emit_json({"ok": True, "policy": policy, "effective": active})
    else:
        print(f"policy: {policy['path']}")
        if args.user:
            print(f"user: {args.user}")
        print(f"max-time: {format_duration(active['max_time_seconds'])}")
        print(f"max-connections: {active['max_connections']}")
    return 0


def cmd_cert_issue(args):
    require_root("cert issue")
    public_key_text = read_text_source(args.public_key, args.public_key_file, "public-key")
    seconds = lifetime_seconds(args)
    principal = args.username or args.principal
    if not principal:
        raise SSHFlingError("Missing --username.", 2)
    result = sign_user_certificate(
        ca_key=args.ca_key,
        public_key_text=public_key_text,
        principal=principal,
        seconds=seconds,
        key_id=args.key_id,
        serial=args.serial,
        out_file=args.out,
        source_address=args.source_address,
        session_wrapper=args.session_wrapper,
        policy_file=args.policy_file,
        login_user=args.login_user,
        permit_pty=not args.no_pty,
    )

    if args.json:
        emit_json(result)
    else:
        if result["out"]:
            print(result["out"])
        else:
            print(result["certificate"])
    return 0


def default_cert_out(public_key_file):
    if not public_key_file:
        return None
    path = Path(public_key_file).expanduser()
    if path.name.endswith(".pub"):
        return str(path.with_name(path.name[:-4] + "-cert.pub"))
    return str(path.with_name(path.name + "-cert.pub"))


def private_key_hint(public_key_file):
    if not public_key_file:
        return None
    path = Path(public_key_file).expanduser()
    if path.name.endswith(".pub"):
        return str(path.with_name(path.name[:-4]))
    return str(path)


def create_temp_client_key(username, session_dir):
    stamp = dt.datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    safe_username = re.sub(r"[^A-Za-z0-9_.-]+", "_", username).strip("._-") or random_username()
    base_dir = Path(session_dir).expanduser().resolve() / f"{safe_username}-{stamp}-{secrets.token_hex(4)}"
    base_dir.mkdir(parents=True, exist_ok=False)
    key_path = base_dir / "id_ed25519"
    run(["ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-C", f"sshfling-{safe_username}", "-f", str(key_path)], capture=True)
    key_path.chmod(0o600)
    Path(str(key_path) + ".pub").chmod(0o644)
    return {"private_key": str(key_path), "public_key": str(key_path) + ".pub", "generated_key": True}


def random_username(prefix=DEFAULT_TEMP_USERNAME_PREFIX):
    return f"{prefix}{secrets.randbelow(1000):03d}"


def default_login_shell():
    for candidate in ["/bin/bash", "/bin/sh"]:
        if Path(candidate).exists():
            return candidate
    return "/bin/sh"


def is_ssh_connect_target(value):
    if value.startswith("-") or "/" in value or value.count("@") != 1:
        return False
    user, host = value.split("@", 1)
    return bool(user and host and not any(ch.isspace() for ch in value))


def maybe_connect_argv(argv):
    subcommands = {
        "doctor",
        "setup",
        "shutdown",
        "list",
        "ca",
        "cert",
        "policy",
        "host",
        "serve",
        "web",
        "web-hash",
        "init",
        "key",
        "network",
        "server",
        "client",
        "test-timeout",
        "compose",
        "package",
        "password",
        "detached",
        "_detached-supervisor",
    }
    for index, token in enumerate(argv):
        if token == "--":
            continue
        if is_ssh_connect_target(token):
            return argv[:index], token, argv[index + 1 :]
        if not token.startswith("-"):
            if token in subcommands:
                return None
    return None


def cmd_connect(before_args, target, after_args):
    ssh_bin = os.environ.get("SSHFLING_SSH_BIN", "ssh")
    ssh_args = [
        ssh_bin,
        "-o",
        "PreferredAuthentications=password,keyboard-interactive",
        "-o",
        "PubkeyAuthentication=no",
    ] + before_args + [target] + after_args

    if os.environ.get("SSHFLING_CONNECT_DRY_RUN"):
        print(shlex.join(ssh_args))
        return 0

    try:
        os.execvp(ssh_bin, ssh_args)
    except FileNotFoundError as exc:
        raise SSHFlingError(f"Missing command: {ssh_bin}", 127) from exc


def validate_unix_username(username):
    if not re.fullmatch(r"[a-z_][a-z0-9_-]{0,31}", username):
        raise SSHFlingError(
            "Password mode requires a Linux username matching [a-z_][a-z0-9_-]{0,31}.",
            2,
            username=username,
        )


def require_password_host_tools():
    missing = [name for name in ["useradd", "chpasswd"] if not command_path(name)]
    if missing:
        raise SSHFlingError(
            "Password grant setup requires Linux account tools. Install shadow/passwd tooling, or use certificate mode.",
            127,
            missing=missing,
        )


def set_user_password(username, password):
    run_with_input(["chpasswd"], f"{username}:{password}\n", capture=True)
    if command_path("usermod"):
        run(["usermod", "--unlock", username], capture=True, check=False)
    if command_path("chage"):
        run(["chage", "-E", "-1", username], capture=True, check=False)


def ensure_unix_user(username):
    if run(["id", "-u", username], capture=True, check=False).returncode == 0:
        return {"user": username, "created": False}
    run(["useradd", "--create-home", "--shell", default_login_shell(), username])
    return {"user": username, "created": True}


def password_force_command(username, seconds, expires_at, session_wrapper, policy_file):
    return f"{session_wrapper} --max-seconds {seconds} --max-connections 1 --username {username} --login-user {username} --policy-file {policy_file} --expires-at {expires_at}"


def password_grant_config(username, force_command):
    return f"""# Managed by sshfling password grant for {username}.
Match User {username}
    PasswordAuthentication yes
    KbdInteractiveAuthentication no
    PubkeyAuthentication no
    AuthenticationMethods password
    ForceCommand {force_command}
    AllowTcpForwarding no
    X11Forwarding no
    PermitTunnel no
"""


def cmd_setup_password(args):
    require_root("temporary password SSH access")
    require_password_host_tools()
    if not args.username:
        args.username = random_username()
    validate_unix_username(args.username)

    policy = load_policy(args.policy_file)
    active_policy = effective_policy(policy, args.username)
    seconds = lifetime_seconds(args, active_policy["max_time_seconds"])
    if seconds <= 0:
        raise SSHFlingError("Password lifetime must be positive.", 2)
    if seconds > active_policy["max_time_seconds"]:
        raise SSHFlingError(f"Password lifetime cannot exceed {format_duration(active_policy['max_time_seconds'])}.", 2)

    previous_metadata = read_password_grant_metadata(args.password_grant_dir, args.username)
    pre_prune = prune_password_grants(args.password_grant_dir, username=args.username, dry_run=args.dry_run)
    expires_at = int(time.time()) + seconds
    password = secrets.token_urlsafe(18)
    if args.dry_run:
        user_result = {"user": args.username, "created": run(["id", "-u", args.username], capture=True, check=False).returncode != 0, "dry_run": True}
    else:
        user_result = ensure_unix_user(args.username)
        set_user_password(args.username, password)

    wrapper_path = Path(args.session_wrapper).expanduser()
    config_dir = Path(args.password_sshd_config_dir).expanduser()
    config_path = config_dir / f"91-sshfling-password-{args.username}.conf"
    force_command = password_force_command(args.username, seconds, expires_at, str(wrapper_path), args.policy_file)
    config = password_grant_config(args.username, force_command)
    created_user = bool(user_result.get("created")) or bool((previous_metadata or {}).get("created_user"))
    metadata = {
        "version": 1,
        "auth": "password",
        "managed_by": "sshfling",
        "username": args.username,
        "created_user": created_user,
        "created_at": int(time.time()),
        "seconds": seconds,
        "expires_at": expires_at,
        "config_path": str(config_path),
        "session_wrapper": str(wrapper_path),
        "policy_file": args.policy_file,
    }

    results = [
        {"pre_prune": pre_prune},
        install_file(resource_file("production/sshfling-session"), wrapper_path, 0o755, args.dry_run),
        write_if_changed(config_path, config, 0o644, args.dry_run),
        write_password_grant_metadata(args.password_grant_dir, args.username, metadata, args.dry_run),
        user_result,
    ]

    if not args.dry_run and args.validate:
        results.append(
            validate_sshd_effective(
                args.username,
                [
                    "passwordauthentication yes",
                    "kbdinteractiveauthentication no",
                    "pubkeyauthentication no",
                    "authenticationmethods password",
                    f"forcecommand {force_command}",
                ],
                config_path,
            )
        )

    if not args.dry_run:
        results.append(reload_sshd())

    server_host = detect_server_host()
    payload = {
        "ok": True,
        "auth": "password",
        "username": args.username,
        "password": password,
        "seconds": seconds,
        "expires_at": expires_at,
        "expires_at_utc": dt.datetime.fromtimestamp(expires_at, UTC).isoformat(),
        "server": server_host,
        "ssh_command": f"sshfling {args.username}@{server_host}",
        "results": results,
    }

    if args.json:
        emit_json(payload)
    else:
        print(f"username: {payload['username']}")
        print(f"password: {payload['password']}")
        print(f"time: {seconds}s")
        print(f"expires: {payload['expires_at_utc']}")
        print(f"connect: {payload['ssh_command']}")
    return 0


def cmd_setup(args):
    require_root("temporary SSH access")
    if getattr(args, "password", False):
        return cmd_setup_password(args)
    if not args.username:
        args.username = random_username()
    ca_key = Path(args.ca_key).expanduser().resolve()
    ca_pub = Path(str(ca_key) + ".pub")
    if not ca_key.exists() or not ca_pub.exists():
        ca_result = create_ca_key(argparse.Namespace(ca_key=str(ca_key), force=False))
    else:
        ca_result = {"ok": True, "status": "exists", "ca_key": str(ca_key), "ca_public_key": str(ca_pub)}

    key_material = {"generated_key": False, "private_key": None, "public_key": args.public_key_file}
    public_key_file = args.public_key_file
    if not args.public_key and not public_key_file:
        key_material = create_temp_client_key(args.username, args.session_dir)
        public_key_file = key_material["public_key"]
    public_key_text = read_text_source(args.public_key, public_key_file, "public-key")
    out_file = args.out if args.out else default_cert_out(public_key_file)
    seconds = lifetime_seconds(args)
    login_user = args.login_user or args.username

    result = sign_user_certificate(
        ca_key=str(ca_key),
        public_key_text=public_key_text,
        principal=args.username,
        seconds=seconds,
        key_id=args.key_id,
        out_file=out_file,
        source_address=args.source_address,
        session_wrapper=args.session_wrapper,
        policy_file=args.policy_file,
        login_user=login_user,
        permit_pty=not args.no_pty,
    )
    result["ca"] = ca_result
    result.update(key_material)

    key_hint = key_material["private_key"] or private_key_hint(public_key_file)
    server_host = detect_server_host()
    result["server"] = server_host
    if key_hint:
        result["ssh_command"] = f"ssh -i {key_hint} {login_user}@{server_host}"
    else:
        result["ssh_command"] = f"ssh {login_user}@{server_host}"

    if args.json:
        emit_json(result)
    else:
        print(f"username: {args.username}")
        print(f"time: {seconds}s")
        if result.get("private_key"):
            print(f"private-key: {result['private_key']}")
        if result["out"]:
            print(f"cert: {result['out']}")
        else:
            print(result["certificate"])
        print(f"ssh: {result['ssh_command']}")
    return 0


def process_exists(pid):
    if os.name == "nt":
        try:
            import ctypes
            from ctypes import wintypes

            access = 0x1000  # PROCESS_QUERY_LIMITED_INFORMATION
            kernel32 = ctypes.windll.kernel32
            kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
            kernel32.OpenProcess.restype = wintypes.HANDLE
            kernel32.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
            kernel32.GetExitCodeProcess.restype = wintypes.BOOL
            kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
            kernel32.CloseHandle.restype = wintypes.BOOL

            handle = kernel32.OpenProcess(access, False, int(pid))
            if not handle:
                return False
            try:
                exit_code = wintypes.DWORD()
                if not kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                    return False
                return exit_code.value == 259  # STILL_ACTIVE
            finally:
                kernel32.CloseHandle(handle)
        except Exception:
            return False
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


def terminate_windows_process(pid):
    try:
        import ctypes
        from ctypes import wintypes

        access = 0x0001  # PROCESS_TERMINATE
        kernel32 = ctypes.windll.kernel32
        kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel32.OpenProcess.restype = wintypes.HANDLE
        kernel32.TerminateProcess.argtypes = [wintypes.HANDLE, wintypes.UINT]
        kernel32.TerminateProcess.restype = wintypes.BOOL
        kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel32.CloseHandle.restype = wintypes.BOOL

        handle = kernel32.OpenProcess(access, False, int(pid))
        if not handle:
            return False
        try:
            return bool(kernel32.TerminateProcess(handle, 1))
        finally:
            kernel32.CloseHandle(handle)
    except Exception:
        return False


def child_pids(pid):
    if not command_path("pgrep"):
        return []
    proc = run(["pgrep", "-P", str(pid)], capture=True, check=False)
    if proc.returncode not in (0, 1):
        return []
    pids = []
    for line in proc.stdout.splitlines():
        try:
            pids.append(int(line.strip()))
        except ValueError:
            pass
    return pids


def kill_process_tree(pid, sig):
    for child in child_pids(pid):
        kill_process_tree(child, sig)
    try:
        os.kill(pid, sig)
    except ProcessLookupError:
        pass


def user_uid(username):
    proc = run(["id", "-u", username], capture=True, check=False)
    if proc.returncode != 0:
        raise SSHFlingError(f"Unknown login user: {username}", 2, stderr=proc.stderr)
    return proc.stdout.strip()


def find_sshfling_sessions(login_user=None, session_username=None):
    if not command_path("ps"):
        raise SSHFlingError("ps is required to inspect active sshfling sessions.", 127)

    target_uid = None
    if login_user:
        target_uid = user_uid(login_user)

    proc = run(["ps", "-eo", "pid=,ppid=,uid=,etimes=,args="], capture=True, check=False)
    if proc.returncode != 0:
        raise SSHFlingError("Could not find active sshfling sessions.", proc.returncode, stderr=proc.stderr)

    self_pid = os.getpid()
    process_rows = []
    matches = {}
    for line in proc.stdout.splitlines():
        parts = line.strip().split(None, 4)
        if len(parts) < 5:
            continue
        try:
            pid = int(parts[0])
            ppid = int(parts[1])
            age_seconds = int(parts[3])
        except ValueError:
            continue
        uid = parts[2]
        command = parts[4]
        process_rows.append({"pid": pid, "ppid": ppid, "uid": uid, "age_seconds": age_seconds, "command": command})
        if pid == self_pid:
            continue
        if target_uid is not None and uid != target_uid:
            continue
        try:
            tokens = shlex.split(command)
        except ValueError:
            tokens = command.split()
        if not tokens:
            continue
        first = Path(tokens[0]).name
        second = Path(tokens[1]).name if len(tokens) > 1 else ""
        is_session_wrapper = first == "sshfling-session" or (first in {"bash", "sh"} and second == "sshfling-session")
        if is_session_wrapper:
            username = None
            max_seconds = None
            for index, token in enumerate(tokens):
                if token == "--username" and index + 1 < len(tokens):
                    username = tokens[index + 1]
                elif token.startswith("--username="):
                    username = token.split("=", 1)[1]
                elif token == "--max-seconds" and index + 1 < len(tokens):
                    max_seconds = tokens[index + 1]
                elif token.startswith("--max-seconds="):
                    max_seconds = token.split("=", 1)[1]
            matches[pid] = {
                "pid": pid,
                "ppid": ppid,
                "uid": uid,
                "username": username,
                "age_seconds": age_seconds,
                "max_seconds": int(max_seconds) if max_seconds and max_seconds.isdigit() else None,
                "status": "processing",
                "command": command,
            }

    children_by_ppid = {}
    for row in process_rows:
        children_by_ppid.setdefault(row["ppid"], []).append(row["pid"])
    for children in children_by_ppid.values():
        children.sort()

    def descendant_pids(root_pid):
        descendants = []
        stack = list(children_by_ppid.get(root_pid, []))
        seen = set()
        while stack:
            child = stack.pop(0)
            if child in seen:
                continue
            seen.add(child)
            descendants.append(child)
            stack.extend(children_by_ppid.get(child, []))
        return descendants

    sessions = [item for pid, item in matches.items() if item["ppid"] not in matches]
    for session in sessions:
        process_pids = descendant_pids(session["pid"])
        session["process_pid"] = process_pids[0] if process_pids else None
        session["process_pids"] = process_pids
    if session_username:
        sessions = [item for item in sessions if item["username"] == session_username]
    return sorted(sessions, key=lambda item: (item["username"] or "", item["pid"]))


def find_sshfling_session_pids(login_user=None, session_username=None):
    return [session["pid"] for session in find_sshfling_sessions(login_user, session_username)]


def cmd_list(args):
    require_root("list")
    sessions = find_sshfling_sessions(getattr(args, "login_user", None), getattr(args, "username", None))
    payload = {"ok": True, "sessions": sessions, "count": len(sessions)}
    if args.json:
        emit_json(payload)
    else:
        if not sessions:
            print("no active sshfling sessions")
        else:
            print("username pid process-pid uid age max")
            for session in sessions:
                username = session["username"] or "-"
                process_pid = session["process_pid"] if session["process_pid"] is not None else "-"
                max_seconds = session["max_seconds"] if session["max_seconds"] is not None else "-"
                print(f"{username} {session['pid']} {process_pid} {session['uid']} {session['age_seconds']}s {max_seconds}")
    return 0


def cmd_kill(args):
    require_root("kill")
    login_user = getattr(args, "login_user", None)
    session_username = getattr(args, "session_username", None) or getattr(args, "username", None)
    kill_value = getattr(args, "kill", None)
    if isinstance(kill_value, str):
        session_username = kill_value
        login_user = getattr(args, "login_user", None)
    payload = kill_sshfling_sessions(login_user, session_username)
    if args.json:
        emit_json(payload)
    else:
        print(f"killed {payload['killed']} active sshfling session(s)")
    return 0


def kill_sshfling_sessions(login_user=None, session_username=None):
    pids = find_sshfling_session_pids(login_user, session_username)

    for pid in pids:
        kill_process_tree(pid, signal.SIGTERM)

    deadline = time.time() + 2
    while time.time() < deadline and any(process_exists(pid) for pid in pids):
        time.sleep(0.1)

    remaining = [pid for pid in pids if process_exists(pid)]
    for pid in remaining:
        kill_process_tree(pid, signal.SIGKILL)

    return {"ok": True, "killed": len(pids), "pids": pids, "login_user": login_user, "username": session_username}


def utc_timestamp():
    return int(time.time())


def utc_iso(timestamp=None):
    timestamp = utc_timestamp() if timestamp is None else int(timestamp)
    return dt.datetime.fromtimestamp(timestamp, UTC).isoformat().replace("+00:00", "Z")


def detached_root(path=None):
    if path:
        return Path(path).expanduser().resolve()
    env_path = os.environ.get("SSHFLING_DETACHED_DIR")
    if env_path:
        return Path(env_path).expanduser().resolve()
    return (Path.home() / DEFAULT_DETACHED_DIR).resolve()


def validate_detached_name(name):
    if not name or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}", name):
        raise SSHFlingError("Detached job name must match [A-Za-z0-9][A-Za-z0-9_.-]{0,79}.", 2, name=name)


def detached_paths(root, name):
    validate_detached_name(name)
    root = detached_root(root)
    return {
        "root": root,
        "metadata": root / f"{name}.json",
        "stdout": root / f"{name}.out.log",
        "stderr": root / f"{name}.err.log",
    }


def write_json_atomic(path, payload, mode=0o600):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    tmp_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    tmp_path.chmod(mode)
    tmp_path.replace(path)


def read_json_file(path):
    return json.loads(Path(path).read_text())


def detached_command_from(args):
    command = list(args.detached_args or [])
    if command and command[0] == "--":
        command = command[1:]
    if not command:
        raise SSHFlingError("Pass the detached command after --.", 2)
    return command


def start_new_process_kwargs(detached=False):
    if os.name == "nt":
        flags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        if detached:
            flags |= getattr(subprocess, "DETACHED_PROCESS", 0)
        return {"creationflags": flags}
    return {"start_new_session": True}


def terminate_detached_process(pid, force=False):
    sig = signal.SIGKILL if force else signal.SIGTERM
    if os.name == "nt" and command_path("taskkill"):
        cmd = ["taskkill", "/PID", str(pid), "/T", "/F"]
        proc = run(cmd, capture=True, check=False, timeout=5)
        if proc.returncode == 0 or not process_exists(pid):
            return True
        return terminate_windows_process(pid)
    if os.name != "nt":
        try:
            os.killpg(pid, sig)
            return True
        except ProcessLookupError:
            return False
        except OSError:
            pass
    kill_process_tree(pid, sig)
    return True


def refresh_detached_job(job):
    status = job.get("status")
    pid = job.get("pid")
    supervisor_pid = job.get("supervisor_pid")
    if status in {"starting", "processing"}:
        pid_alive = bool(pid and process_exists(int(pid)))
        supervisor_alive = bool(supervisor_pid and process_exists(int(supervisor_pid)))
        if pid_alive:
            job["status"] = "processing"
        elif not supervisor_alive:
            job["status"] = "unknown"
            job.setdefault("completed_at", utc_timestamp())
            job.setdefault("completed_at_utc", utc_iso(job["completed_at"]))
    return job


def detached_metadata_claims_active(job, now=None):
    if job.get("status") not in {"starting", "processing"}:
        return False
    expires_at = job.get("expires_at")
    if expires_at is None:
        return True
    try:
        return int(expires_at) > (utc_timestamp() if now is None else int(now))
    except (TypeError, ValueError):
        return True


def load_detached_jobs(root):
    root = detached_root(root)
    jobs = []
    if not root.exists():
        return jobs
    for path in sorted(root.glob("*.json")):
        try:
            job = read_json_file(path)
        except (OSError, json.JSONDecodeError):
            continue
        if job.get("managed_by") != "sshfling" or not job.get("name"):
            continue
        job["metadata_path"] = str(path)
        jobs.append(refresh_detached_job(job))
    return jobs


def cmd_detached_start(args):
    seconds = lifetime_seconds(args, MAX_TIME_SECONDS)
    if seconds < 1:
        raise SSHFlingError("Detached job lifetime must be positive.", 2)
    if seconds > MAX_TIME_SECONDS:
        raise SSHFlingError(f"Detached job lifetime cannot exceed {format_duration(MAX_TIME_SECONDS)}.", 2)
    validate_detached_name(args.name)

    command = detached_command_from(args)
    paths = detached_paths(args.detached_dir, args.name)
    existing = read_json_file(paths["metadata"]) if paths["metadata"].exists() else None
    if existing:
        if detached_metadata_claims_active(existing):
            raise SSHFlingError(f"Detached job is already active: {args.name}", 2, pid=existing.get("pid"))
        existing = refresh_detached_job(existing)
        if existing.get("status") in {"starting", "processing"}:
            raise SSHFlingError(f"Detached job is already active: {args.name}", 2, pid=existing.get("pid"))
        if not args.replace:
            raise SSHFlingError(
                f"Detached job already exists: {args.name}. Use --replace after it is inactive.",
                2,
                status=existing.get("status"),
            )

    root = paths["root"]
    root.mkdir(parents=True, exist_ok=True)
    try:
        root.chmod(0o700)
    except OSError:
        pass
    if existing and args.replace:
        for log_path in (paths["stdout"], paths["stderr"]):
            try:
                log_path.unlink()
            except FileNotFoundError:
                pass

    started_at = utc_timestamp()
    job = {
        "version": 1,
        "managed_by": "sshfling",
        "name": args.name,
        "status": "starting",
        "pid": None,
        "supervisor_pid": None,
        "command": command,
        "cwd": str(Path(args.cwd).expanduser().resolve()),
        "seconds": seconds,
        "started_at": started_at,
        "started_at_utc": utc_iso(started_at),
        "expires_at": started_at + seconds,
        "expires_at_utc": utc_iso(started_at + seconds),
        "metadata_path": str(paths["metadata"]),
        "stdout_path": str(paths["stdout"]),
        "stderr_path": str(paths["stderr"]),
    }
    write_json_atomic(paths["metadata"], job)

    supervisor_cmd = [
        sys.executable,
        str(Path(__file__).resolve()),
        "_detached-supervisor",
        "--metadata",
        str(paths["metadata"]),
        "--",
    ] + command
    try:
        supervisor = subprocess.Popen(
            supervisor_cmd,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
            **start_new_process_kwargs(detached=True),
        )
    except OSError as exc:
        job["status"] = "failed"
        job["error"] = str(exc)
        job["completed_at"] = utc_timestamp()
        job["completed_at_utc"] = utc_iso(job["completed_at"])
        write_json_atomic(paths["metadata"], job)
        raise SSHFlingError(f"Could not start detached supervisor: {exc}", 1) from exc

    deadline = time.time() + 5
    while time.time() < deadline:
        try:
            current = read_json_file(paths["metadata"])
        except (OSError, json.JSONDecodeError):
            current = job
        if current.get("pid") or current.get("status") not in {"starting", "processing"}:
            job = current
            break
        time.sleep(0.05)
    else:
        job = read_json_file(paths["metadata"])

    job = refresh_detached_job(job)
    if job.get("status") == "failed" and not job.get("pid"):
        error = job.get("error") or "detached command exited before it could start"
        raise SSHFlingError(f"Detached job failed to start: {error}", 1, job=job)

    payload = {"ok": True, "job": job}
    if args.json:
        emit_json(payload)
    else:
        item = payload["job"]
        print(f"name: {item['name']}")
        print(f"status: {item['status']}")
        print(f"pid: {item.get('pid') or '-'}")
        print(f"supervisor-pid: {item.get('supervisor_pid') or '-'}")
        print(f"stdout: {item['stdout_path']}")
        print(f"stderr: {item['stderr_path']}")
    return 0


def cmd_detached_list(args):
    jobs = load_detached_jobs(args.detached_dir)
    if args.name:
        jobs = [job for job in jobs if job.get("name") == args.name]
    payload = {"ok": True, "jobs": jobs, "count": len(jobs)}
    if args.json:
        emit_json(payload)
    else:
        if not jobs:
            print("no detached sshfling jobs")
        else:
            print("name status pid supervisor-pid age max stdout")
            now = utc_timestamp()
            for job in jobs:
                age = max(0, now - int(job.get("started_at", now)))
                print(
                    f"{job.get('name', '-')} {job.get('status', '-')} {job.get('pid') or '-'} "
                    f"{job.get('supervisor_pid') or '-'} {age}s {job.get('seconds', '-')} {job.get('stdout_path', '-')}"
                )
    return 0


def cmd_detached_kill(args):
    paths = detached_paths(args.detached_dir, args.name)
    if not paths["metadata"].exists():
        raise SSHFlingError(f"Detached job does not exist: {args.name}", 2)
    job = read_json_file(paths["metadata"])
    targeted = []
    live_targets = []
    for pid_key in ["pid", "supervisor_pid"]:
        pid = job.get(pid_key)
        if not pid:
            continue
        pid = int(pid)
        if pid in targeted:
            continue
        targeted.append(pid)
        if process_exists(pid):
            live_targets.append(pid)
        terminate_detached_process(pid, force=False)

    deadline = time.time() + 2
    while time.time() < deadline:
        live = [pid for pid in targeted if process_exists(pid)]
        if not live:
            break
        time.sleep(0.1)

    remaining = [pid for pid in targeted if process_exists(pid)]
    for pid in remaining:
        terminate_detached_process(pid, force=True)

    job["status"] = "killed"
    job["killed_at"] = utc_timestamp()
    job["killed_at_utc"] = utc_iso(job["killed_at"])
    job["killed_pids"] = targeted
    job["live_pids_before_kill"] = live_targets
    write_json_atomic(paths["metadata"], job)
    payload = {"ok": True, "job": job, "killed": len(targeted), "pids": targeted}
    if args.json:
        emit_json(payload)
    else:
        print(f"killed {payload['killed']} detached process(es)")
    return 0


def cmd_detached_supervisor(args):
    metadata_path = Path(args.metadata).expanduser().resolve()
    job = read_json_file(metadata_path)
    command = detached_command_from(args)
    job["supervisor_pid"] = os.getpid()
    write_json_atomic(metadata_path, job)
    stdout_path = Path(job["stdout_path"])
    stderr_path = Path(job["stderr_path"])
    stdout_path.parent.mkdir(parents=True, exist_ok=True)
    stderr_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        with stdout_path.open("ab", buffering=0) as stdout, stderr_path.open("ab", buffering=0) as stderr:
            try:
                proc = subprocess.Popen(
                    command,
                    cwd=job["cwd"],
                    stdin=subprocess.DEVNULL,
                    stdout=stdout,
                    stderr=stderr,
                    close_fds=True,
                    **start_new_process_kwargs(detached=False),
                )
            except OSError as exc:
                job.update(
                    {
                        "status": "failed",
                        "error": str(exc),
                        "supervisor_pid": os.getpid(),
                        "completed_at": utc_timestamp(),
                    }
                )
                job["completed_at_utc"] = utc_iso(job["completed_at"])
                write_json_atomic(metadata_path, job)
                return 127

            job["pid"] = proc.pid
            job["supervisor_pid"] = os.getpid()
            job["status"] = "processing"
            write_json_atomic(metadata_path, job)

            timed_out = False
            while proc.poll() is None:
                if utc_timestamp() >= int(job["expires_at"]):
                    timed_out = True
                    terminate_detached_process(proc.pid, force=False)
                    try:
                        proc.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        terminate_detached_process(proc.pid, force=True)
                    break
                time.sleep(0.5)

            exit_code = proc.wait()
            job["exit_code"] = exit_code
            job["completed_at"] = utc_timestamp()
            job["completed_at_utc"] = utc_iso(job["completed_at"])
            if timed_out:
                job["status"] = "timed_out"
            elif exit_code == 0:
                job["status"] = "completed"
            else:
                job["status"] = "failed"
            write_json_atomic(metadata_path, job)
            return 0
    except Exception as exc:
        try:
            job.update({"status": "failed", "error": str(exc), "completed_at": utc_timestamp()})
            job["completed_at_utc"] = utc_iso(job["completed_at"])
            write_json_atomic(metadata_path, job)
        except Exception:
            pass
        return 1


def write_if_changed(path, content, mode=0o644, dry_run=False):
    path = Path(path)
    if dry_run:
        return {"path": str(path), "changed": not path.exists() or path.read_text() != content, "dry_run": True}
    path.parent.mkdir(parents=True, exist_ok=True)
    changed = not path.exists() or path.read_text() != content
    path.write_text(content)
    path.chmod(mode)
    return {"path": str(path), "changed": changed}


def install_file(src, dst, mode=0o755, dry_run=False):
    src = Path(src)
    dst = Path(dst)
    if dry_run:
        return {"path": str(dst), "source": str(src), "dry_run": True}
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    dst.chmod(mode)
    return {"path": str(dst), "source": str(src)}


def reload_sshd():
    override = os.environ.get("SSHFLING_SSHD_RELOAD_CMD")
    attempts = []
    commands = []

    if override:
        commands.append(shlex.split(override))
    if command_path("systemctl"):
        commands.extend([["systemctl", "reload", "sshd"], ["systemctl", "reload", "ssh"]])
    if command_path("service"):
        commands.extend([["service", "sshd", "reload"], ["service", "ssh", "reload"]])
    if command_path("rc-service"):
        commands.extend([["rc-service", "sshd", "reload"], ["rc-service", "ssh", "reload"]])
    if command_path("rcctl"):
        commands.append(["rcctl", "reload", "sshd"])
    if command_path("pkill"):
        commands.append(["pkill", "-HUP", "sshd"])

    for command in commands:
        proc = run(command, capture=True, check=False)
        attempts.append({"command": shlex.join(command), "returncode": proc.returncode})
        if proc.returncode == 0:
            return {"reloaded": "sshd", "command": shlex.join(command), "attempts": attempts}

    raise SSHFlingError("Could not reload sshd automatically; reload sshd manually.", 127, attempts=attempts)


def validate_sshd_effective(username=None, expected_lines=None, config_hint=None):
    run(["sshd", "-t"], capture=True)
    result = {"validated": "sshd -t"}
    if not expected_lines:
        return result

    proc = run(["sshd", "-T", "-C", f"user={username},host=localhost,addr=127.0.0.1"], capture=True)
    effective = "\n".join(line.strip().lower() for line in proc.stdout.splitlines())
    missing = [line for line in expected_lines if line.strip().lower() not in effective]
    if missing:
        raise SSHFlingError(
            "sshd syntax is valid, but the sshfling Match configuration is not active. Ensure sshd_config includes the managed config path.",
            2,
            missing=missing,
            config=str(config_hint) if config_hint else None,
        )
    result["validated_effective"] = "sshd -T"
    return result


def password_grant_metadata_path(grant_dir, username):
    validate_unix_username(username)
    return Path(grant_dir).expanduser() / f"{username}.json"


def read_password_grant_metadata(grant_dir, username):
    path = password_grant_metadata_path(grant_dir, username)
    if not path.exists():
        return None
    return json.loads(path.read_text())


def write_password_grant_metadata(grant_dir, username, metadata, dry_run=False):
    path = password_grant_metadata_path(grant_dir, username)
    if dry_run:
        return {"path": str(path), "dry_run": True}
    path.parent.mkdir(parents=True, exist_ok=True)
    path.parent.chmod(0o700)
    tmp_path = path.with_suffix(".json.tmp")
    tmp_path.write_text(json.dumps(metadata, indent=2, sort_keys=True) + "\n")
    tmp_path.chmod(0o600)
    tmp_path.replace(path)
    return {"path": str(path), "metadata": "written"}


def remove_password_grant_config(path, username, dry_run=False):
    path = Path(path)
    if not path.exists():
        return {"path": str(path), "status": "missing"}
    content = path.read_text()
    marker = f"# Managed by sshfling password grant for {username}."
    if marker not in content:
        raise SSHFlingError(f"Refusing to remove unmanaged sshd config: {path}", 2)
    if dry_run:
        return {"path": str(path), "would_remove": True, "dry_run": True}
    path.unlink()
    return {"path": str(path), "removed": True}


def remove_file(path, dry_run=False):
    path = Path(path)
    if not path.exists():
        return {"path": str(path), "status": "missing"}
    if path.is_dir():
        raise SSHFlingError(f"Refusing to remove directory as a file: {path}", 2)
    if dry_run:
        return {"path": str(path), "would_remove": True, "dry_run": True}
    path.unlink()
    return {"path": str(path), "removed": True}


def remove_managed_file(path, marker, dry_run=False, force=False):
    path = Path(path)
    if not path.exists():
        return {"path": str(path), "status": "missing"}
    content = path.read_text()
    if marker not in content and not force:
        raise SSHFlingError(f"Refusing to remove unmanaged file: {path}", 2)
    return remove_file(path, dry_run)


def remove_matching_file(path, expected_content, dry_run=False, force=False):
    path = Path(path)
    if not path.exists():
        return {"path": str(path), "status": "missing"}
    content = path.read_text()
    if content != expected_content and not force:
        raise SSHFlingError(
            f"Refusing to remove file with unexpected content: {path}. Re-run with matching --principal values or --force.",
            2,
        )
    return remove_file(path, dry_run)


def remove_empty_dir(path, dry_run=False):
    path = Path(path)
    if not path.exists():
        return {"path": str(path), "status": "missing"}
    if not path.is_dir():
        return {"path": str(path), "status": "not-directory"}
    if any(path.iterdir()):
        return {"path": str(path), "status": "not-empty"}
    if dry_run:
        return {"path": str(path), "would_remove_empty_dir": True, "dry_run": True}
    try:
        path.rmdir()
        return {"path": str(path), "removed_empty_dir": True}
    except OSError:
        return {"path": str(path), "status": "not-empty"}


def remove_policy_user(policy_file, username, dry_run=False):
    path = policy_file_path(policy_file)
    if not path.exists():
        return {"path": str(path), "status": "missing"}

    try:
        data = json.loads(path.read_text())
    except json.JSONDecodeError as exc:
        raise SSHFlingError(f"Invalid policy file: {path}", 2) from exc

    policy = normalize_policy(data)
    if username not in policy.get("users", {}):
        return {"path": str(path), "user": username, "status": "missing"}

    if dry_run:
        return {"path": str(path), "user": username, "would_remove": True, "dry_run": True}

    del policy["users"][username]
    path.write_text(json.dumps(policy, indent=2, sort_keys=True) + "\n")
    path.chmod(0o644)
    return {"path": str(path), "user": username, "removed": True}


def lock_password_user(username, dry_run=False):
    if run(["id", "-u", username], capture=True, check=False).returncode != 0:
        return {"user": username, "status": "missing"}
    if dry_run:
        return {"user": username, "would_lock": True, "dry_run": True}

    attempts = []
    locked = False
    expired = False
    if command_path("usermod"):
        proc = run(["usermod", "--lock", username], capture=True, check=False)
        attempts.append({"command": f"usermod --lock {username}", "returncode": proc.returncode})
        locked = proc.returncode == 0
    if command_path("passwd") and not locked:
        proc = run(["passwd", "-l", username], capture=True, check=False)
        attempts.append({"command": f"passwd -l {username}", "returncode": proc.returncode})
        locked = proc.returncode == 0
    if command_path("chage"):
        proc = run(["chage", "-E", "0", username], capture=True, check=False)
        attempts.append({"command": f"chage -E 0 {username}", "returncode": proc.returncode})
        expired = proc.returncode == 0

    if not locked:
        raise SSHFlingError(f"Could not lock expired password user: {username}", 1, attempts=attempts)
    return {"user": username, "locked": locked, "expired": expired, "attempts": attempts}


def delete_password_user(username, dry_run=False):
    if run(["id", "-u", username], capture=True, check=False).returncode != 0:
        return {"user": username, "status": "missing"}
    if dry_run:
        return {"user": username, "would_delete": True, "dry_run": True}
    if not command_path("userdel"):
        raise SSHFlingError("userdel is required for --delete-users.", 127)

    proc = run(["userdel", "--remove", username], capture=True, check=False)
    if proc.returncode != 0:
        proc = run(["userdel", username], capture=True, check=False)
    if proc.returncode != 0:
        raise SSHFlingError(f"Could not delete password user: {username}", proc.returncode, stderr=proc.stderr)
    return {"user": username, "deleted": True}


def prune_password_grants(grant_dir, username=None, all_grants=False, delete_users=False, dry_run=False):
    now = int(time.time())
    root = Path(grant_dir).expanduser()
    if username:
        validate_unix_username(username)
        paths = [password_grant_metadata_path(root, username)]
    elif root.exists():
        paths = sorted(root.glob("*.json"))
    else:
        paths = []

    results = []
    for path in paths:
        if not path.exists():
            results.append({"metadata_path": str(path), "status": "missing"})
            continue

        metadata = json.loads(path.read_text())
        grant_username = metadata.get("username") or path.stem
        validate_unix_username(grant_username)
        expires_at = int(metadata.get("expires_at", 0))
        if not all_grants and expires_at > now:
            results.append({"metadata_path": str(path), "username": grant_username, "status": "active", "expires_at": expires_at})
            continue

        item = {"metadata_path": str(path), "username": grant_username, "expires_at": expires_at, "status": "pruned"}
        config_path = metadata.get("config_path")
        if config_path:
            item["config"] = remove_password_grant_config(config_path, grant_username, dry_run)

        if metadata.get("created_user"):
            if delete_users:
                item["user"] = delete_password_user(grant_username, dry_run)
            else:
                item["user"] = lock_password_user(grant_username, dry_run)
        else:
            item["user"] = {"user": grant_username, "status": "left-existing-user"}

        if dry_run:
            item["metadata"] = {"path": str(path), "would_remove": True, "dry_run": True}
        else:
            path.unlink()
            item["metadata"] = {"path": str(path), "removed": True}
        results.append(item)
    return results


def cmd_password_prune(args):
    require_root("password prune")
    grant_results = prune_password_grants(
        args.password_grant_dir,
        username=args.username,
        all_grants=args.all,
        delete_users=args.delete_users,
        dry_run=args.dry_run,
    )
    results = list(grant_results)
    if not args.dry_run and any(item.get("config", {}).get("removed") for item in grant_results):
        results.append(reload_sshd())

    payload = {"ok": True, "results": results, "count": len(grant_results)}
    if args.json:
        emit_json(payload)
    else:
        if not grant_results:
            print("no password grants to prune")
        for item in grant_results:
            print(json.dumps(item, sort_keys=True))
    return 0


def cmd_host_install(args):
    require_root("host install")
    ca_pub = Path(args.ca_pub).expanduser().resolve()
    if not ca_pub.exists():
        raise SSHFlingError(f"CA public key does not exist: {ca_pub}", 2)

    trusted_ca = Path(args.trusted_ca).expanduser()
    principals_dir = Path(args.principals_dir).expanduser()
    principals_file = principals_dir / args.user
    wrapper_path = Path(args.session_wrapper).expanduser()
    sshd_config = Path(args.sshd_config).expanduser()
    principals = args.principal or [args.user]
    principal_lines = "\n".join(dict.fromkeys(principals)) + "\n"

    config = f"""# Managed by sshfling.
TrustedUserCAKeys {trusted_ca}
ExposeAuthInfo yes

Match User {args.user}
    AuthorizedPrincipalsFile {principals_dir}/%u
    AuthorizedKeysFile none
    PasswordAuthentication no
    KbdInteractiveAuthentication no
    AuthenticationMethods publickey
    AllowTcpForwarding no
    X11Forwarding no
    PermitTunnel no
"""

    results = []
    results.append(install_file(resource_file("production/sshfling-session"), wrapper_path, 0o755, args.dry_run))
    results.append(write_if_changed(trusted_ca, ca_pub.read_text(), 0o644, args.dry_run))
    results.append(write_if_changed(principals_file, principal_lines, 0o644, args.dry_run))
    results.append(write_if_changed(sshd_config, config, 0o644, args.dry_run))
    if args.max_time or args.max_connections:
        current = load_policy(args.policy_file)
        current_user_policy = effective_policy(current, args.user)
        max_time = args.max_time if args.max_time else current_user_policy["max_time_seconds"]
        max_connections = args.max_connections if args.max_connections else current_user_policy["max_connections"]
        if args.dry_run:
            results.append({"path": str(policy_file_path(args.policy_file)), "dry_run": True, "user": args.user, "max_time_seconds": max_time, "max_connections": max_connections})
        else:
            results.append(write_policy(args.policy_file, max_time, max_connections, args.user))

    if args.create_user and not args.dry_run:
        if run(["id", "-u", args.user], capture=True, check=False).returncode != 0:
            run(["useradd", "--create-home", "--shell", default_login_shell(), args.user])
            if command_path("openssl"):
                password = run(["openssl", "rand", "-base64", "32"], capture=True).stdout.strip()
                password_hash = run(["openssl", "passwd", "-6", password], capture=True).stdout.strip()
                run(["usermod", "--password", password_hash, args.user])
            results.append({"created_user": args.user})

    if not args.dry_run and args.validate:
        results.append(
            validate_sshd_effective(
                args.user,
                [
                    f"trustedusercakeys {trusted_ca}",
                    f"authorizedprincipalsfile {principals_dir}/%u",
                    "passwordauthentication no",
                    "authenticationmethods publickey",
                ],
                sshd_config,
            )
        )

    if not args.dry_run and args.reload:
        results.append(reload_sshd())

    payload = {"ok": True, "results": results}
    if args.json:
        emit_json(payload)
    else:
        for item in results:
            print(json.dumps(item, sort_keys=True))
    return 0


def cmd_host_uninstall(args):
    require_root("host uninstall")
    trusted_ca = Path(args.trusted_ca).expanduser()
    principals_dir = Path(args.principals_dir).expanduser()
    principals_file = principals_dir / args.user
    wrapper_path = Path(args.session_wrapper).expanduser()
    sshd_config = Path(args.sshd_config).expanduser()
    principals = args.principal or [args.user]
    principal_lines = "\n".join(dict.fromkeys(principals)) + "\n"

    results = [
        remove_managed_file(sshd_config, "# Managed by sshfling.", args.dry_run, args.force),
        remove_matching_file(principals_file, principal_lines, args.dry_run, args.force),
        remove_empty_dir(principals_dir, args.dry_run),
    ]

    if args.remove_ca:
        results.append(remove_file(trusted_ca, args.dry_run))
    if args.remove_wrapper:
        results.append(remove_file(wrapper_path, args.dry_run))
    if args.remove_policy_user:
        results.append(remove_policy_user(args.policy_file, args.user, args.dry_run))
    if args.delete_user:
        results.append(delete_password_user(args.user, args.dry_run))

    if not args.dry_run and args.validate:
        results.append(validate_sshd_effective())

    if not args.dry_run and args.reload:
        results.append(reload_sshd())

    payload = {"ok": True, "results": results}
    if args.json:
        emit_json(payload)
    else:
        for item in results:
            print(json.dumps(item, sort_keys=True))
    return 0


class IssuerHandler(http.server.BaseHTTPRequestHandler):
    server_version = "sshflingd/0.1"

    def send_json(self, status, payload):
        body = json.dumps(payload, sort_keys=True).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/healthz":
            self.send_json(200, {"ok": True, "service": "sshflingd", "version": VERSION})
            return
        self.send_json(404, {"ok": False, "error": "not found"})

    def do_POST(self):
        if self.path != "/v1/certificates":
            self.send_json(404, {"ok": False, "error": "not found"})
            return

        expected = self.server.auth_token
        actual = self.headers.get("Authorization", "")
        if actual != f"Bearer {expected}":
            self.send_json(401, {"ok": False, "error": "unauthorized"})
            return

        try:
            length = int(self.headers.get("Content-Length", "0"))
            body = self.rfile.read(length).decode("utf-8")
            request = json.loads(body)
            principal = request.get("principal")
            seconds = int(request.get("seconds", self.server.default_seconds))
            if principal not in self.server.allowed_principals:
                raise SSHFlingError(f"Principal is not allowed: {principal}", 403)
            if seconds > self.server.max_seconds:
                raise SSHFlingError(f"Requested seconds exceeds max_seconds={self.server.max_seconds}", 400)
            public_key = request.get("public_key", "").strip()
            if not public_key:
                raise SSHFlingError("Missing public_key.", 400)

            result = sign_user_certificate(
                ca_key=self.server.ca_key,
                public_key_text=public_key,
                principal=principal,
                seconds=seconds,
                key_id=request.get("key_id"),
                source_address=request.get("source_address"),
                session_wrapper=self.server.session_wrapper,
                policy_file=self.server.policy_file,
                login_user=request.get("login_user") or principal,
                permit_pty=bool(request.get("permit_pty", True)),
            )
            self.send_json(200, result)
        except SSHFlingError as exc:
            self.send_json(exc.code if exc.code >= 100 else 400, {"ok": False, "error": exc.message})
        except Exception as exc:
            self.send_json(500, {"ok": False, "error": str(exc)})

    def log_message(self, fmt, *args):
        eprint(f"{self.address_string()} - {fmt % args}")


def cmd_serve(args):
    require_root("serve")
    policy = load_policy(args.policy_file)
    default_policy_caps = effective_policy(policy)
    token = args.token or os.environ.get(args.token_env)
    if not token:
        raise SSHFlingError(f"Set {args.token_env} or pass --token before starting the issuer service.", 2)
    if args.max_seconds > default_policy_caps["max_time_seconds"]:
        raise SSHFlingError(f"Maximum issuer lifetime cannot exceed {format_duration(default_policy_caps['max_time_seconds'])}.", 2)
    if args.default_seconds > args.max_seconds:
        raise SSHFlingError("--default-seconds cannot exceed --max-seconds.", 2)

    if ":" not in args.listen:
        raise SSHFlingError("--listen must be host:port.", 2)
    host, port_text = args.listen.rsplit(":", 1)
    port = int(port_text)

    allowed = set()
    for raw in args.allowed_principal:
        allowed.update(part.strip() for part in raw.split(",") if part.strip())
    if not allowed:
        raise SSHFlingError("At least one --allowed-principal is required.", 2)

    server = http.server.ThreadingHTTPServer((host, port), IssuerHandler)
    server.auth_token = token
    server.ca_key = str(Path(args.ca_key).expanduser().resolve())
    server.allowed_principals = allowed
    server.max_seconds = args.max_seconds
    server.default_seconds = args.default_seconds
    server.session_wrapper = args.session_wrapper
    server.policy_file = policy["path"]

    eprint(f"sshflingd listening on {host}:{port}; allowed principals: {', '.join(sorted(allowed))}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        return 130
    return 0


def b64url(data):
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def b64url_decode(value):
    padding = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode((value + padding).encode("ascii"))


def make_password_hash(password, iterations=260000):
    salt = secrets.token_urlsafe(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), iterations)
    return f"pbkdf2_sha256${iterations}${salt}${b64url(digest)}"


def verify_web_password(password, password_hash=None, plain_password=None):
    if password_hash:
        try:
            scheme, iterations, salt, expected = password_hash.split("$", 3)
            if scheme != "pbkdf2_sha256":
                return False
            digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), int(iterations))
            return hmac.compare_digest(b64url(digest), expected)
        except Exception:
            return False
    if plain_password is not None:
        return hmac.compare_digest(password, plain_password)
    return False


def make_web_session(user, secret, max_age=28800):
    payload = {
        "user": user,
        "exp": int(time.time()) + max_age,
        "csrf": secrets.token_urlsafe(24),
    }
    body = b64url(json.dumps(payload, separators=(",", ":")).encode("utf-8"))
    sig = b64url(hmac.new(secret, body.encode("ascii"), hashlib.sha256).digest())
    return f"{body}.{sig}"


def verify_web_session(token, secret):
    try:
        body, sig = token.split(".", 1)
        expected = b64url(hmac.new(secret, body.encode("ascii"), hashlib.sha256).digest())
        if not hmac.compare_digest(sig, expected):
            return None
        payload = json.loads(b64url_decode(body).decode("utf-8"))
        if int(payload.get("exp", 0)) < int(time.time()):
            return None
        return payload
    except Exception:
        return None


def parse_cookie(header):
    cookies = {}
    for part in (header or "").split(";"):
        if "=" in part:
            key, value = part.strip().split("=", 1)
            cookies[key] = value
    return cookies


def render_web_page(title, body):
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{html.escape(title)}</title>
  <style>
    body {{ margin: 0; font: 14px/1.45 system-ui, -apple-system, Segoe UI, sans-serif; color: #172026; background: #f5f7f8; }}
    header {{ display: flex; align-items: center; justify-content: space-between; padding: 14px 20px; background: #172026; color: white; }}
    main {{ max-width: 1040px; margin: 0 auto; padding: 20px; }}
    h1 {{ margin: 0; font-size: 18px; font-weight: 650; }}
    h2 {{ margin: 0 0 12px; font-size: 15px; }}
    section, .login {{ background: white; border: 1px solid #d8e0e5; border-radius: 6px; padding: 16px; margin-bottom: 16px; }}
    label {{ display: block; font-weight: 600; margin: 10px 0 4px; }}
    input {{ box-sizing: border-box; width: 100%; max-width: 320px; padding: 8px 10px; border: 1px solid #b8c4cc; border-radius: 4px; font: inherit; }}
    button {{ padding: 8px 12px; border: 1px solid #172026; border-radius: 4px; background: #172026; color: white; font: inherit; cursor: pointer; }}
    button.secondary {{ background: white; color: #172026; }}
    table {{ width: 100%; border-collapse: collapse; }}
    th, td {{ padding: 8px; border-bottom: 1px solid #e4eaee; text-align: left; }}
    th {{ font-size: 12px; color: #4d5c66; text-transform: uppercase; }}
    .row {{ display: flex; gap: 12px; flex-wrap: wrap; align-items: end; }}
    .notice {{ color: #31516b; margin-bottom: 12px; }}
    .error {{ color: #9b1c1c; margin-bottom: 12px; }}
    .inline {{ display: inline; }}
    .inline input {{ width: auto; }}
  </style>
</head>
<body>
  <header><h1>SSHFling</h1></header>
  <main>{body}</main>
</body>
</html>
"""


def render_login(error=""):
    error_html = f"<div class=\"error\">{html.escape(error)}</div>" if error else ""
    return render_web_page(
        "SSHFling Login",
        f"""<div class="login">
  <h2>Login</h2>
  {error_html}
  <form method="post" action="/login">
    <label for="username">Username</label>
    <input id="username" name="username" autocomplete="username" required>
    <label for="password">Password</label>
    <input id="password" name="password" type="password" autocomplete="current-password" required>
    <p><button type="submit">Login</button></p>
  </form>
</div>""",
    )


def render_dashboard(policy, sessions, csrf, message=""):
    default_caps = effective_policy(policy)
    user_rows = []
    for username, caps in sorted(policy.get("users", {}).items()):
        user_rows.append(
            f"<tr><td>{html.escape(username)}</td><td>{format_duration(caps['max_time_seconds'])}</td><td>{caps['max_connections']}</td></tr>"
        )
    user_table = "".join(user_rows) or "<tr><td colspan=\"3\">No user overrides</td></tr>"

    session_rows = []
    for session in sessions:
        username = html.escape(session.get("username") or "-")
        process_pid = session.get("process_pid")
        process_pid = process_pid if process_pid is not None else "-"
        max_seconds = session["max_seconds"] if session["max_seconds"] is not None else "-"
        session_rows.append(
            f"""<tr>
  <td>{username}</td><td>{session['pid']}</td><td>{process_pid}</td><td>{session['uid']}</td><td>{session['age_seconds']}s</td><td>{max_seconds}</td>
  <td><form class="inline" method="post" action="/kill"><input type="hidden" name="csrf" value="{html.escape(csrf)}"><input type="hidden" name="username" value="{username}"><button type="submit">Kill</button></form></td>
</tr>"""
        )
    sessions_table = "".join(session_rows) or "<tr><td colspan=\"7\">No active sessions</td></tr>"
    message_html = f"<div class=\"notice\">{html.escape(message)}</div>" if message else ""

    return render_web_page(
        "SSHFling",
        f"""{message_html}
<section>
  <h2>Policy</h2>
  <table>
    <tr><th>User</th><th>Max Time</th><th>Max Connections</th></tr>
    <tr><td>default</td><td>{format_duration(default_caps['max_time_seconds'])}</td><td>{default_caps['max_connections']}</td></tr>
    {user_table}
  </table>
</section>
<section>
  <h2>Set Policy</h2>
  <form method="post" action="/policy">
    <input type="hidden" name="csrf" value="{html.escape(csrf)}">
    <div class="row">
      <div><label for="user">User</label><input id="user" name="user" placeholder="default"></div>
      <div><label for="max_time">Max Time</label><input id="max_time" name="max_time" value="{duration_input_value(default_caps['max_time_seconds'])}" required></div>
      <div><label for="max_connections">Max Connections</label><input id="max_connections" name="max_connections" type="number" min="1" max="10" value="{default_caps['max_connections']}" required></div>
      <button type="submit">Save</button>
    </div>
  </form>
</section>
<section>
  <h2>Sessions</h2>
  <table>
    <tr><th>Name</th><th>PID</th><th>Process PID</th><th>UID</th><th>Age</th><th>Max</th><th></th></tr>
    {sessions_table}
  </table>
</section>
<section>
  <h2>Kill Session</h2>
  <form method="post" action="/kill">
    <input type="hidden" name="csrf" value="{html.escape(csrf)}">
    <div class="row">
      <div><label for="kill_username">Name</label><input id="kill_username" name="username" placeholder="s432"></div>
      <button type="submit">Kill</button>
    </div>
  </form>
</section>
<form method="post" action="/logout">
  <input type="hidden" name="csrf" value="{html.escape(csrf)}">
  <button class="secondary" type="submit">Logout</button>
</form>""",
    )


class WebHandler(http.server.BaseHTTPRequestHandler):
    server_version = "sshfling-web/0.1"

    def send_html(self, status, body, headers=None):
        data = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        for key, value in (headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(data)

    def redirect(self, location, headers=None):
        self.send_response(303)
        self.send_header("Location", location)
        for key, value in (headers or {}).items():
            self.send_header(key, value)
        self.end_headers()

    def read_form(self):
        length = min(int(self.headers.get("Content-Length", "0")), 16384)
        raw = self.rfile.read(length).decode("utf-8")
        parsed = urllib.parse.parse_qs(raw, keep_blank_values=True)
        return {key: values[-1] for key, values in parsed.items()}

    def session_payload(self):
        token = parse_cookie(self.headers.get("Cookie")).get("sshfling_web")
        return verify_web_session(token, self.server.session_secret) if token else None

    def require_session(self):
        payload = self.session_payload()
        if not payload:
            self.redirect("/login")
            return None
        return payload

    def check_csrf(self, payload, form):
        return hmac.compare_digest(str(payload.get("csrf", "")), str(form.get("csrf", "")))

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == "/healthz":
            body = json.dumps({"ok": True, "service": "sshfling-web", "version": VERSION}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if parsed.path == "/login":
            if self.session_payload():
                self.redirect("/")
            else:
                self.send_html(200, render_login())
            return
        if parsed.path != "/":
            self.send_html(404, render_web_page("Not Found", "<section>Not found</section>"))
            return

        payload = self.require_session()
        if not payload:
            return
        query = urllib.parse.parse_qs(parsed.query)
        message = query.get("message", [""])[-1]
        policy = load_policy(self.server.policy_file)
        sessions = find_sshfling_sessions()
        self.send_html(200, render_dashboard(policy, sessions, payload["csrf"], message))

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        form = self.read_form()
        if parsed.path == "/login":
            username = form.get("username", "")
            password = form.get("password", "")
            if username == self.server.web_user and verify_web_password(password, self.server.password_hash, self.server.plain_password):
                token = make_web_session(username, self.server.session_secret)
                self.redirect("/", {"Set-Cookie": f"sshfling_web={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=28800"})
            else:
                self.send_html(401, render_login("Invalid login."))
            return

        payload = self.require_session()
        if not payload:
            return
        if not self.check_csrf(payload, form):
            self.send_html(403, render_web_page("Forbidden", "<section>Invalid request</section>"))
            return

        try:
            if parsed.path == "/logout":
                self.redirect("/login", {"Set-Cookie": "sshfling_web=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0"})
                return
            if parsed.path == "/policy":
                user = form.get("user", "").strip() or None
                max_time = duration_seconds(form.get("max_time", ""))
                max_connections = positive_int(form.get("max_connections", ""))
                write_policy(self.server.policy_file, max_time, max_connections, user)
                self.redirect("/?message=policy+saved")
                return
            if parsed.path == "/kill":
                username = form.get("username", "").strip() or None
                result = kill_sshfling_sessions(session_username=username)
                self.redirect(f"/?message=killed+{result['killed']}+session(s)")
                return
            self.send_html(404, render_web_page("Not Found", "<section>Not found</section>"))
        except (SSHFlingError, argparse.ArgumentTypeError, ValueError) as exc:
            policy = load_policy(self.server.policy_file)
            sessions = find_sshfling_sessions()
            self.send_html(400, render_dashboard(policy, sessions, payload["csrf"], str(exc)))

    def log_message(self, fmt, *args):
        eprint(f"{self.address_string()} - {fmt % args}")


def cmd_web_hash(args):
    password = os.environ.get(args.password_env)
    if password is None:
        password = getpass.getpass("Web password: ")
    print(make_password_hash(password))
    return 0


def cmd_web(args):
    require_root("web")
    password_hash = args.password_hash or os.environ.get(args.password_hash_env)
    plain_password = os.environ.get(args.password_env)
    if not password_hash and plain_password is None:
        raise SSHFlingError(f"Set {args.password_hash_env}, set {args.password_env}, or pass --password-hash.", 2)

    if ":" not in args.listen:
        raise SSHFlingError("--listen must be host:port.", 2)
    host, port_text = args.listen.rsplit(":", 1)
    if host not in {"127.0.0.1", "localhost", "::1"} and not args.allow_remote:
        raise SSHFlingError("Refusing non-local web bind without --allow-remote.", 2)
    port = int(port_text)

    session_secret_text = os.environ.get(args.session_secret_env) or secrets.token_urlsafe(32)
    server = http.server.ThreadingHTTPServer((host, port), WebHandler)
    server.web_user = args.user
    server.password_hash = password_hash
    server.plain_password = plain_password
    server.session_secret = session_secret_text.encode("utf-8")
    server.policy_file = str(policy_file_path(args.policy_file))

    eprint(f"sshfling web listening on http://{host}:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        return 130
    return 0


def cmd_key_generate(args):
    generate_key(args)
    return 0


def cmd_network_create(args):
    name = args.name
    proc = run(["docker", "network", "inspect", name], capture=True, check=False)
    created = False
    if proc.returncode != 0:
        run(["docker", "network", "create", name])
        created = True

    payload = {"ok": True, "name": name, "created": created}
    if args.json:
        emit_json(payload)
    else:
        print(("Created" if created else "Exists") + f": {name}")
    return 0


def cmd_server(args):
    project_dir = project_dir_from(args)
    env = {}
    if getattr(args, "session_seconds", None):
        env["SSH_SESSION_SECONDS"] = args.session_seconds

    if args.server_command == "up":
        cmd = compose_command(project_dir, "server") + ["up", "-d"]
        if args.build:
            cmd.append("--build")
        if args.force_recreate:
            cmd.append("--force-recreate")
        run(cmd, cwd=project_dir, env=env)
        return 0

    if args.server_command == "down":
        run(compose_command(project_dir, "server") + ["down"], cwd=project_dir)
        return 0

    if args.server_command == "restart":
        run(compose_command(project_dir, "server") + ["restart"], cwd=project_dir)
        return 0

    if args.server_command == "status":
        run(compose_command(project_dir, "server") + ["ps"], cwd=project_dir)
        return 0

    if args.server_command == "logs":
        cmd = compose_command(project_dir, "server") + ["logs"]
        if args.follow:
            cmd.append("--follow")
        if args.tail:
            cmd += ["--tail", str(args.tail)]
        run(cmd, cwd=project_dir)
        return 0

    raise SSHFlingError(f"Unknown server command: {args.server_command}", 2)


def cmd_client_run(args):
    project_dir = project_dir_from(args)
    remote_command = args.remote_command
    if remote_command and remote_command[0] == "--":
        remote_command = remote_command[1:]

    cmd = compose_command(project_dir, "client") + ["run", "--rm", "ssh-client"] + remote_command
    run(cmd, cwd=project_dir)
    return 0


def cmd_test_timeout(args):
    require_root("test-timeout")
    project_dir = project_dir_from(args)
    env = {"SSH_SESSION_SECONDS": args.seconds}
    run(
        compose_command(project_dir, "server") + ["up", "-d", "--build", "--force-recreate"],
        cwd=project_dir,
        env=env,
    )
    remote = f"echo start; date -u; sleep {args.sleep}; echo should-not-print"
    proc = run(
        compose_command(project_dir, "client") + ["run", "--rm", "ssh-client", remote],
        cwd=project_dir,
        check=False,
    )
    if proc.returncode != 124:
        raise SSHFlingError(
            f"Timeout test expected exit code 124, got {proc.returncode}",
            proc.returncode or 1,
        )
    return 0


def cmd_compose(args):
    project_dir = project_dir_from(args)
    compose_args = args.compose_args
    if compose_args and compose_args[0] == "--":
        compose_args = compose_args[1:]
    if not compose_args:
        raise SSHFlingError("Pass docker compose arguments after --.", 2)
    run(compose_command(project_dir, args.kind) + compose_args, cwd=project_dir)
    return 0


def cmd_package_build(args):
    root = source_root()
    package_types = ["deb", "rpm", "msi", "pkg"] if args.type == "all" else [args.type]
    results = []

    for package_type in package_types:
        if package_type == "deb":
            script = root / "packaging/build-deb.sh"
            cmd = ["bash", str(script)]
        elif package_type == "rpm":
            script = root / "packaging/build-rpm.sh"
            cmd = ["bash", str(script)]
        elif package_type == "msi":
            script = root / "packaging/build-msi.ps1"
            pwsh = command_path("pwsh") or command_path("powershell")
            if not pwsh:
                results.append(
                    {
                        "type": "msi",
                        "ok": False,
                        "message": "PowerShell is required to run packaging/build-msi.ps1.",
                    }
                )
                continue
            cmd = [pwsh, "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script)]
        elif package_type == "pkg":
            script = root / "packaging/build-pkg.sh"
            cmd = ["bash", str(script)]
        else:
            raise SSHFlingError(f"Unknown package type: {package_type}", 2)

        proc = run(cmd, cwd=root, capture=True, check=False)
        results.append(
            {
                "type": package_type,
                "ok": proc.returncode == 0,
                "exit_code": proc.returncode,
                "stdout": proc.stdout.strip(),
                "stderr": proc.stderr.strip(),
            }
        )

        if proc.returncode != 0 and args.type != "all":
            if args.json:
                emit_json({"ok": False, "results": results})
            else:
                sys.stdout.write(proc.stdout)
                sys.stderr.write(proc.stderr)
            return proc.returncode

    ok = all(result["ok"] for result in results)
    if args.json:
        emit_json({"ok": ok, "results": results})
    else:
        for result in results:
            status = "built" if result["ok"] else "skipped/failed"
            print(f"{status}: {result['type']}")
            if result.get("stdout"):
                print(result["stdout"])
            if result.get("stderr"):
                eprint(result["stderr"])

    return 0 if ok else 1


def positive_int(value):
    try:
        parsed = int(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("must be an integer") from exc
    if parsed < 1:
        raise argparse.ArgumentTypeError("must be positive")
    return parsed


def duration_seconds(value):
    raw = str(value).strip().lower()
    match = re.fullmatch(r"([1-9][0-9]*)([smhd]?)", raw)
    if not match:
        raise argparse.ArgumentTypeError("use seconds or a duration like 30s, 5m, 2h, or 1d")
    number = int(match.group(1))
    unit = match.group(2) or "s"
    return number * {"s": 1, "m": 60, "h": 3600, "d": 86400}[unit]


def lifetime_seconds(args, default=300):
    if getattr(args, "time", None) is not None:
        return args.time
    if getattr(args, "seconds", None) is not None:
        return args.seconds
    return default


def build_parser():
    parser = argparse.ArgumentParser(
        prog="sshfling",
        usage="sshfling [-t TIME] [--username USERNAME] [-k] [command ...]",
        description="Grant or kill temporary SSH access.",
        epilog="""examples:
  sudo sshfling
  sudo sshfling -t 10m
  sudo sshfling -t 5m --username temp-remote
  sudo sshfling list
  sudo sshfling -k s432
  sudo sshfling web
  sudo sshfling shutdown
  sudo sshfling -k
  sshfling s234@1.0.0.1
""",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--version", action="version", version=f"sshfling {VERSION}")
    parser.add_argument("--json", action="store_true", help="Emit stable JSON where supported.")
    parser.add_argument("-t", "--time", type=duration_seconds, help="Grant access for this long, for example 30s, 5m, 1h, or 24h.")
    parser.add_argument("--username", help="Temporary SSH username. Defaults to a random name like s123.")
    parser.add_argument("--login-user", help="Actual Unix login account if different from --username.")
    parser.add_argument("-p", "--password", action="store_true", help="Create temporary password SSH access instead of certificate access.")
    parser.add_argument("-k", "--kill", nargs="?", const=True, metavar="USERNAME", help="Kill active sshfling SSH session(s), optionally by name like s432.")
    parser.add_argument(
        "--project-dir",
        default=".",
        help="Deployment directory. Defaults to the current directory.",
    )
    parser.add_argument("--ca-key", default=str(default_ca_key_path()), help=argparse.SUPPRESS)
    parser.add_argument("--public-key", help=argparse.SUPPRESS)
    parser.add_argument("--public-key-file", help=argparse.SUPPRESS)
    parser.add_argument("--out", help=argparse.SUPPRESS)
    parser.add_argument("--session-dir", default=DEFAULT_SESSION_DIR, help=argparse.SUPPRESS)
    parser.add_argument("--key-id", help=argparse.SUPPRESS)
    parser.add_argument("--source-address", help=argparse.SUPPRESS)
    parser.add_argument("--session-wrapper", default=DEFAULT_SESSION_WRAPPER, help=argparse.SUPPRESS)
    parser.add_argument("--policy-file", default=DEFAULT_POLICY_FILE, help=argparse.SUPPRESS)
    parser.add_argument("--password-sshd-config-dir", default="/etc/ssh/sshd_config.d", help=argparse.SUPPRESS)
    parser.add_argument("--password-grant-dir", default=DEFAULT_PASSWORD_GRANT_DIR, help=argparse.SUPPRESS)
    parser.add_argument("--no-validate", dest="validate", action="store_false", help=argparse.SUPPRESS)
    parser.add_argument("--dry-run", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--no-pty", action="store_true", help=argparse.SUPPRESS)
    parser.set_defaults(validate=True)

    subparsers = parser.add_subparsers(dest="command")

    doctor = subparsers.add_parser("doctor", help="Check local tooling and deployment files.")
    doctor.set_defaults(func=cmd_doctor)

    setup = subparsers.add_parser("setup", help="Create a temporary SSH login. Normal use only needs --time and optionally --username.")
    setup.add_argument("-t", "--time", type=duration_seconds, required=True, help="Access lifetime, for example 30s, 5m, 1h, or 24h.")
    setup.add_argument("--username", help="Temporary SSH username. Defaults to a random name like s123.")
    setup.add_argument("--login-user", help="Actual Unix login account if different from --username.")
    setup.add_argument("-p", "--password", action="store_true", help="Create temporary password SSH access instead of certificate access.")
    setup.add_argument("--ca-key", default=str(default_ca_key_path()), help="CA private key path.")
    setup.add_argument("--public-key", help="Public key text to sign.")
    setup.add_argument("--public-key-file", help="Public key file to sign. If omitted, sshfling generates a temporary keypair.")
    setup.add_argument("--out", help="Certificate output path. Defaults beside the public key.")
    setup.add_argument("--session-dir", default=DEFAULT_SESSION_DIR, help=argparse.SUPPRESS)
    setup.add_argument("--key-id", help="Audit identifier stored in the certificate.")
    setup.add_argument("--source-address", help="Optional CIDR source-address certificate restriction.")
    setup.add_argument("--session-wrapper", default=DEFAULT_SESSION_WRAPPER, help="Forced command wrapper path on target hosts.")
    setup.add_argument("--policy-file", default=DEFAULT_POLICY_FILE, help=argparse.SUPPRESS)
    setup.add_argument("--password-sshd-config-dir", default="/etc/ssh/sshd_config.d", help=argparse.SUPPRESS)
    setup.add_argument("--password-grant-dir", default=DEFAULT_PASSWORD_GRANT_DIR, help=argparse.SUPPRESS)
    setup.add_argument("--no-validate", dest="validate", action="store_false", help="Skip sshd -t validation in password mode.")
    setup.add_argument("--dry-run", action="store_true", help="Show intended password-mode changes without writing files.")
    setup.add_argument("--no-pty", action="store_true", help="Do not permit interactive PTY sessions.")
    setup.set_defaults(func=cmd_setup, validate=True)

    password = subparsers.add_parser("password", help="Manage temporary password grants.")
    password_sub = password.add_subparsers(dest="password_command")
    password_prune = password_sub.add_parser("prune", help="Remove expired temporary password grants.")
    password_prune.add_argument("--username", help="Only prune this temporary password username.")
    password_prune.add_argument("--password-grant-dir", default=DEFAULT_PASSWORD_GRANT_DIR, help=argparse.SUPPRESS)
    password_prune.add_argument("--all", action="store_true", help="Prune active and expired tracked password grants.")
    password_prune.add_argument("--delete-users", action="store_true", help="Delete sshfling-created Unix users instead of locking them.")
    password_prune.add_argument("--dry-run", action="store_true", help="Show grants that would be pruned without changing files.")
    password_prune.set_defaults(func=cmd_password_prune)

    shutdown = subparsers.add_parser("shutdown", help="Kill active sshfling SSH session(s).")
    shutdown.add_argument("session_username", nargs="?", help="SSHFling session name to kill, for example s432.")
    shutdown.add_argument("--username", help="SSHFling session name to kill, for example s432.")
    shutdown.add_argument("--login-user", help="Login user whose sshfling sessions should be killed.")
    shutdown.set_defaults(func=cmd_kill)

    list_cmd = subparsers.add_parser("list", help="List active sshfling SSH sessions.")
    list_cmd.add_argument("--username", help="Only list this sshfling session name.")
    list_cmd.add_argument("--login-user", help="Only list sessions for this Unix login user.")
    list_cmd.set_defaults(func=cmd_list)

    ca = subparsers.add_parser("ca", help="Manage the SSH user certificate authority.")
    ca_sub = ca.add_subparsers(dest="ca_command")
    ca_init = ca_sub.add_parser("init", help="Create the SSH user CA keypair.")
    ca_init.add_argument("--ca-key", default=str(default_ca_key_path()), help="CA private key path.")
    ca_init.add_argument("--force", action="store_true", help="Replace an existing CA keypair.")
    ca_init.set_defaults(func=cmd_ca_init)

    cert = subparsers.add_parser("cert", help="Issue temporary SSH user certificates.")
    cert_sub = cert.add_subparsers(dest="cert_command")
    cert_issue = cert_sub.add_parser("issue", help="Sign a public key for temporary SSH access.")
    cert_issue.add_argument("--ca-key", default=str(default_ca_key_path()), help="CA private key path.")
    cert_issue.add_argument("--public-key", help="Public key text to sign.")
    cert_issue.add_argument("--public-key-file", help="Public key file to sign.")
    cert_issue.add_argument("--username", help="Temporary SSH username/certificate principal.")
    cert_issue.add_argument("--login-user", help="Unix login user for policy lookup and forced-command metadata.")
    cert_issue.add_argument("--principal", help=argparse.SUPPRESS)
    cert_issue.add_argument("-t", "--time", type=duration_seconds, help="Access lifetime, for example 30s, 5m, 1h, or 24h.")
    cert_issue.add_argument("--seconds", type=positive_int, default=300, help="Certificate and session lifetime.")
    cert_issue.add_argument("--key-id", help="Audit identifier stored in the certificate.")
    cert_issue.add_argument("--serial", type=positive_int, help=argparse.SUPPRESS)
    cert_issue.add_argument("--source-address", help="Optional CIDR source-address certificate restriction.")
    cert_issue.add_argument("--session-wrapper", default=DEFAULT_SESSION_WRAPPER, help="Forced command wrapper path on target hosts.")
    cert_issue.add_argument("--policy-file", default=DEFAULT_POLICY_FILE, help=argparse.SUPPRESS)
    cert_issue.add_argument("--no-pty", action="store_true", help="Do not permit interactive PTY sessions.")
    cert_issue.add_argument("--out", help="Write certificate to this path instead of stdout.")
    cert_issue.set_defaults(func=cmd_cert_issue)

    policy = subparsers.add_parser("policy", help="Show or install max time and connection limits.")
    policy_sub = policy.add_subparsers(dest="policy_command")
    policy_show = policy_sub.add_parser("show", help="Show the active policy.")
    policy_show.add_argument("--policy-file", default=DEFAULT_POLICY_FILE, help="Policy file path.")
    policy_show.add_argument("--user", help="Show the effective policy for this Unix login user.")
    policy_show.set_defaults(func=cmd_policy_show)
    policy_install = policy_sub.add_parser("install", help="Install the host policy.")
    policy_install.add_argument("--policy-file", default=DEFAULT_POLICY_FILE, help="Policy file path.")
    policy_install.add_argument("--user", help="Set policy for this Unix login user. Omit to set the default policy.")
    policy_install.add_argument("--max-time", type=duration_seconds, default=MAX_TIME_SECONDS, help="Maximum SSH lifetime. Hard cap is 24h.")
    policy_install.add_argument("--max-connections", type=positive_int, default=MAX_CONNECTIONS, help="Maximum active sessions. Hard cap is 10.")
    policy_install.set_defaults(func=cmd_policy_install)

    host = subparsers.add_parser("host", help="Configure a production SSH host for temporary access.")
    host_sub = host.add_subparsers(dest="host_command")
    host_install = host_sub.add_parser("install", help="Trust the CA and install the forced session wrapper.")
    host_install.add_argument("--ca-pub", required=True, help="CA public key to trust.")
    host_install.add_argument("--username", "--user", dest="user", default="deploy", help="Unix account that may receive temporary SSH access.")
    host_install.add_argument("--principal", action="append", help="Allowed certificate principal. Defaults to --user. Repeatable.")
    host_install.add_argument("--trusted-ca", default="/etc/ssh/sshfling_user_ca.pub", help="Installed CA public key path.")
    host_install.add_argument("--principals-dir", default="/etc/ssh/auth_principals", help="Authorized principals directory.")
    host_install.add_argument("--sshd-config", default="/etc/ssh/sshd_config.d/90-sshfling-temp-access.conf", help="Managed sshd config snippet.")
    host_install.add_argument("--session-wrapper", default=DEFAULT_SESSION_WRAPPER, help="Installed session wrapper path.")
    host_install.add_argument("--policy-file", default=DEFAULT_POLICY_FILE, help="Installed policy file path.")
    host_install.add_argument("--max-time", type=duration_seconds, help="Install a maximum SSH lifetime policy. Hard cap is 24h.")
    host_install.add_argument("--max-connections", type=positive_int, help="Install a maximum active session policy. Hard cap is 10.")
    host_install.add_argument("--create-user", action="store_true", help="Create the Unix user if missing.")
    host_install.add_argument("--no-validate", dest="validate", action="store_false", help="Skip sshd -t validation.")
    host_install.add_argument("--reload", action="store_true", help="Reload sshd after writing config.")
    host_install.add_argument("--dry-run", action="store_true", help="Show intended changes without writing files.")
    host_install.set_defaults(func=cmd_host_install, validate=True)
    host_uninstall = host_sub.add_parser("uninstall", help="Remove sshfling host SSH configuration.")
    host_uninstall.add_argument("--username", "--user", dest="user", default="deploy", help="Unix account configured for temporary SSH access.")
    host_uninstall.add_argument("--principal", action="append", help="Expected authorized principal. Defaults to --user. Repeatable.")
    host_uninstall.add_argument("--trusted-ca", default="/etc/ssh/sshfling_user_ca.pub", help="Installed CA public key path.")
    host_uninstall.add_argument("--principals-dir", default="/etc/ssh/auth_principals", help="Authorized principals directory.")
    host_uninstall.add_argument("--sshd-config", default="/etc/ssh/sshd_config.d/90-sshfling-temp-access.conf", help="Managed sshd config snippet.")
    host_uninstall.add_argument("--session-wrapper", default=DEFAULT_SESSION_WRAPPER, help="Installed session wrapper path.")
    host_uninstall.add_argument("--policy-file", default=DEFAULT_POLICY_FILE, help="Installed policy file path.")
    host_uninstall.add_argument("--remove-ca", action="store_true", help="Also remove the installed trusted CA file.")
    host_uninstall.add_argument("--remove-wrapper", action="store_true", help="Also remove the installed session wrapper.")
    host_uninstall.add_argument("--remove-policy-user", action="store_true", help="Remove this user's policy override from the policy file.")
    host_uninstall.add_argument("--delete-user", action="store_true", help="Delete the Unix account. Use only for accounts created solely for sshfling.")
    host_uninstall.add_argument("--force", action="store_true", help="Remove files even when managed-content checks do not match.")
    host_uninstall.add_argument("--no-validate", dest="validate", action="store_false", help="Skip sshd -t validation.")
    host_uninstall.add_argument("--reload", action="store_true", help="Reload sshd after removing config.")
    host_uninstall.add_argument("--dry-run", action="store_true", help="Show intended removals without changing files.")
    host_uninstall.set_defaults(func=cmd_host_uninstall, validate=True)

    serve = subparsers.add_parser("serve", help="Run the temporary SSH certificate issuer service.")
    serve.add_argument("--listen", default=DEFAULT_ISSUER_LISTEN, help="Issuer listen address as host:port.")
    serve.add_argument("--ca-key", default=str(default_ca_key_path()), help="CA private key path.")
    serve.add_argument("--allowed-principal", action="append", default=["deploy"], help="Allowed principal or comma list. Repeatable.")
    serve.add_argument("--default-seconds", type=positive_int, default=300, help="Default certificate lifetime.")
    serve.add_argument("--max-seconds", type=positive_int, default=MAX_TIME_SECONDS, help="Maximum certificate lifetime.")
    serve.add_argument("--session-wrapper", default=DEFAULT_SESSION_WRAPPER, help="Forced command wrapper path on target hosts.")
    serve.add_argument("--policy-file", default=DEFAULT_POLICY_FILE, help=argparse.SUPPRESS)
    serve.add_argument("--token-env", default="SSHFLING_ISSUER_TOKEN", help="Environment variable containing the bearer token.")
    serve.add_argument("--token", help="Bearer token. Prefer --token-env for production.")
    serve.set_defaults(func=cmd_serve)

    web = subparsers.add_parser("web", help="Run the local admin web console.")
    web.add_argument("--listen", default="127.0.0.1:8790", help="Web listen address as host:port.")
    web.add_argument("--user", default=os.environ.get("SSHFLING_WEB_USER", "admin"), help="Login username.")
    web.add_argument("--password-hash", help="PBKDF2 password hash. Prefer SSHFLING_WEB_PASSWORD_HASH.")
    web.add_argument("--password-hash-env", default="SSHFLING_WEB_PASSWORD_HASH", help="Environment variable containing the password hash.")
    web.add_argument("--password-env", default="SSHFLING_WEB_PASSWORD", help="Environment variable containing a plaintext password.")
    web.add_argument("--session-secret-env", default="SSHFLING_WEB_SESSION_SECRET", help="Environment variable containing the cookie signing secret.")
    web.add_argument("--policy-file", default=DEFAULT_POLICY_FILE, help="Policy file path.")
    web.add_argument("--allow-remote", action="store_true", help="Allow binding to a non-local address.")
    web.set_defaults(func=cmd_web)

    web_hash = subparsers.add_parser("web-hash", help="Hash a web login password.")
    web_hash.add_argument("--password-env", default="SSHFLING_WEB_PASSWORD", help="Environment variable containing the password.")
    web_hash.set_defaults(func=cmd_web_hash)

    detached = subparsers.add_parser("detached", help="Manage detached local jobs with PIDs and logs.")
    detached_sub = detached.add_subparsers(dest="detached_command")
    detached_start = detached_sub.add_parser("start", help="Start a detached local command.")
    detached_start.add_argument("--name", required=True, help="Detached job name.")
    detached_start.add_argument("-t", "--time", type=duration_seconds, default=MAX_TIME_SECONDS, help="Maximum runtime, up to 24h.")
    detached_start.add_argument("--cwd", default=".", help="Working directory for the command.")
    detached_start.add_argument("--detached-dir", help="Detached job metadata directory.")
    detached_start.add_argument("--replace", action="store_true", help="Replace an inactive job with the same name.")
    detached_start.add_argument("detached_args", nargs=argparse.REMAINDER, help="Command to run after --.")
    detached_start.set_defaults(func=cmd_detached_start)
    detached_list = detached_sub.add_parser("list", help="List detached local jobs.")
    detached_list.add_argument("--name", help="Only show this detached job.")
    detached_list.add_argument("--detached-dir", help="Detached job metadata directory.")
    detached_list.set_defaults(func=cmd_detached_list)
    detached_kill = detached_sub.add_parser("kill", help="Kill a detached local job.")
    detached_kill.add_argument("name", help="Detached job name.")
    detached_kill.add_argument("--detached-dir", help="Detached job metadata directory.")
    detached_kill.set_defaults(func=cmd_detached_kill)

    detached_supervisor = subparsers.add_parser("_detached-supervisor", help=argparse.SUPPRESS)
    detached_supervisor.add_argument("--metadata", required=True)
    detached_supervisor.add_argument("detached_args", nargs=argparse.REMAINDER)
    detached_supervisor.set_defaults(func=cmd_detached_supervisor)

    init = subparsers.add_parser("init", help="Copy deployment templates into a directory.")
    init.add_argument("path", nargs="?", default=None, help="Target directory. Defaults to --project-dir.")
    init.add_argument("--force", action="store_true", help="Overwrite existing template files.")
    init.add_argument("--with-key", action="store_true", help="Generate the client SSH keypair.")
    init.add_argument("--session-seconds", type=positive_int, help="Write SSH_SESSION_SECONDS to .env.")
    init.add_argument("--host-port", type=positive_int, help="Write SSH_PORT_ON_HOST to .env.")
    init.set_defaults(func=lambda args: cmd_init(normalize_init_path(args)))

    key = subparsers.add_parser("key", help="Manage the client SSH keypair.")
    key_sub = key.add_subparsers(dest="key_command")
    key_generate = key_sub.add_parser("generate", help="Generate an ed25519 client keypair.")
    key_generate.add_argument("--path", default="secrets/client_ed25519", help="Private key path.")
    key_generate.add_argument("--force", action="store_true", help="Replace an existing keypair.")
    key_generate.set_defaults(func=cmd_key_generate)

    network = subparsers.add_parser("network", help="Manage the shared Docker network.")
    network_sub = network.add_subparsers(dest="network_command")
    network_create = network_sub.add_parser("create", help="Create the shared Docker network.")
    network_create.add_argument("--name", default=DEFAULT_NETWORK)
    network_create.set_defaults(func=cmd_network_create)

    server = subparsers.add_parser("server", help="Manage the SSH server Compose deployment.")
    server_sub = server.add_subparsers(dest="server_command")
    server_up = server_sub.add_parser("up", help="Start the SSH server.")
    server_up.add_argument("--build", action="store_true", help="Build the server image first.")
    server_up.add_argument("--force-recreate", action="store_true", help="Recreate the container.")
    server_up.add_argument("--session-seconds", type=positive_int, help="Override SSH_SESSION_SECONDS.")
    server_up.set_defaults(func=cmd_server)
    server_sub.add_parser("down", help="Stop and remove the SSH server.").set_defaults(func=cmd_server)
    server_sub.add_parser("restart", help="Restart the SSH server.").set_defaults(func=cmd_server)
    server_sub.add_parser("status", help="Show server container status.").set_defaults(func=cmd_server)
    server_logs = server_sub.add_parser("logs", help="Show server logs.")
    server_logs.add_argument("--follow", "-f", action="store_true")
    server_logs.add_argument("--tail", type=positive_int)
    server_logs.set_defaults(func=cmd_server)

    client = subparsers.add_parser("client", help="Run SSH client commands.")
    client_sub = client.add_subparsers(dest="client_command")
    client_run = client_sub.add_parser("run", help="Run a remote command through the SSH client container.")
    client_run.add_argument("remote_command", nargs=argparse.REMAINDER)
    client_run.set_defaults(func=cmd_client_run)

    test_timeout = subparsers.add_parser("test-timeout", help="Run a server-side timeout smoke test.")
    test_timeout.add_argument("--seconds", type=positive_int, default=5, help="Session limit for the test.")
    test_timeout.add_argument("--sleep", type=positive_int, default=20, help="Remote sleep duration.")
    test_timeout.set_defaults(func=cmd_test_timeout)

    compose = subparsers.add_parser("compose", help="Raw docker compose escape hatch.")
    compose.add_argument("kind", choices=["server", "client"])
    compose.add_argument("compose_args", nargs=argparse.REMAINDER)
    compose.set_defaults(func=cmd_compose)

    package = subparsers.add_parser("package", help="Build OS packages.")
    package_sub = package.add_subparsers(dest="package_command")
    package_build = package_sub.add_parser("build", help="Build deb, rpm, msi, or all packages.")
    package_build.add_argument("--type", choices=["deb", "rpm", "msi", "pkg", "all"], default="all")
    package_build.set_defaults(func=cmd_package_build)

    return parser


def normalize_init_path(args):
    if args.path:
        args.project_dir = args.path
    return args


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    connect_args = maybe_connect_argv(argv)
    if connect_args:
        before_args, target, after_args = connect_args
        try:
            return cmd_connect(before_args, target, after_args)
        except SSHFlingError as exc:
            eprint(f"sshfling: {exc.message}")
            if exc.details.get("stderr"):
                eprint(exc.details["stderr"].rstrip())
            return exc.code

    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        if args.kill:
            if args.command:
                parser.error("-k/--kill cannot be combined with a subcommand")
            if args.time is not None:
                parser.error("-k/--kill cannot be combined with -t/--time")
            return cmd_kill(args)

        if not args.command:
            if args.time is None:
                args.time = effective_policy(load_policy(args.policy_file), args.login_user or args.username)["max_time_seconds"]
            return cmd_setup(args)

        if not hasattr(args, "func"):
            parser.error(f"missing subcommand for {args.command}")

        return args.func(args)
    except SSHFlingError as exc:
        if getattr(args, "json", False):
            emit_json({"ok": False, "error": {"message": exc.message, "details": exc.details}})
        else:
            eprint(f"sshfling: {exc.message}")
            if exc.details.get("stderr"):
                eprint(exc.details["stderr"].rstrip())
        return exc.code


if __name__ == "__main__":
    sys.exit(main())
