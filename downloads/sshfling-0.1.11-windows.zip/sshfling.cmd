@echo off
python "%~dp0sshfling.py" %*
